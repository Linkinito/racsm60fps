# Protocole — palier 03 Ryllus sous PPSSPP 1.19.3 / Windows 11

## État de départ

Les paliers Pokitaru sont validés. Le parcours complet a installé les 55 callsites de LEVEL_01, enregistré 496 697 hits connus sans `unknown_hits`, puis effectué une transition propre vers LEVEL_02. Ryllus a été reconnu, mais n’a reçu aucune redirection car le palier 02 imposait `allowed_module = 1`.

La v0.4.4 conserve ces garde-fous et ajoute le format `rcsm-wrapper-trace/4`. Le prochain objectif est de vérifier la transparence des 57 hooks de Ryllus et de recueillir leur distribution temporelle.

## Préparation

1. Fermer complètement PPSSPP.
2. Ouvrir le Memory Stick depuis PPSSPP.
3. Déplacer les anciens `status.log` et `trace_*.json` dans un dossier d’archive.
4. Supprimer entièrement `PSP\PLUGINS\SizeMattersWrapperProfiler`.
5. Désactiver provisoirement les cheats, l’ancien patch 60 FPS et tout autre plugin Size Matters.
6. Extraire uniquement `RCSMProfiler_v0.4.4_STAGE03_FULL_RYLLUS_UCES00420.zip` à la racine du Memory Stick.
7. Utiliser une sauvegarde **interne au jeu**, de préférence directement sur Ryllus. Ne pas charger un savestate créé avec une autre version du plugin.

Conserver le cœur CPU habituel, idéalement le JIT par défaut, le frameskip à zéro et la vitesse d’émulation à 100 %. Le plugin mesure les VBlank ; il ne change ni la limite FPS ni le wrapper deux-passes.

## Vérification au démarrage

Après le chargement de Ryllus, le journal doit contenir :

```text
start version=0.4.4-prealpha ... mode=full_module ... allowed_module=2
module armed key=LEVEL_02 index=2 ... callsites=57 resolver=module_api base=0x........ delta=.....
PPSSPP JIT marker accepted key=LEVEL_02 ...
```

Arrêter immédiatement le test si la dernière ligne `start` indique une ancienne version, si `callsites` n’est pas 57, si `allowed_module` n’est pas 2, si l’installation est refusée ou si un mot est déclaré `foreign/unreadable`.

## Parcours recommandé

Le meilleur retour est un parcours aussi complet que possible de Ryllus. Les actions suivantes augmentent la couverture sans imposer une chorégraphie stricte :

- marcher, sauter et tourner la caméra dans plusieurs zones ;
- combattre plusieurs types d’ennemis avec la clé et au moins deux armes ;
- utiliser des portes, ponts, plateformes, ascenseurs ou éléments mobiles ;
- déclencher des cinématiques ou scripts normaux du niveau ;
- revenir brièvement dans une zone déjà visitée si le parcours le permet.

Après une longue portion ou à la fin du niveau, appuyer une fois sur `L + R + SELECT` pendant que Ratchet est encore visible et contrôlable. Attendre deux secondes. Si la progression permet ensuite de changer de niveau, effectuer cette transition : le plugin doit exporter automatiquement LEVEL_02, reconnaître le niveau suivant, puis rester sans écriture parce que seul le module 2 est autorisé.

Quitter PPSSPP normalement après l’export ou la transition. Ne pas changer de configuration ni charger de savestate au milieu de la capture.

## Résultat attendu

La trace manuelle doit contenir :

- `schema: "rcsm-wrapper-trace/4"` ;
- `module.index: 2` et `module.key: "LEVEL_02"` ;
- 57 entrées ;
- `installed_callsites: 57` ;
- `unknown_hits: 0` ;
- au moins un callsite actif ;
- des métriques temporelles cohérentes pour chaque entrée active.

Pour une entrée active, les invariants principaux sont :

```text
active_vblanks >= 1
same_vblank_hits = hits - active_vblanks
gap_1_vblank + gap_2_vblank + gap_other_vblank = active_vblanks - 1
```

Le parseur les vérifie automatiquement :

```powershell
python profiler\tools\parse_trace.py "C:\chemin\vers\trace_L02_0001.json" --csv "C:\chemin\vers\trace_L02_0001.csv"
```

Une sortie `status: PASS` valide le format, le corpus, les adresses runtime et les invariants temporels. Elle ne décide pas encore quelles familles doivent passer à une seule passe.

## Critères d’arrêt

| Symptôme | Action |
|---|---|
| aucune ligne `module armed` pour LEVEL_02 | exporter manuellement, quitter et fournir le log |
| ancienne version ou mauvais `allowed_module` | supprimer tout le dossier du plugin et réinstaller le palier 03 |
| `resolver=fallback_scan` | ne pas poursuivre une longue session ; fournir le log |
| `install refused`, `foreign` ou `unreadable` | quitter sans forcer et fournir le log |
| crash, blocage, animation ou commandes anormales | fermer PPSSPP et décrire l’action exacte |
| `unknown_hits > 0` | ne pas tester un autre niveau instrumenté |
| marqueur `PPSSPP JIT marker accepted` | comportement normal si les autres gardes restent valides |

## Fichiers à renvoyer

Fournir le `status.log` complet et toutes les traces créées pendant la session, notamment la trace manuelle LEVEL_02 et l’éventuelle trace automatique de transition. Une courte indication des zones parcourues et des interactions suffit ; le log PPSSPP n’est nécessaire qu’en cas de problème visible ou de refus d’installation.

La comparaison 30/60 FPS viendra seulement après ce palier. Elle exigera des scènes reproductibles et une mesure gameplay associée à la cadence observée ; aucune règle `ONE_PASS` ne sera déduite des seuls totaux.
