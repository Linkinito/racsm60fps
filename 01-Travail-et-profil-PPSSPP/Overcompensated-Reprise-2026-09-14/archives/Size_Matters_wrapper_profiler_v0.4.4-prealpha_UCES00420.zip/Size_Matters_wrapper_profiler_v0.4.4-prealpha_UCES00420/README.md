# Size Matters — wrapper profiler v0.4.4-prealpha (UCES00420)

Ce paquet prolonge le catalogue statique par un **PRX utilisateur compilé** pour PPSSPP. Il ne constitue pas encore un patch 60 FPS : il reconnaît le PRX de niveau actif, observe les appels au wrapper deux-passes sans changer son résultat et exporte les mesures nécessaires au futur dispatcher.

## État au 25 août 2026

- 15 modules, 493 callsites et 59 familles cartographiés ;
- résolution dynamique de `rcp1`, testée in situ à `+0x7000` ;
- trampoline Allegrex sauvegardant GPR, HI/LO, FCR31 et les 32 FPR scalaires ;
- installation transactionnelle, rollback, retrait conditionnel et synchronisation des caches ;
- marqueurs JIT `0x68xxxxxx` acceptés uniquement au premier mot du wrapper, avec toutes les autres gardes exactes ;
- palier 02 Pokitaru **validé in situ** : 55/55 callsites installés, 34 actifs, 496 697 hits connus et zéro `$ra` inconnu ;
- `HutDoor` (WF-016) observé 303 fois et `TriggeredDoor` (WF-019) 25 fois ;
- transition Pokitaru → Ryllus réussie : export automatique de LEVEL_01, LEVEL_02 reconnu, zéro écriture grâce à `allowed_module=1` ;
- traces JSON v4 avec activité par VBlank, multiplicité intra-VBlank et histogramme des écarts ;
- PRX v0.4.4 compilé et validé par 801 contrôles binaires ;
- empreinte estimée : 35 060 octets chargés + 18 432 octets de piles, soit environ 53 492 octets ;
- **prochaine frontière : palier 03, les 57 callsites de Ryllus**.

Le bilan détaillé du parcours se trouve dans [POKITARU_STAGE02_RESULT.md](POKITARU_STAGE02_RESULT.md). Ouvrir [index.html](index.html) pour le rapport vulgarisé et [TEST_PROTOCOL_PPSSPP_1.19.3_WINDOWS11.md](TEST_PROTOCOL_PPSSPP_1.19.3_WINDOWS11.md) pour la prochaine session.

## Prochain essai

1. Fermer complètement PPSSPP et supprimer l’ancien dossier du plugin.
2. Installer uniquement `install/03_FULL_RYLLUS` ou son archive prête à extraire.
3. Charger une sauvegarde interne sur Ryllus, parcourir le niveau et interagir avec portes, ponts, ennemis, armes et éléments mobiles.
4. Exporter avec `L + R + SELECT` pendant que Ratchet est encore contrôlable ; si possible, effectuer ensuite la transition vers le niveau suivant.
5. Fournir `status.log` et toutes les traces `trace_L02_*.json` produites.

Les sources et preuves de compilation se trouvent dans `profiler/`. Aucun EBOOT, PRX de niveau ou autre binaire du jeu n’est inclus ; `patch.prx` est uniquement le module original produit pour cette expérimentation.
