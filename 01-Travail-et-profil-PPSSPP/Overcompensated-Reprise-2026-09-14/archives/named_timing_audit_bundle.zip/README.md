# Audit 60 FPS nommé — première passe consolidée

- **21 PRX** scannés, dont **17** avec descripteurs de classes reconnus
- **972 descripteurs de classes** retrouvés
- **145 classes uniques**
- **170 écritures de patch connues** projetées dans les PRX concernés
- Vérification des opcodes/constantes originales : **100 % conformes**

## Résultat structurel majeur

Les descripteurs de classe donnent directement `nom -> Init -> Destroy -> Update`. Les correctifs connus peuvent donc être dérivés relativement à la classe, sans utiliser un décalage global entre PRX.

## Patches déjà projetables automatiquement

- Lacérator : **17 PRX**
- Sniper Mine : **16 PRX**
- Shock Rocket : **16 PRX**
- T.E.L.T. : **12 PRX**

## Armes à auditer en priorité

- `BlasterShot` — 17 PRX — priorité max **115** — FRAME_BASED_HIGH
- `BlitzGunShot` — 16 PRX — priorité max **60** — FRAME_TIMER_SUSPECT
- `Bombglove` — 16 PRX — priorité max **90** — FRAME_MOVEMENT_SUSPECT
- `Acidbomb` — 16 PRX — priorité max **5** — DELTA_AWARE
- `AgentsGlove` — 12 PRX — priorité max **120** — FRAME_BASED_HIGH
- `AgentsGrenade` — 12 PRX — priorité max **90** — FRAME_MOVEMENT_SUSPECT
- `AgentsLaser` — 12 PRX — priorité max **5** — DELTA_AWARE
- `AgentsRocket` — 12 PRX — priorité max **38** — FIXED_DT_REVIEW
- `BeeMineGlove` — 16 PRX — priorité max **5** — DELTA_AWARE
- `ExplosiveBee` — 16 PRX — priorité max **115** — FRAME_BASED_HIGH
- `Flamethrower` — 16 PRX — priorité max **65** — FRAME_TIMER_SUSPECT
- `SuckCannonManager` — 13 PRX — priorité max **115** — FRAME_BASED_HIGH
- `SuckCannonComet` — 13 PRX — priorité max **90** — FRAME_MOVEMENT_SUSPECT
- `CrossbowGun` — 16 PRX — priorité max **125** — FRAME_BASED_HIGH
- `CrossbowShot` — 16 PRX — priorité max **115** — FRAME_BASED_HIGH
- `ShockRocketShot` — 16 PRX — priorité max **90** — FRAME_MOVEMENT_SUSPECT
- `Mootator` — 16 PRX — priorité max **90** — DELTA_AWARE, FRAME_MOVEMENT_SUSPECT
- `LaserTracer` — 12 PRX — priorité max **60** — FRAME_TIMER_SUSPECT
- `RynoRocket` — 12 PRX — priorité max **21** — LOW_CONFIDENCE_COUNTER

## Prudence

La classification est un triage statique. `DIRECT_POSITION_STEP` peut aussi désigner une interpolation ou un effet local, et une fonction peut être correcte si son incrément a déjà été préparé avec le delta. Chaque patch reste soumis à validation dynamique.