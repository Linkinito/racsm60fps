# Size Matters 60 FPS — expérience générale globale

Version **v0.2.0-prealpha.1**, cible **Europe UCES-00420**. Cette pré-alpha ajoute au socle global les 13 armes, le wrapper commun en une passe, la physique des breakables avec les boulons ordinaires, ainsi que les effets/particules dont les signatures ont été retrouvées sans ambiguïté.

Le profil ne débloque rien dans la sauvegarde : les armes et les 23 mods restent acquis, équipés et progressés normalement. Les mods ne reçoivent pas 23 écritures arbitraires ; leurs effets profitent des corrections apportées aux systèmes d’armes qu’ils réutilisent, puis devront être retestés combinaison par combinaison.

## Profils

| Fichier | Écritures logiques | Compactes | Continues | Valeurs du dictionnaire | Fin de table |
|---|---:|---:|---:|---:|---:|
| 01_GLOBAL_60FPS_BASE_PREALPHA.ini | 60 | 60 | 0 | 4 | 0x08800170 |
| 02_GLOBAL_60FPS_SOCLE_PREALPHA.ini | 112 | 112 | 0 | 7 | 0x08800240 |
| 03_GLOBAL_60FPS_EXPERIENCE_PREALPHA.ini | 1485 | 1408 | 77 | 151 | 0x08801680 |
| 04_GLOBAL_EXPERIENCE_RESTORE_NEXT_LOAD.ini | 1386 | 1309 | 77 | 83 | 0x088014F4 |

Le profil recommandé pour un premier parcours est `03_GLOBAL_60FPS_EXPERIENCE_PREALPHA.ini`. Les quatre INI sont alternatifs : redémarrer complètement PPSSPP avant d’en remplacer un autre.

## Couverture du profil expérience

| Index | PRX | Niveau | Armes/caves | Breakables/boulons | Particules/FX | Total |
|---:|---|---|---:|---:|---:|---:|
| 1 | LEVEL_01.PRX | Pokitaru | 86 | 19 | 8 | 122 |
| 2 | LEVEL_02.PRX | Ryllus | 86 | 19 | 7 | 121 |
| 3 | LEVEL_03.PRX | Kalidon | 86 | 19 | 7 | 121 |
| 4 | LEVEL_04.PRX | Metalis | 86 | 19 | 8 | 122 |
| 5 | LEVEL_05.PRX | Dreamtime | 86 | 19 | 5 | 119 |
| 6 | LEVEL_06.PRX | Medical Outpost Omega | 86 | 19 | 5 | 119 |
| 7 | LEVEL_07.PRX | Challax | 86 | 19 | 7 | 121 |
| 8 | LEVEL_08.PRX | Dayni Moon | 86 | 19 | 7 | 121 |
| 9 | LEVEL_09.PRX | Inside Clank | 86 | 19 | 7 | 121 |
| 10 | LEVEL_10.PRX | Quadrona | 86 | 19 | 7 | 121 |
| 15 | LEVEL_15.PRX | Giant Clank — niveau 4 | 0 | 7 | 3 | 17 |
| 21 | LEVEL_21.PRX | Giant Clank — niveau 7 | 0 | 7 | 3 | 17 |
| 22 | LEVEL_22.PRX | Airboard — niveau 3 | 2 | 7 | 3 | 19 |
| 23 | LEVEL_23.PRX | Airboard — niveau 6 | 86 | 7 | 5 | 107 |
| 24 | LEVEL_24.PRX | HIG Treehouse | 86 | 19 | 5 | 117 |

Les Giant Clank n’embarquent pas les classes des 13 armes. L’Airboard niveau 3 n’embarque que le Lacerator. Les tables reflètent cette présence réelle au lieu d’écrire des adresses supposées.

## Installation et retour vanilla

1. Copier un seul INI sous le nom `UCES00420.ini` dans `PPSSPP/PSP/Cheats`.
2. Démarrer PPSSPP à froid, activer les cheats, puis entrer dans le niveau depuis le frontend.
3. Pour restaurer, démarrer avec `04_GLOBAL_EXPERIENCE_RESTORE_NEXT_LOAD.ini`, charger chaque niveau concerné, puis activer son bloc de retrait du hook ou redémarrer à froid sans l’INI.

Ne pas commencer par une savestate prise dans un PRX déjà chargé : le dispatcher agit juste avant l’initialisation du module.

## Statut et limites

- Le socle Pokitaru reste la seule base ayant reçu une validation dynamique antérieure.
- Les portages multi-PRX, les 79 écritures d’armes, le wrapper, les breakables et les particules sont validés statiquement mais nécessitent des essais en jeu.
- Sept constantes de rotation des boulons sont initialisées après le chargement du PRX ; elles représentent 77 écritures module-adresse maintenues en continu et conditionnées par l’index du module.
- “Particules” signifie ici les effets connus : trois phases de level-up, émission de feu là où la classe existe, deux timers de téléporteur, fondu Bee Mine et shrapnel Agents. Ce n’est pas encore un correctif exhaustif du moteur de particules.
- Le wrapper global remplace la variante Local JAL ; les deux approches ne doivent jamais être combinées.
- FRONTEND et `LEVEL_16` à `LEVEL_20` ne sont jamais patchés.

Le paquet ne contient aucun PRX, WAD, EBOOT ni dump RAM du jeu. Il requiert une copie légitime de la version européenne.
