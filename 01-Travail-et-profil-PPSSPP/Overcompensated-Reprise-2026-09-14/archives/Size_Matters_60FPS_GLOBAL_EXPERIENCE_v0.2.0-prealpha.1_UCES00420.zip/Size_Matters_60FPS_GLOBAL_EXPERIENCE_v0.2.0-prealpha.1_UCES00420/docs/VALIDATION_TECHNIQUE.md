# Validation technique

- 1485 enregistrements de patch, dont 1034 armes/caves et 237 breakables/caves.
- 122 adresses recoupées exactement avec `known_weapon_patch_candidates.csv`.
- Signatures de portage acceptées uniquement avec contexte normalisé exact et marge minimale de 0,40 ; le record SuckCannonComet utilise une séquence de douze mots unique.
- Wrapper choisi par prologue exact et nombre maximal d’appelants, ce qui exclut les clones mono-appel.
- Valeurs vanilla relocalisées pour les instructions MIPS26 du VBlank et du wrapper.
- Corps de caves écrits avant les hooks ; retours spécifiques au module écrits en première phase.
- Tables, dictionnaire, dispatcher et caves bornés dans la zone vérifiée nulle.
- Ryllus construit depuis `LEVEL_02_clean.PRX`, pas depuis le PRX déjà contaminé de `BIN.zip`.

La validation statique ne remplace pas une exécution réelle dans PPSSPP.
