# Kalidon — Passage B 60 FPS avec Titanium Bolt

Ce paquet est destiné au passage B de la comparaison 30/60 FPS sur Kalidon, version européenne UCES-00420. Il conserve le wrapper deux-passes vanilla observé par `RCSMProfiler v0.4.5 Stage04` et ajoute uniquement le socle minimal 60 FPS, la compensation caméra et les deux corrections du Titanium Bolt.

## Installation

Si ton fichier `PSP/Cheats/UCES00420.ini` contient déjà d'autres codes, copie seulement le bloc présent dans `merge_snippet/KALIDON_PASSAGE_B_60FPS_TITANIUM.ini`. Si tu utilises le fichier de remplacement fourni dans `ready_replacement`, sauvegarde d'abord ton INI actuel afin de ne pas perdre tes autres cheats.

Dans PPSSPP, active ensuite le code `[TEST B] Kalidon 60 FPS - SOCLE MINIMAL + TITANIUM (PRX +0x8000)`. Le code est livré en `_C0`, donc désactivé par défaut jusqu'à ce que tu coches son entrée dans le menu des cheats.

## Conditions obligatoires

Le paquet suppose que le journal du profileur annonce `LEVEL_03`, `runtime_base=0x09141D00` et `delta=32768`. Les huit écritures ont été relocalisées de `+0x8000` pour cette configuration précise ; si le delta change, n'utilise pas ce bloc et transmets le nouveau `status.log`.

Effectue un redémarrage complet de PPSSPP entre le passage A vanilla et le passage B 60 FPS. N'active simultanément ni le patch global `v0.2.1`, ni un ancien correctif local de wrapper, car ils modifieraient les objets que le profileur doit encore observer en deux-passes.

## Titanium Bolt

Les deux lignes supplémentaires corrigent la vitesse `0,24 -> 0,12` et le facteur `2,0 -> 1,0` du Titanium Bolt. Elles ne donnent pas automatiquement le boulon : elles permettent de le récupérer pendant le parcours 60 FPS sans réintroduire le reste du profil global expérimental.

## Portée du test

Le garde CWCheat vérifie que l'index de module vaut `3`, puis applique exactement huit écritures. Aucune redirection `jal` du wrapper, aucune correction de plateforme, de MungoDrone, d'arme, de débris ou de particules n'est incluse dans ce paquet.
