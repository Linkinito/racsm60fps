# Size Matters 60 FPS — premier socle global

Version **v0.1.0-prealpha.1**, cible **Europe UCES-00420**. Ce paquet contient un seul dispatcher EBOOT capable d’appliquer la bonne table avant le démarrage de chacun des quinze PRX solo ou modes spéciaux.

Le frontend reste à 30 FPS. Les modules `LEVEL_16` à `LEVEL_20`, correspondant au multijoueur et au lobby, ne possèdent aucune table et ne sont donc jamais modifiés.

## Profils

| Fichier | Contenu | Écritures PRX | Usage |
|---|---|---:|---|
| `01_GLOBAL_60FPS_BASE_PREALPHA.ini` | VBlank, sous-pas, delta général, compensation joueur | 60 | Premier témoin global |
| `02_GLOBAL_60FPS_SOCLE_PREALPHA.ini` | Base + caméra + Titanium Bolt lorsqu’il existe | 112 | Profil recommandé pour la campagne de test |
| `03_GLOBAL_SOCLE_RESTORE_NEXT_LOAD.ini` | Valeurs vanilla du socle, choisies par module | 112 | Restauration au prochain chargement |

Ces fichiers sont strictement alternatifs. Un redémarrage complet de PPSSPP est obligatoire avant de remplacer l’un par l’autre, car retirer une coche dans le menu des cheats n’efface ni le hook EBOOT ni les mots déjà écrits en RAM.

## Installation

1. Choisir un seul INI et le renommer `UCES00420.ini`.
2. Le placer dans `PPSSPP/PSP/Cheats`, puis activer les cheats.
3. Démarrer le jeu à froid et entrer normalement dans le niveau depuis le frontend.
4. Ne pas commencer par une savestate prise dans un PRX déjà chargé.

Le dispatcher lit l’index demandé à `0x08841120`, parcourt ses tables à partir de `0x08802080`, puis écrit seulement les valeurs du module correspondant. Les PRX continuent de partager la base runtime `0x09139D00`, mais leurs adresses internes sont différentes.

## Couverture

| Index | PRX | Niveau / rôle | Base | Ajouts socle | Titanium | Validation |
|---:|---|---|---:|---:|---|---|
| `1` | `LEVEL_01.PRX` | Pokitaru | 4 | 4 | Oui | Pokitaru validé |
| `2` | `LEVEL_02.PRX` | Ryllus | 4 | 4 | Oui | Test requis |
| `3` | `LEVEL_03.PRX` | Kalidon | 4 | 4 | Oui | Test requis |
| `4` | `LEVEL_04.PRX` | Metalis | 4 | 4 | Oui | Test requis |
| `5` | `LEVEL_05.PRX` | Dreamtime | 4 | 4 | Oui | Test requis |
| `6` | `LEVEL_06.PRX` | Medical Outpost Omega | 4 | 4 | Oui | Test requis |
| `7` | `LEVEL_07.PRX` | Challax | 4 | 4 | Oui | Test requis |
| `8` | `LEVEL_08.PRX` | Dayni Moon | 4 | 4 | Oui | Test requis |
| `9` | `LEVEL_09.PRX` | Inside Clank | 4 | 4 | Oui | Test requis |
| `10` | `LEVEL_10.PRX` | Quadrona | 4 | 4 | Oui | Test requis |
| `15` | `LEVEL_15.PRX` | Giant Clank — niveau 4 | 4 | 2 | Absent du module | Test requis |
| `21` | `LEVEL_21.PRX` | Giant Clank — niveau 7 | 4 | 2 | Absent du module | Test requis |
| `22` | `LEVEL_22.PRX` | Airboard — niveau 3 | 4 | 2 | Absent du module | Test requis |
| `23` | `LEVEL_23.PRX` | Airboard — niveau 6 | 4 | 4 | Oui | Test requis |
| `24` | `LEVEL_24.PRX` | HIG Treehouse | 4 | 2 | Absent du module | Test requis |

## Ce qui n’est pas encore inclus

- armes et mods ;
- ennemis, portes, véhicules et objets propres aux niveaux ;
- wrapper global ou remplacements Local JAL ;
- breakables et boulons ordinaires ;
- particules, UI et autres cosmétiques ;
- frontend et multijoueur.

Ces exclusions sont intentionnelles. Le but de cette pré-alpha est de vérifier le noyau temporel dans tout le solo avant d’ajouter les couches déjà séparées sur Pokitaru.

## Avertissement Ryllus

Le `LEVEL_02.PRX` de `BIN.zip` contient déjà `0x2A240001` à l’adresse runtime `0x0916DE60`. Le constructeur a donc utilisé `LEVEL_02_clean.PRX`, qui contient la valeur vanilla `0x2A240002`, pour calculer le patch et la restauration.

## Référence de symboles trouvée

`BIN/straddle.junk` est un ELF de module `rcp1` contenant 2 374 entrées de symboles ainsi que des sections de debug. Sa structure est proche de `FRONTEND.PRX` sans lui être identique ; il est inventorié comme référence future pour le loader et l’interface, mais n’a servi à aucune écriture de cette pré-alpha.

Le paquet ne contient aucun PRX, WAD, EBOOT, dump RAM ou autre donnée du jeu. Il requiert une copie légitime de la version européenne.
