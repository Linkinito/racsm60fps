# Validation technique statique

## Résultat

- 15 PRX solo ou spéciaux acceptés par hash ;
- 75 signatures structurantes uniques : cinq familles par module ;
- 15 relocations VBlank `R_MIPS_26` confirmées dans les sections `.rel.text` ;
- 60 écritures dans le profil BASE ;
- 112 écritures dans le profil SOCLE et sa restauration ;
- 11 implémentations Titanium Bolt confirmées par code et données ;
- aucune table pour le frontend ou les modules 16–20 ;
- cave EBOOT vide dans les deux dumps disponibles ;
- fin de table BASE : `0x088022E0` ;
- fin de table SOCLE : `0x08802480` ;
- fin de table RESTORE : `0x08802480`.

La validation prouve la cohérence des fichiers, des valeurs vanilla, des valeurs relocalisées et du format de table. Elle ne remplace pas les essais dynamiques dans les quatorze modules autres que Pokitaru.

## Contamination détectée

`BIN/LEVEL_02.PRX` et `LEVEL_02_clean.PRX` ont la même taille et ne diffèrent que d’un octet, au fichier `0x000341D4`. Le mot propre `0x2A240002` est déjà devenu `0x2A240001` dans l’archive ; aucun autre PRX n’a échoué à son hash attendu.

## Statut des correctifs

Pokitaru conserve le statut validé pour le noyau, la caméra et le Titanium Bolt. Tous les autres niveaux sont des portages statiques forts : ils utilisent des signatures uniques et les mêmes mots vanilla, mais doivent encore être comparés en secondes réelles à 30 et 60 FPS.
