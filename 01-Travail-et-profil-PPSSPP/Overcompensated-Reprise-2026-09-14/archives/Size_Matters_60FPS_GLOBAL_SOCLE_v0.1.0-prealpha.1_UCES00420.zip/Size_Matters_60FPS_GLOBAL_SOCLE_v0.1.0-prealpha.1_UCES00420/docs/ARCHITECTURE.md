# Architecture du dispatcher global

Le hook persistant remplace le `jal 0x08807360` de `0x08806DA4` par un appel à `0x08802000`. Le dispatcher lit l’index du module, applique les couples adresse/valeur correspondants, puis effectue un tail-jump vers la routine vanilla.

La table conserve le format `module_index`, `write_count`, puis `write_count` couples de deux mots. Le profil SOCLE occupe exactement `0x400` octets entre `0x08802080` et `0x08802480`, ce qui reste très loin de la limite vérifiée `0x08804000`.

Les caves `0x08802000–0x08803FFF` étaient entièrement nulles dans les dumps Pokitaru et Ryllus. Le mot live de l’ancien hook était `0x0E201CD8` dans les deux dumps, tandis que le mot brut de l’EBOOT est relocalisé au chargement.

## Pourquoi les signatures sont fiables

Dans chaque PRX couvert, les signatures VBlank, sous-pas, delta général, compensation joueur et paire caméra n’apparaissent qu’une seule fois. Les quinze ensembles sont structurellement homologues même lorsque leurs adresses ou leurs cibles `jal` diffèrent.

Le Titanium Bolt exige deux correspondances simultanées : le marqueur `X94<TitaniumBolt_Init`, accompagné des constantes `0,20 / 0,24 / -0,12`, et une séquence de six instructions autour du facteur `2,0`. Les deux preuves sont uniques dans onze PRX et absentes ensemble dans les quatre autres.
