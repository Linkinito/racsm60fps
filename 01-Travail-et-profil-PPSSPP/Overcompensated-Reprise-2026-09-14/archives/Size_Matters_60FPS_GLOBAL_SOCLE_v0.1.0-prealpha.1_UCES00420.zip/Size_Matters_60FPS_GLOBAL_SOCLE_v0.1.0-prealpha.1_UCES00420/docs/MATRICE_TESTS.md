# Matrice de tests dynamiques

Pour chaque ligne, effectuer un démarrage à froid, entrer dans le niveau sans savestate interne, puis comparer successivement vanilla 30 FPS, 60 FPS BASE et 60 FPS SOCLE. Les mesures doivent être exprimées en secondes ou en distance fixe, pas seulement en impression visuelle.

| Index | Niveau | Chargement/crash | Course/saut/chute | Caméra | Titanium | Checkpoint | Sortie du niveau |
|---:|---|---|---|---|---|---|---|
| 1 | Pokitaru | ☐ | ☐ | ☐ | À tester | ☐ | ☐ |
| 2 | Ryllus | ☐ | ☐ | ☐ | À tester | ☐ | ☐ |
| 3 | Kalidon | ☐ | ☐ | ☐ | À tester | ☐ | ☐ |
| 4 | Metalis | ☐ | ☐ | ☐ | À tester | ☐ | ☐ |
| 5 | Dreamtime | ☐ | ☐ | ☐ | À tester | ☐ | ☐ |
| 6 | Medical Outpost Omega | ☐ | ☐ | ☐ | À tester | ☐ | ☐ |
| 7 | Challax | ☐ | ☐ | ☐ | À tester | ☐ | ☐ |
| 8 | Dayni Moon | ☐ | ☐ | ☐ | À tester | ☐ | ☐ |
| 9 | Inside Clank | ☐ | ☐ | ☐ | À tester | ☐ | ☐ |
| 10 | Quadrona | ☐ | ☐ | ☐ | À tester | ☐ | ☐ |
| 15 | Giant Clank — niveau 4 | ☐ | ☐ | ☐ | N/A | ☐ | ☐ |
| 21 | Giant Clank — niveau 7 | ☐ | ☐ | ☐ | N/A | ☐ | ☐ |
| 22 | Airboard — niveau 3 | ☐ | ☐ | ☐ | N/A | ☐ | ☐ |
| 23 | Airboard — niveau 6 | ☐ | ☐ | ☐ | À tester | ☐ | ☐ |
| 24 | HIG Treehouse | ☐ | ☐ | ☐ | N/A | ☐ | ☐ |

## Critères d’arrêt

Arrêter immédiatement la campagne sur un module si le chargement plante, si Ratchet ne répond plus, si la caméra diverge ou si un checkpoint devient impossible. Noter le profil exact, le module, la zone, le framerate réel et joindre si possible une vidéo chronométrée.

Le profil BASE permet d’isoler le noyau joueur. Le profil SOCLE ne doit être essayé qu’après la réussite du BASE dans le même niveau, afin qu’une erreur caméra ou Titanium ne soit pas attribuée à tort au delta général.