#!/usr/bin/env python3
"""Build the first multi-PRX 60 FPS test pack for Size Matters UCES-00420.

The builder performs signature-based discovery of the common timing core in
the fifteen solo/special-mode PRXs. It never modifies or redistributes game
binaries. LEVEL_02_clean.PRX is used as the Ryllus authority because the copy
inside BIN.zip already contains the 2 -> 1 substep edit.
"""

from __future__ import annotations

import csv
import hashlib
import json
import shutil
import struct
from dataclasses import asdict, dataclass
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parent
SOURCES = HERE / "sources"
BIN_DIR = SOURCES / "BIN"
CLEAN_LEVEL2 = WORKSPACE / "project_sources" / "05-LEVEL_02_clean.PRX"
ARCHIVE_LEVEL2 = BIN_DIR / "LEVEL_02.PRX"
RECOVERED = WORKSPACE / "recovered_full" / "Patch 60 fps - Ratchet & Clank Size Matters (PSP)"
EBOOT = RECOVERED / "UCES00420_EBOOT.BIN"
RCPM = RECOVERED / "RCPM.PRX"
RAM_DUMPS = [
    WORKSPACE / "project_sources" / "01-RAM.dump",
    RECOVERED / "RAM2.dump",
]

VERSION = "v0.1.0-prealpha.1"
PACKAGE_NAME = f"Size_Matters_60FPS_GLOBAL_SOCLE_{VERSION}_UCES00420"
OUT = HERE / PACKAGE_NAME
ZIP_PATH = HERE / f"{PACKAGE_NAME}.zip"

RUNTIME_BASE = 0x09139D00
FILE_BIAS = 0x74
PSP_BASE = 0x08800000
EBOOT_BASE = 0x08804000
HOOK_ADDRESS = 0x08806DA4
HOOK_RUNTIME_VANILLA = 0x0E201CD8
HOOK_PATCHED = 0x0E200800
TABLE_START = 0x08802080
CAVE_END = 0x08804000

LEVEL_NAMES = {
    1: "Pokitaru",
    2: "Ryllus",
    3: "Kalidon",
    4: "Metalis",
    5: "Dreamtime",
    6: "Medical Outpost Omega",
    7: "Challax",
    8: "Dayni Moon",
    9: "Inside Clank",
    10: "Quadrona",
    15: "Giant Clank — niveau 4",
    21: "Giant Clank — niveau 7",
    22: "Airboard — niveau 3",
    23: "Airboard — niveau 6",
    24: "HIG Treehouse",
}

EXPECTED_PRX_SHA256 = {
    1: "d10a81d076fb44987a45314a020cda2f7e8b39f860b957911ca9365464676571",
    2: "0037689a926197969231795c4d6b05980e5e94558394617b21e8b8bcd79bc8aa",
    3: "4b6cf5e41ab9f3f30e182f15752a4d9d264904794ce568582fa78ad8177e8b94",
    4: "6896122ac19973e928303dc94c40fa309b5f06e5fef6ab14f624987035a4dc37",
    5: "af7474d3af87dd392717d45b2be30a3512ab5f6df3f449e1ac15ce9971a75bbb",
    6: "c7953cd34e82fbea8fca4125cd5f30581fa8450b858e454f83968b2cd0fec39c",
    7: "40e236a82cce9be46044a06945dcd0e7aab754e91d1eb7bb75b8040101dc233d",
    8: "c6906ca8805ec805063036429ecc86ce316efdd386641e87fc8c92dd90dad8a8",
    9: "5674dd1a09d43d0a35578a1252ce46035d6f64a139dc2660bb25a941f78e6370",
    10: "07f9010f78cf6f49f8fdad0dbf89ce20375dff600183117605c3ebf231583772",
    15: "cebd5b53f4a7f0b42cc7aec7f7e2e13749089a3dd630a3af1fcccaf81748e70a",
    21: "0e7a7f7d70a70e51081b0471e257f50d3a86f987a5eae546b2a178d2190dd706",
    22: "be7ef86357ee668bb1c194226e4cd2e55920a4f7f375952ffb494c0de5a78986",
    23: "7c8a790eccf722cfd8e5a6e066d17300cf84c1f4068535a6575542229c0f7561",
    24: "a4e3f6496b3d2d238767fbb72b9db274dc5179dbe4d6f71eea2ce1fee22480bf",
}

EXPECTED_EBOOT_SHA256 = "eab4e81e302cff922969ea5fe31f937ba96b18ea8b2f7ee7632038537d00ffdd"
EXPECTED_RCPM_SHA256 = "6ba6787592336d3ef289c94888ebd4853687fe8dcd92fe12914b2d48054e78b1"
EXPECTED_ARCHIVE_LEVEL2_SHA256 = "8b25dc880062912c28adc49b78ce1e90952037ca18db8164e41301530647c7e9"

DISPATCHER_WORDS = [
    (0x08802000, 0x3C080884),
    (0x08802004, 0x8D081120),
    (0x08802008, 0x3C090880),
    (0x0880200C, 0x35292080),
    (0x08802010, 0x8D2A0000),
    (0x08802014, 0x240BFFFF),
    (0x08802018, 0x114B0013),
    (0x0880201C, 0x00000000),
    (0x08802020, 0x8D2B0004),
    (0x08802024, 0x11480006),
    (0x08802028, 0x00000000),
    (0x0880202C, 0x000B60C0),
    (0x08802030, 0x25290008),
    (0x08802034, 0x012C4821),
    (0x08802038, 0x1000FFF5),
    (0x0880203C, 0x00000000),
    (0x08802040, 0x25290008),
    (0x08802044, 0x11600008),
    (0x08802048, 0x00000000),
    (0x0880204C, 0x8D2C0000),
    (0x08802050, 0x8D2D0004),
    (0x08802054, 0xAD8D0000),
    (0x08802058, 0x25290008),
    (0x0880205C, 0x256BFFFF),
    (0x08802060, 0x1000FFF8),
    (0x08802064, 0x00000000),
    (0x08802068, 0x0A201CD8),
    (0x0880206C, 0x00000000),
]

TITANIUM_MARKER = b"X94<TitaniumBolt_Init"
TITANIUM_CODE_PATTERN = (
    0x460F6303,
    0x3C044000,
    0xC64D008C,
    0x44848000,
    0x46106302,
    0x460C6B01,
)


@dataclass
class Section:
    name: str
    addr: int
    offset: int
    size: int


@dataclass
class Patch:
    module_index: int
    module: str
    level: str
    mechanic: str
    address: int
    file_vanilla: int
    runtime_vanilla: int
    patched: int
    profile: str
    evidence: str
    status: str


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def parse_sections(data: bytes) -> dict[str, Section]:
    if data[:6] != b"\x7fELF\x01\x01":
        raise ValueError("ELF32 little-endian attendu")
    e_shoff = struct.unpack_from("<I", data, 0x20)[0]
    e_shentsize = struct.unpack_from("<H", data, 0x2E)[0]
    e_shnum = struct.unpack_from("<H", data, 0x30)[0]
    e_shstrndx = struct.unpack_from("<H", data, 0x32)[0]
    headers = [
        struct.unpack_from("<IIIIIIIIII", data, e_shoff + i * e_shentsize)
        for i in range(e_shnum)
    ]
    shstr = headers[e_shstrndx]
    names = data[shstr[4] : shstr[4] + shstr[5]]

    def cstr(offset: int) -> str:
        end = names.find(b"\0", offset)
        if end < 0:
            end = len(names)
        return names[offset:end].decode("ascii", errors="replace")

    return {
        cstr(h[0]): Section(cstr(h[0]), h[3], h[4], h[5])
        for h in headers
    }


def module_path(index: int) -> Path:
    if index == 2:
        return CLEAN_LEVEL2
    return BIN_DIR / f"LEVEL_{index:02d}.PRX"


def runtime_address(text: Section, word_index: int) -> int:
    return RUNTIME_BASE + text.addr + word_index * 4


def file_offset_for_runtime(address: int) -> int:
    return FILE_BIAS + address - RUNTIME_BASE


def word_at_runtime(data: bytes, address: int) -> int:
    return struct.unpack_from("<I", data, file_offset_for_runtime(address))[0]


def relocated_jump_word(raw_word: int, base: int) -> int:
    opcode = raw_word & 0xFC000000
    if opcode not in (0x08000000, 0x0C000000):
        raise ValueError(f"J/JAL attendu, reçu 0x{raw_word:08X}")
    index = ((raw_word & 0x03FFFFFF) + (base >> 2)) & 0x03FFFFFF
    return opcode | index


def verify_mips26_relocation(data: bytes, address: int, module: str) -> None:
    sections = parse_sections(data)
    rel = sections.get(".rel.text")
    if rel is None or rel.size % 8:
        raise RuntimeError(f"{module}: section .rel.text absente ou invalide")
    target_offset = address - RUNTIME_BASE
    matches = []
    for offset in range(rel.offset, rel.offset + rel.size, 8):
        r_offset, r_info = struct.unpack_from("<II", data, offset)
        if r_offset == target_offset:
            matches.append(r_info)
    if matches != [0x00000004]:
        raise RuntimeError(
            f"{module}: relocation R_MIPS_26 attendue à 0x{address:08X}, reçu {matches}"
        )


def unique(name: str, hits: list[int], module: str) -> int:
    if len(hits) != 1:
        raise RuntimeError(f"{module}: signature {name} trouvée {len(hits)} fois")
    return hits[0]


def scan_core(data: bytes, module: str) -> dict[str, int]:
    sections = parse_sections(data)
    text = sections[".text"]
    if text.offset != FILE_BIAS:
        raise RuntimeError(f"{module}: biais .text inattendu 0x{text.offset:X}")
    code = data[text.offset : text.offset + text.size]
    words = struct.unpack_from(f"<{len(code) // 4}I", code)
    hits: dict[str, list[int]] = {k: [] for k in ("vblank", "substeps", "global_dt", "physics", "camera")}

    for i in range(len(words) - 8):
        if (
            words[i] == 0x14440003
            and words[i + 1] == 0
            and words[i + 2] & 0xFC000000 == 0x0C000000
            and words[i + 3] == 0
            and words[i + 4] == words[i + 2] + 2
            and words[i + 5] == 0
            and words[i + 6] == 0x10000003
        ):
            hits["vblank"].append(runtime_address(text, i + 2))

        if words[i : i + 4] == (0x26310001, 0x2A240002, 0x1480FFEB, 0x00000000):
            hits["substeps"].append(runtime_address(text, i + 1))

        if (
            words[i] == 0x3C043D08
            and words[i + 1] == 0x34848889
            and words[i + 2] & 0xFC000000 == 0x0C000000
            and words[i + 3] == 0x4484A000
        ):
            hits["global_dt"].append(runtime_address(text, i))

        if (
            words[i] == 0x00808025
            and words[i + 1] == 0x46006506
            and words[i + 2] & 0xFFFF0000 == 0x3C040000
            and words[i + 3] & 0xFFFF0000 == 0xAC900000
        ):
            hits["physics"].append(runtime_address(text, i + 1))

        if (
            words[i] == 0x3C043D08
            and words[i + 1] == 0x34848889
            and words[i + 2] == 0x44847800
            and words[i + 3] == 0x460F7382
            and words[i + 6] == 0x3C04BD08
            and words[i + 7] == 0x460F6402
        ):
            positive = runtime_address(text, i)
            negative = runtime_address(text, i + 6)
            hits["camera"].append((positive << 32) | negative)

    camera_pair = unique("camera", hits["camera"], module)
    return {
        "vblank": unique("vblank", hits["vblank"], module),
        "substeps": unique("substeps", hits["substeps"], module),
        "global_dt": unique("global_dt", hits["global_dt"], module),
        "physics": unique("physics", hits["physics"], module),
        "camera_positive": camera_pair >> 32,
        "camera_negative": camera_pair & 0xFFFFFFFF,
    }


def find_all(data: bytes, pattern: bytes, start: int = 0, end: int | None = None) -> list[int]:
    if end is None:
        end = len(data)
    hits = []
    cursor = start
    while True:
        pos = data.find(pattern, cursor, end)
        if pos < 0:
            return hits
        hits.append(pos)
        cursor = pos + 1


def scan_titanium(data: bytes, module: str) -> tuple[int, int] | None:
    sections = parse_sections(data)
    text = sections[".text"]
    marker_hits = find_all(data, TITANIUM_MARKER)
    code_pattern = b"".join(struct.pack("<I", word) for word in TITANIUM_CODE_PATTERN)
    code_hits = find_all(data, code_pattern, text.offset, text.offset + text.size)

    if not marker_hits and not code_hits:
        return None
    if len(marker_hits) != 1 or len(code_hits) != 1:
        raise RuntimeError(
            f"{module}: Titanium incohérent, marqueurs={len(marker_hits)}, code={len(code_hits)}"
        )

    marker_runtime = RUNTIME_BASE + marker_hits[0] - FILE_BIAS
    speed_address = marker_runtime - 0x0C
    factor_address = RUNTIME_BASE + code_hits[0] - FILE_BIAS + 4
    if word_at_runtime(data, speed_address) != 0x3E75C28F:
        raise RuntimeError(f"{module}: vitesse Titanium vanilla inattendue")
    if word_at_runtime(data, factor_address) != 0x3C044000:
        raise RuntimeError(f"{module}: facteur Titanium vanilla inattendu")
    if word_at_runtime(data, speed_address + 4) != 0xBDF5C28F:
        raise RuntimeError(f"{module}: témoin Titanium -0,12 absent")
    return speed_address, factor_address


def build_patches(index: int, data: bytes, addresses: dict[str, int]) -> list[Patch]:
    module = f"LEVEL_{index:02d}.PRX"
    level = LEVEL_NAMES[index]
    status = "VALIDÉ DYNAMIQUEMENT SUR POKITARU" if index == 1 else "PORTAGE STATIQUE — TEST EN JEU REQUIS"
    out = []

    def add(mechanic: str, key: str, file_vanilla: int, runtime_vanilla: int, patched: int, profile: str, evidence: str):
        address = addresses[key]
        actual = word_at_runtime(data, address)
        if actual != file_vanilla:
            raise RuntimeError(
                f"{module}: 0x{address:08X} vaut 0x{actual:08X}, attendu 0x{file_vanilla:08X}"
            )
        out.append(Patch(index, module, level, mechanic, address, file_vanilla, runtime_vanilla, patched, profile, evidence, status))

    vblank_raw = word_at_runtime(data, addresses["vblank"])
    verify_mips26_relocation(data, addresses["vblank"], module)
    add(
        "Déverrouillage VBlank",
        "vblank",
        vblank_raw,
        relocated_jump_word(vblank_raw, RUNTIME_BASE),
        0x00000000,
        "BASE",
        "Signature unique branch/nop/jal/nop/jal+2/nop/branch + relocation R_MIPS_26",
    )
    add("Sous-pas joueur 2 → 1", "substeps", 0x2A240002, 0x2A240002, 0x2A240001, "BASE", "Signature unique de la boucle joueur")
    add("Delta général 1/30 → 1/60", "global_dt", 0x3C043D08, 0x3C043D08, 0x3C043C88, "BASE", "Construction unique 1/30 suivie du registre f20")
    add("Compensation locale du joueur", "physics", 0x46006506, 0x46006506, 0x460C6500, "BASE", "Prologue homologue unique, à 0x140 du sous-pas")
    add("Caméra, branche positive +1/30 → +1/60", "camera_positive", 0x3C043D08, 0x3C043D08, 0x3C043C88, "SOCLE", "Paire caméra +/- unique")
    add("Caméra, branche négative -1/30 → -1/60", "camera_negative", 0x3C04BD08, 0x3C04BD08, 0x3C04BC88, "SOCLE", "Paire caméra +/- unique")

    titanium = scan_titanium(data, module)
    if titanium:
        speed_address, factor_address = titanium
        out.append(Patch(index, module, level, "Titanium Bolt, vitesse 0,24 → 0,12", speed_address, 0x3E75C28F, 0x3E75C28F, 0x3DF5C28F, "SOCLE", "Marqueur X94<TitaniumBolt_Init + témoin -0,12", status))
        out.append(Patch(index, module, level, "Titanium Bolt, facteur 2,0 → 1,0", factor_address, 0x3C044000, 0x3C044000, 0x3C043F80, "SOCLE", "Séquence de code Titanium unique sur six instructions", status))
    return out


def cw_address(address: int) -> int:
    if not PSP_BASE <= address < 0x0A800000:
        raise ValueError(f"Adresse PSP hors plage : 0x{address:08X}")
    return 0x20000000 | (address - PSP_BASE)


def cw_line(address: int, value: int) -> str:
    return f"_L 0x{cw_address(address):08X} 0x{value:08X}"


def profile_tables(all_patches: dict[int, list[Patch]], profile: str, restore: bool = False) -> dict[int, list[tuple[Patch, int]]]:
    tables = {}
    for index, patches in all_patches.items():
        selected = [p for p in patches if p.profile == "BASE" or (profile == "SOCLE" and p.profile == "SOCLE")]
        tables[index] = [(p, p.runtime_vanilla if restore else p.patched) for p in selected]
    return tables


def build_ini(title: str, tables: dict[int, list[tuple[Patch, int]]], restore: bool = False) -> tuple[str, int]:
    total = sum(len(items) for items in tables.values())
    lines = [
        "_S UCES-00420",
        "_G Ratchet & Clank: Size Matters [EU]",
        "",
        f"# {title}",
        f"# Version : {VERSION}. Quinze modules solo/spéciaux, {total} écritures.",
        "# FRONTEND et LEVEL_16–20 (multijoueur/lobby) sont volontairement absents.",
        "# Profil alternatif : redémarrer PPSSPP à froid avant de changer d’INI.",
        "# Le dispatcher applique uniquement la table correspondant au module chargé.",
        "",
        f"_C1 {title}",
        "# Bootstrap seulement sur le hook EBOOT vanilla.",
        "_L 0xC0006DA4 0x0E201CD8",
        "# Dispatcher persistant à 0x08802000.",
    ]
    lines.extend(cw_line(address, value) for address, value in DISPATCHER_WORDS)
    lines.append("")

    cursor = TABLE_START
    for index in sorted(tables):
        items = tables[index]
        lines.extend([
            f"# Module {index}: LEVEL_{index:02d}.PRX — {LEVEL_NAMES[index]} — {len(items)} écritures.",
            cw_line(cursor, index),
            cw_line(cursor + 4, len(items)),
        ])
        cursor += 8
        for patch, value in items:
            action = "restaure" if restore else "patche"
            lines.append(
                f"# {action} 0x{patch.address:08X}: 0x{patch.runtime_vanilla:08X} → 0x{value:08X} — {patch.mechanic}"
            )
            lines.append(cw_line(cursor, patch.address))
            lines.append(cw_line(cursor + 4, value))
            cursor += 8

    lines.extend([
        "# Sentinelle de fin.",
        cw_line(cursor, 0xFFFFFFFF),
        cw_line(cursor + 4, 0x00000000),
        "# Hook écrit en dernier.",
        cw_line(HOOK_ADDRESS, HOOK_PATCHED),
        "",
    ])
    cursor += 8
    if cursor > CAVE_END:
        raise RuntimeError(f"Table trop grande : fin 0x{cursor:08X}")
    if restore:
        lines.extend([
            "_C0 [APRÈS RECHARGEMENT DU MODULE] Retirer le hook du dispatcher",
            "# À utiliser seulement après que le profil RESTORE a chargé le niveau voulu.",
            cw_line(HOOK_ADDRESS, HOOK_RUNTIME_VANILLA),
            "",
        ])
    return "\n".join(lines), cursor


def write_csv(path: Path, rows: list[dict], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def hex_patch(patch: Patch) -> dict:
    row = asdict(patch)
    for key in ("address", "file_vanilla", "runtime_vanilla", "patched"):
        row[key] = f"0x{row[key]:08X}"
    return row


def source_inventory() -> list[dict]:
    rows = []
    for path in sorted(p for p in SOURCES.rglob("*") if p.is_file()):
        if path.name == "straddle.junk":
            role = "ELF rcp1 riche en symboles/debug, référence frontend non patchée"
        elif path.suffix.upper() == ".PRX":
            role = "PRX"
        else:
            role = "WAD/HUD/ressource"
        rows.append({
            "path": path.relative_to(SOURCES).as_posix(),
            "size_bytes": path.stat().st_size,
            "sha256": sha256(path),
            "role": role,
        })
    rows.extend([
        {"path": "AUTHORITY/LEVEL_02_clean.PRX", "size_bytes": CLEAN_LEVEL2.stat().st_size, "sha256": sha256(CLEAN_LEVEL2), "role": "Autorité vanilla Ryllus — non redistribuée"},
        {"path": "AUTHORITY/UCES00420_EBOOT.BIN", "size_bytes": EBOOT.stat().st_size, "sha256": sha256(EBOOT), "role": "Autorité EBOOT — non redistribuée"},
        {"path": "AUTHORITY/RCPM.PRX", "size_bytes": RCPM.stat().st_size, "sha256": sha256(RCPM), "role": "Inventorié, non patché, non redistribué"},
    ])
    return rows


def verify_inputs() -> dict:
    for path in [*map(module_path, LEVEL_NAMES), EBOOT, RCPM, ARCHIVE_LEVEL2, *RAM_DUMPS]:
        if not path.is_file():
            raise FileNotFoundError(path)

    hashes = {index: sha256(module_path(index)) for index in LEVEL_NAMES}
    for index, expected in EXPECTED_PRX_SHA256.items():
        if hashes[index] != expected:
            raise RuntimeError(f"LEVEL_{index:02d}: hash {hashes[index]} != {expected}")
    if sha256(EBOOT) != EXPECTED_EBOOT_SHA256:
        raise RuntimeError("Hash EBOOT inattendu")
    if sha256(RCPM) != EXPECTED_RCPM_SHA256:
        raise RuntimeError("Hash RCPM inattendu")
    if sha256(ARCHIVE_LEVEL2) != EXPECTED_ARCHIVE_LEVEL2_SHA256:
        raise RuntimeError("Hash LEVEL_02.PRX de BIN.zip inattendu")

    clean = CLEAN_LEVEL2.read_bytes()
    archived = ARCHIVE_LEVEL2.read_bytes()
    diffs = [i for i, (a, b) in enumerate(zip(clean, archived)) if a != b]
    if len(clean) != len(archived) or diffs != [0x341D4]:
        raise RuntimeError(f"Différence Ryllus inattendue : tailles {len(clean)}/{len(archived)}, diffs={diffs[:20]}")
    if struct.unpack_from("<I", clean, 0x341D4)[0] != 0x2A240002:
        raise RuntimeError("Valeur propre Ryllus inattendue")
    if struct.unpack_from("<I", archived, 0x341D4)[0] != 0x2A240001:
        raise RuntimeError("La contamination Ryllus attendue n’est pas présente")

    eboot_data = EBOOT.read_bytes()
    raw_hook = struct.unpack_from("<I", eboot_data, FILE_BIAS + HOOK_ADDRESS - EBOOT_BASE)[0]
    if raw_hook != 0x0C000CD8 or relocated_jump_word(raw_hook, EBOOT_BASE) != HOOK_RUNTIME_VANILLA:
        raise RuntimeError("Hook EBOOT vanilla non confirmé")

    cave_checks = []
    for dump in RAM_DUMPS:
        data = dump.read_bytes()
        cave = data[0x2000:0x4000]
        nonzero = sum(byte != 0 for byte in cave)
        if nonzero:
            raise RuntimeError(f"Cave non vide dans {dump.name}: {nonzero} octets")
        live_hook = struct.unpack_from("<I", data, HOOK_ADDRESS - PSP_BASE)[0]
        if live_hook != HOOK_RUNTIME_VANILLA:
            raise RuntimeError(f"Hook RAM inattendu dans {dump.name}: 0x{live_hook:08X}")
        cave_checks.append({"dump": dump.name, "cave_nonzero_bytes": nonzero, "hook": f"0x{live_hook:08X}"})

    return {
        "prx_hashes": {str(k): v for k, v in hashes.items()},
        "eboot_sha256": sha256(EBOOT),
        "rcpm_sha256": sha256(RCPM),
        "archive_level2_sha256": sha256(ARCHIVE_LEVEL2),
        "level2_clean_sha256": sha256(CLEAN_LEVEL2),
        "level2_diff_file_offset": "0x000341D4",
        "level2_diff_runtime_address": "0x0916DE60",
        "level2_clean_word": "0x2A240002",
        "level2_archive_word": "0x2A240001",
        "cave_checks": cave_checks,
    }


def make_docs(all_patches: dict[int, list[Patch]], verification: dict, table_ends: dict[str, int]) -> None:
    titanium_modules = [i for i, ps in all_patches.items() if any("Titanium" in p.mechanic for p in ps)]
    module_rows = []
    for index, patches in all_patches.items():
        module_rows.append(
            f"| `{index}` | `LEVEL_{index:02d}.PRX` | {LEVEL_NAMES[index]} | {sum(p.profile == 'BASE' for p in patches)} | {sum(p.profile == 'SOCLE' for p in patches)} | {'Oui' if index in titanium_modules else 'Absent du module'} | {'Pokitaru validé' if index == 1 else 'Test requis'} |"
        )

    readme = f"""# Size Matters 60 FPS — premier socle global

Version **{VERSION}**, cible **Europe UCES-00420**. Ce paquet contient un seul dispatcher EBOOT capable d’appliquer la bonne table avant le démarrage de chacun des quinze PRX solo ou modes spéciaux.

Le frontend reste à 30 FPS. Les modules `LEVEL_16` à `LEVEL_20`, correspondant au multijoueur et au lobby, ne possèdent aucune table et ne sont donc jamais modifiés.

## Profils

| Fichier | Contenu | Écritures PRX | Usage |
|---|---|---:|---|
| `01_GLOBAL_60FPS_BASE_PREALPHA.ini` | VBlank, sous-pas, delta général, compensation joueur | 60 | Premier témoin global |
| `02_GLOBAL_60FPS_SOCLE_PREALPHA.ini` | Base + caméra + Titanium Bolt lorsqu’il existe | 112 | Profil recommandé pour la campagne de test |
| `03_GLOBAL_SOCLE_RESTORE_NEXT_LOAD.ini` | Valeurs vanilla du socle, choisies par module | 112 | Restauration au prochain chargement |

Ces fichiers sont strictement alternatifs. Un redémarrage complet de PPSSPP est obligatoire avant de remplacer l’un par l’autre, car retirer une coche dans le menu des cheats n’efface ni le hook EBOOT ni les mots déjà écrits en RAM.

## Installation

1. Choisir un seul INI et le renommer `UCES00420.ini`.
2. Le placer dans `PPSSPP/PSP/Cheats`, puis activer les cheats.
3. Démarrer le jeu à froid et entrer normalement dans le niveau depuis le frontend.
4. Ne pas commencer par une savestate prise dans un PRX déjà chargé.

Le dispatcher lit l’index demandé à `0x08841120`, parcourt ses tables à partir de `0x08802080`, puis écrit seulement les valeurs du module correspondant. Les PRX continuent de partager la base runtime `0x09139D00`, mais leurs adresses internes sont différentes.

## Couverture

| Index | PRX | Niveau / rôle | Base | Ajouts socle | Titanium | Validation |
|---:|---|---|---:|---:|---|---|
{chr(10).join(module_rows)}

## Ce qui n’est pas encore inclus

- armes et mods ;
- ennemis, portes, véhicules et objets propres aux niveaux ;
- wrapper global ou remplacements Local JAL ;
- breakables et boulons ordinaires ;
- particules, UI et autres cosmétiques ;
- frontend et multijoueur.

Ces exclusions sont intentionnelles. Le but de cette pré-alpha est de vérifier le noyau temporel dans tout le solo avant d’ajouter les couches déjà séparées sur Pokitaru.

## Avertissement Ryllus

Le `LEVEL_02.PRX` de `BIN.zip` contient déjà `0x2A240001` à l’adresse runtime `0x0916DE60`. Le constructeur a donc utilisé `LEVEL_02_clean.PRX`, qui contient la valeur vanilla `0x2A240002`, pour calculer le patch et la restauration.

## Référence de symboles trouvée

`BIN/straddle.junk` est un ELF de module `rcp1` contenant 2 374 entrées de symboles ainsi que des sections de debug. Sa structure est proche de `FRONTEND.PRX` sans lui être identique ; il est inventorié comme référence future pour le loader et l’interface, mais n’a servi à aucune écriture de cette pré-alpha.

Le paquet ne contient aucun PRX, WAD, EBOOT, dump RAM ou autre donnée du jeu. Il requiert une copie légitime de la version européenne.
"""
    (OUT / "README.md").write_text(readme, encoding="utf-8")

    architecture = f"""# Architecture du dispatcher global

Le hook persistant remplace le `jal 0x08807360` de `0x08806DA4` par un appel à `0x08802000`. Le dispatcher lit l’index du module, applique les couples adresse/valeur correspondants, puis effectue un tail-jump vers la routine vanilla.

La table conserve le format `module_index`, `write_count`, puis `write_count` couples de deux mots. Le profil SOCLE occupe exactement `0x{table_ends['socle'] - TABLE_START:X}` octets entre `0x{TABLE_START:08X}` et `0x{table_ends['socle']:08X}`, ce qui reste très loin de la limite vérifiée `0x{CAVE_END:08X}`.

Les caves `0x08802000–0x08803FFF` étaient entièrement nulles dans les dumps Pokitaru et Ryllus. Le mot live de l’ancien hook était `0x{HOOK_RUNTIME_VANILLA:08X}` dans les deux dumps, tandis que le mot brut de l’EBOOT est relocalisé au chargement.

## Pourquoi les signatures sont fiables

Dans chaque PRX couvert, les signatures VBlank, sous-pas, delta général, compensation joueur et paire caméra n’apparaissent qu’une seule fois. Les quinze ensembles sont structurellement homologues même lorsque leurs adresses ou leurs cibles `jal` diffèrent.

Le Titanium Bolt exige deux correspondances simultanées : le marqueur `X94<TitaniumBolt_Init`, accompagné des constantes `0,20 / 0,24 / -0,12`, et une séquence de six instructions autour du facteur `2,0`. Les deux preuves sont uniques dans onze PRX et absentes ensemble dans les quatre autres.
"""
    (OUT / "docs" / "ARCHITECTURE.md").write_text(architecture, encoding="utf-8")

    validation = f"""# Validation technique statique

## Résultat

- 15 PRX solo ou spéciaux acceptés par hash ;
- 75 signatures structurantes uniques : cinq familles par module ;
- 15 relocations VBlank `R_MIPS_26` confirmées dans les sections `.rel.text` ;
- 60 écritures dans le profil BASE ;
- 112 écritures dans le profil SOCLE et sa restauration ;
- 11 implémentations Titanium Bolt confirmées par code et données ;
- aucune table pour le frontend ou les modules 16–20 ;
- cave EBOOT vide dans les deux dumps disponibles ;
- fin de table BASE : `0x{table_ends['base']:08X}` ;
- fin de table SOCLE : `0x{table_ends['socle']:08X}` ;
- fin de table RESTORE : `0x{table_ends['restore']:08X}`.

La validation prouve la cohérence des fichiers, des valeurs vanilla, des valeurs relocalisées et du format de table. Elle ne remplace pas les essais dynamiques dans les quatorze modules autres que Pokitaru.

## Contamination détectée

`BIN/LEVEL_02.PRX` et `LEVEL_02_clean.PRX` ont la même taille et ne diffèrent que d’un octet, au fichier `0x000341D4`. Le mot propre `0x2A240002` est déjà devenu `0x2A240001` dans l’archive ; aucun autre PRX n’a échoué à son hash attendu.

## Statut des correctifs

Pokitaru conserve le statut validé pour le noyau, la caméra et le Titanium Bolt. Tous les autres niveaux sont des portages statiques forts : ils utilisent des signatures uniques et les mêmes mots vanilla, mais doivent encore être comparés en secondes réelles à 30 et 60 FPS.
"""
    (OUT / "docs" / "VALIDATION_TECHNIQUE.md").write_text(validation, encoding="utf-8")

    tests = [
        "# Matrice de tests dynamiques",
        "",
        "Pour chaque ligne, effectuer un démarrage à froid, entrer dans le niveau sans savestate interne, puis comparer successivement vanilla 30 FPS, 60 FPS BASE et 60 FPS SOCLE. Les mesures doivent être exprimées en secondes ou en distance fixe, pas seulement en impression visuelle.",
        "",
        "| Index | Niveau | Chargement/crash | Course/saut/chute | Caméra | Titanium | Checkpoint | Sortie du niveau |",
        "|---:|---|---|---|---|---|---|---|",
    ]
    for index in LEVEL_NAMES:
        titanium = "À tester" if index in titanium_modules else "N/A"
        tests.append(f"| {index} | {LEVEL_NAMES[index]} | ☐ | ☐ | ☐ | {titanium} | ☐ | ☐ |")
    tests.extend([
        "",
        "## Critères d’arrêt",
        "",
        "Arrêter immédiatement la campagne sur un module si le chargement plante, si Ratchet ne répond plus, si la caméra diverge ou si un checkpoint devient impossible. Noter le profil exact, le module, la zone, le framerate réel et joindre si possible une vidéo chronométrée.",
        "",
        "Le profil BASE permet d’isoler le noyau joueur. Le profil SOCLE ne doit être essayé qu’après la réussite du BASE dans le même niveau, afin qu’une erreur caméra ou Titanium ne soit pas attribuée à tort au delta général.",
    ])
    (OUT / "docs" / "MATRICE_TESTS.md").write_text("\n".join(tests), encoding="utf-8")


def main() -> None:
    verification = verify_inputs()
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    (OUT / "docs").mkdir()
    (OUT / "analysis").mkdir()
    (OUT / "tools").mkdir()

    all_patches: dict[int, list[Patch]] = {}
    signature_map = []
    for index in LEVEL_NAMES:
        path = module_path(index)
        data = path.read_bytes()
        addresses = scan_core(data, path.name)
        patches = build_patches(index, data, addresses)
        all_patches[index] = patches
        signature_map.append({
            "module_index": index,
            "module": f"LEVEL_{index:02d}.PRX",
            "level": LEVEL_NAMES[index],
            **{k: f"0x{v:08X}" for k, v in addresses.items()},
            "titanium_present": any("Titanium" in p.mechanic for p in patches),
            "authoritative_sha256": sha256(path),
        })

    titanium_modules = {i for i, patches in all_patches.items() if any("Titanium" in p.mechanic for p in patches)}
    expected_titanium = {*range(1, 11), 23}
    if titanium_modules != expected_titanium:
        raise RuntimeError(f"Modules Titanium inattendus : {sorted(titanium_modules)}")

    base_tables = profile_tables(all_patches, "BASE")
    socle_tables = profile_tables(all_patches, "SOCLE")
    restore_tables = profile_tables(all_patches, "SOCLE", restore=True)
    base_ini, base_end = build_ini("[PREALPHA] GLOBAL 60 FPS BASE — 15 modules", base_tables)
    socle_ini, socle_end = build_ini("[PREALPHA] GLOBAL 60 FPS SOCLE — caméra + Titanium", socle_tables)
    restore_ini, restore_end = build_ini("[RESTORE] GLOBAL SOCLE — valeurs vanilla au prochain chargement", restore_tables, restore=True)

    (OUT / "01_GLOBAL_60FPS_BASE_PREALPHA.ini").write_text(base_ini, encoding="utf-8")
    (OUT / "02_GLOBAL_60FPS_SOCLE_PREALPHA.ini").write_text(socle_ini, encoding="utf-8")
    (OUT / "03_GLOBAL_SOCLE_RESTORE_NEXT_LOAD.ini").write_text(restore_ini, encoding="utf-8")

    patch_rows = [hex_patch(p) for index in all_patches for p in all_patches[index]]
    patch_fields = list(patch_rows[0])
    write_csv(OUT / "analysis" / "module_patch_map.csv", patch_rows, patch_fields)
    write_csv(OUT / "analysis" / "signature_map.csv", signature_map, list(signature_map[0]))
    inventory = source_inventory()
    write_csv(OUT / "analysis" / "source_inventory_sha256.csv", inventory, list(inventory[0]))

    manifest = {
        "release": VERSION,
        "game": "Ratchet & Clank: Size Matters",
        "region": "Europe",
        "game_id": "UCES-00420",
        "runtime_base": f"0x{RUNTIME_BASE:08X}",
        "frontend_patched": False,
        "multiplayer_patched": False,
        "module_indices": list(LEVEL_NAMES),
        "base_write_count": sum(len(x) for x in base_tables.values()),
        "socle_write_count": sum(len(x) for x in socle_tables.values()),
        "titanium_modules": sorted(titanium_modules),
        "table_ends": {"base": f"0x{base_end:08X}", "socle": f"0x{socle_end:08X}", "restore": f"0x{restore_end:08X}"},
        "verification": verification,
        "modules": signature_map,
        "patches": patch_rows,
        "excluded_layers": ["weapons", "level_specific", "global_wrapper", "local_jal", "breakables", "ordinary_bolts", "cosmetics", "frontend", "multiplayer"],
    }
    (OUT / "patch_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    make_docs(all_patches, verification, {"base": base_end, "socle": socle_end, "restore": restore_end})
    shutil.copy2(__file__, OUT / "tools" / "build_global_socle.py")
    shutil.copy2(HERE / "validate_global_pack.py", OUT / "tools" / "validate_global_pack.py")

    manifest_lines = []
    for path in sorted(p for p in OUT.rglob("*") if p.is_file() and p.name != "MANIFEST_SHA256.txt"):
        manifest_lines.append(f"{sha256(path)}  {path.relative_to(OUT).as_posix()}")
    (OUT / "MANIFEST_SHA256.txt").write_text("\n".join(manifest_lines) + "\n", encoding="utf-8")

    if ZIP_PATH.exists():
        ZIP_PATH.unlink()
    with ZipFile(ZIP_PATH, "w", ZIP_DEFLATED) as zf:
        for path in sorted(p for p in OUT.rglob("*") if p.is_file()):
            zf.write(path, f"{OUT.name}/{path.relative_to(OUT).as_posix()}")

    print(json.dumps({
        "package": str(OUT),
        "zip": str(ZIP_PATH),
        "zip_sha256": sha256(ZIP_PATH),
        "base_writes": sum(len(x) for x in base_tables.values()),
        "socle_writes": sum(len(x) for x in socle_tables.values()),
        "titanium_modules": sorted(titanium_modules),
        "table_end_socle": f"0x{socle_end:08X}",
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
