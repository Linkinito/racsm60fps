#!/usr/bin/env python3
"""Independent structural validator for the global UCES-00420 test pack."""

from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path
from zipfile import ZipFile


PSP_BASE = 0x08800000
TABLE_START = 0x08802080
CAVE_END = 0x08804000
DISPATCHER_WORDS = {
    0x08802000: 0x3C080884,
    0x08802004: 0x8D081120,
    0x08802008: 0x3C090880,
    0x0880200C: 0x35292080,
    0x08802010: 0x8D2A0000,
    0x08802014: 0x240BFFFF,
    0x08802018: 0x114B0013,
    0x0880201C: 0x00000000,
    0x08802020: 0x8D2B0004,
    0x08802024: 0x11480006,
    0x08802028: 0x00000000,
    0x0880202C: 0x000B60C0,
    0x08802030: 0x25290008,
    0x08802034: 0x012C4821,
    0x08802038: 0x1000FFF5,
    0x0880203C: 0x00000000,
    0x08802040: 0x25290008,
    0x08802044: 0x11600008,
    0x08802048: 0x00000000,
    0x0880204C: 0x8D2C0000,
    0x08802050: 0x8D2D0004,
    0x08802054: 0xAD8D0000,
    0x08802058: 0x25290008,
    0x0880205C: 0x256BFFFF,
    0x08802060: 0x1000FFF8,
    0x08802064: 0x00000000,
    0x08802068: 0x0A201CD8,
    0x0880206C: 0x00000000,
}
LINE_RE = re.compile(r"^_L 0x([0-9A-Fa-f]{8}) 0x([0-9A-Fa-f]{8})$")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def decode_cw(code: int) -> int | None:
    if code >> 28 != 2:
        return None
    return PSP_BASE + (code & 0x0FFFFFFF)


def parse_ini(path: Path) -> tuple[dict[int, list[tuple[int, int]]], int, dict[int, int]]:
    memory: dict[int, int] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        match = LINE_RE.match(line)
        if not match:
            continue
        address = decode_cw(int(match.group(1), 16))
        if address is not None:
            memory[address] = int(match.group(2), 16)

    for address, expected in DISPATCHER_WORDS.items():
        if memory.get(address) != expected:
            raise RuntimeError(f"{path.name}: dispatcher 0x{address:08X} incorrect")

    tables: dict[int, list[tuple[int, int]]] = {}
    cursor = TABLE_START
    while True:
        if cursor not in memory or cursor + 4 not in memory:
            raise RuntimeError(f"{path.name}: table tronquée à 0x{cursor:08X}")
        index = memory[cursor]
        count = memory[cursor + 4]
        cursor += 8
        if index == 0xFFFFFFFF:
            if count != 0:
                raise RuntimeError(f"{path.name}: sentinelle invalide")
            break
        if index in tables:
            raise RuntimeError(f"{path.name}: module {index} dupliqué")
        items = []
        for _ in range(count):
            if cursor not in memory or cursor + 4 not in memory:
                raise RuntimeError(f"{path.name}: entrée tronquée à 0x{cursor:08X}")
            items.append((memory[cursor], memory[cursor + 4]))
            cursor += 8
        tables[index] = items

    if cursor > CAVE_END:
        raise RuntimeError(f"{path.name}: table hors cave")
    return tables, cursor, memory


def expected_tables(manifest: dict, profile: str, restore: bool) -> dict[int, list[tuple[int, int]]]:
    tables = {int(index): [] for index in manifest["module_indices"]}
    for patch in manifest["patches"]:
        if patch["profile"] != "BASE" and profile != "SOCLE":
            continue
        index = int(patch["module_index"])
        value = int(patch["runtime_vanilla"], 16) if restore else int(patch["patched"], 16)
        tables[index].append((int(patch["address"], 16), value))
    return tables


def verify_manifest(pack: Path) -> int:
    expected = {}
    for line in (pack / "MANIFEST_SHA256.txt").read_text(encoding="utf-8").splitlines():
        digest, relative = line.split("  ", 1)
        expected[relative] = digest
    actual_files = {
        path.relative_to(pack).as_posix()
        for path in pack.rglob("*")
        if path.is_file() and path.name != "MANIFEST_SHA256.txt"
    }
    if set(expected) != actual_files:
        raise RuntimeError("Le manifeste de fichiers ne couvre pas exactement le paquet")
    for relative, digest in expected.items():
        if sha256(pack / relative) != digest:
            raise RuntimeError(f"Hash de sortie incorrect : {relative}")
    return len(expected)


def verify_zip(pack: Path, zip_path: Path) -> int:
    with ZipFile(zip_path) as zf:
        bad = zf.testzip()
        if bad:
            raise RuntimeError(f"Entrée ZIP corrompue : {bad}")
        names = {name for name in zf.namelist() if not name.endswith("/")}
        expected = {
            f"{pack.name}/{path.relative_to(pack).as_posix()}"
            for path in pack.rglob("*")
            if path.is_file()
        }
        if names != expected:
            raise RuntimeError("Le ZIP ne correspond pas exactement au dossier de sortie")
        forbidden = (".prx", ".wad", ".dump", ".gzf")
        offenders = [name for name in names if name.lower().endswith(forbidden)]
        if offenders:
            raise RuntimeError(f"Binaire du jeu inclus par erreur : {offenders}")
        return len(names)


def main() -> None:
    pack = Path(sys.argv[1]).resolve()
    zip_path = Path(sys.argv[2]).resolve()
    manifest = json.loads((pack / "patch_manifest.json").read_text(encoding="utf-8"))
    cases = [
        ("01_GLOBAL_60FPS_BASE_PREALPHA.ini", "BASE", False, 60),
        ("02_GLOBAL_60FPS_SOCLE_PREALPHA.ini", "SOCLE", False, 112),
        ("03_GLOBAL_SOCLE_RESTORE_NEXT_LOAD.ini", "SOCLE", True, 112),
    ]
    results = []
    for filename, profile, restore, count in cases:
        tables, end, memory = parse_ini(pack / filename)
        expected = expected_tables(manifest, profile, restore)
        if tables != expected:
            raise RuntimeError(f"{filename}: tables différentes du manifeste")
        if sum(len(items) for items in tables.values()) != count:
            raise RuntimeError(f"{filename}: nombre d’écritures incorrect")
        if not restore and memory.get(0x08806DA4) != 0x0E200800:
            raise RuntimeError(f"{filename}: hook final incorrect")
        if set(tables) != {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 21, 22, 23, 24}:
            raise RuntimeError(f"{filename}: périmètre module incorrect")
        results.append({"file": filename, "writes": count, "table_end": f"0x{end:08X}"})

    manifest_files = verify_manifest(pack)
    zip_files = verify_zip(pack, zip_path)
    print(json.dumps({
        "status": "PASS",
        "profiles": results,
        "manifest_files": manifest_files,
        "zip_files": zip_files,
        "zip_sha256": sha256(zip_path),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
