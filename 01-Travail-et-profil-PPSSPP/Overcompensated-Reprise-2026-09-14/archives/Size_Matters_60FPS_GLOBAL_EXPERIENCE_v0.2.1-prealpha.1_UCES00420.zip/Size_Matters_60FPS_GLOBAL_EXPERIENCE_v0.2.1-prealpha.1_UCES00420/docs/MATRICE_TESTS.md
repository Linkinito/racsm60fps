# Matrice de tests — expérience générale

## Parcours prioritaire

1. Cold boot, sauvegarde normale, Pokitaru sans savestate.
2. Tirer chaque arme sans mod puis avec chacun de ses mods actifs ; comparer cadence, portée, durée, DPS et XP au 30 FPS vanilla.
3. Casser plusieurs caisses, observer projection, rebonds, durée des débris et attraction des boulons.
4. Vérifier caméra et déplacements sur une transition complète de niveau.
5. Contrôler level-up de vie, feu, téléporteurs, Bee Mine et shrapnel Agents.
6. Répéter au minimum sur Ryllus, un niveau tardif, un Airboard et Giant Clank.

## Arrêts immédiats

- crash ou écran noir au chargement ;
- arme dont la trajectoire ou la durée est doublée/divisée par deux ;
- breakables figés, gravité excessive ou boulons impossibles à ramasser ;
- animation accélérée par le wrapper ;
- corruption d’inventaire ou de sauvegarde.

Noter le PRX, l’arme/mod, l’état précis, 30 FPS vanilla, 60 FPS patché, backend PPSSPP et présence d’une savestate.
