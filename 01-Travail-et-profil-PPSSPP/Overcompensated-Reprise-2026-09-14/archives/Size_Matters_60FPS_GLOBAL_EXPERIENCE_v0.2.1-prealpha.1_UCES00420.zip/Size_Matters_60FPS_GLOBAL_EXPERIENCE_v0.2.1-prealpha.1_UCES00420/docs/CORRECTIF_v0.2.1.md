# Correctif v0.2.1-prealpha.1

## Cause racine

La v0.2.0 utilisait 77 paires de la forme `0xC0041120 / écriture`. Dans PPSSPP, le type `C` n’est pas une condition portant seulement sur la ligne suivante : c’est une assertion qui termine tout le bloc `_C1` quand elle est fausse. Aucun index de niveau ne peut satisfaire successivement les gardes des quinze modules ; le dispatcher, le dictionnaire, les tables et le hook placés après elles étaient donc inatteignables.

Les corps de caves, placés avant ces gardes, pouvaient malgré tout être visibles en mémoire. C’est pourquoi le profil paraissait actif sans produire le 60 FPS.

## Correction

- remplacement des 77 gardes par des conditions `E` 16 bits avec saut d’une ligne ;
- déplacement des caves dans la partie bootstrap à exécution unique ;
- ajout de quatre sondes à `0x08803FE0–0x08803FEC` ;
- ajout d’une simulation du premier passage CWCheat pour les seize cas d’index ;
- conservation du dispatcher pré-start afin de ne pas réintroduire la course de rafraîchissement d’environ 77 ms.
