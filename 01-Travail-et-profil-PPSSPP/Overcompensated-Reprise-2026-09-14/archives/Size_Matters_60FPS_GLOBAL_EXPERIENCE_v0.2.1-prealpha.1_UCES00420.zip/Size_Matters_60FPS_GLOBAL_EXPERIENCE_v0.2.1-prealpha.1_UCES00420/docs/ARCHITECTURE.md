# Architecture du profil cumulatif

Le hook EBOOT à `0x08806DA4` appelle le dispatcher à `0x08802000`. Celui-ci lit l’index demandé à `0x08841120`, sélectionne une table et applique chaque mot avant de reprendre la routine vanilla `0x08807360`.

Les écritures continues sont gardées par des conditions CWCheat `E` sur les 16 bits bas de `0x08841120`. Une condition fausse saute exactement une ligne. Le seul type `C` actif protège le bootstrap et se trouve après ces écritures ; une fois le hook posé, il évite de réécrire le dispatcher et les tables à chaque rafraîchissement.

Chaque entrée compacte contient huit bits d’index de valeur et vingt-quatre bits d’offset depuis `0x08800000`. Les valeurs sont placées dans un dictionnaire à `0x08802100`. La plus grande table finit avant `0x08802000`.

Les caves armes occupent `0x08802C00–0x08802E9C` et la cave breakables `0x08803000–0x08803094`. Leur dernier saut dépend du PRX : le mot de retour est donc la première écriture de chaque table de module, avant tout hook vers la cave. Les corps de caves sont écrits directement avant l’installation du hook EBOOT.

Les deux dumps gameplay contrôlés contiennent uniquement des zéros sur `0x08800000–0x08803FFF` et le hook vanilla attendu.

Les sondes `0x08803FE0–0x08803FEC` distinguent quatre états : profil interprété, index vu à l’entrée, fin du dispatcher et taille de la table sélectionnée.
