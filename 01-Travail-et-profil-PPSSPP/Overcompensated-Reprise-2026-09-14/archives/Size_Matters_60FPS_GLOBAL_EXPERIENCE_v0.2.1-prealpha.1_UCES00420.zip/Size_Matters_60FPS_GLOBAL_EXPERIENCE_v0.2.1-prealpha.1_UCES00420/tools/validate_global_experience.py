#!/usr/bin/env python3
"""Independent structural and semantic validator for the v0.2.1 global pack."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import struct
from collections import defaultdict
from pathlib import Path
from zipfile import ZipFile


PSP_BASE = 0x08800000
RUNTIME_BASE = 0x09139D00
FILE_BIAS = 0x74
TABLE_START = 0x08800000
TABLE_LIMIT = 0x08802000
DISPATCHER_START = 0x08802000
DICTIONARY_START = 0x08802100
DICTIONARY_LIMIT = 0x08802C00
HOOK_ADDRESS = 0x08806DA4
HOOK_PATCHED = 0x0E200800
HOOK_VANILLA = 0x0E201CD8
PROFILE_MARKER_ADDRESS = 0x08803FE0
DISPATCHER_INDEX_ADDRESS = 0x08803FE4
DISPATCHER_STATE_ADDRESS = 0x08803FE8
DISPATCHER_COUNT_ADDRESS = 0x08803FEC
PROFILE_MARKERS = {
    "BASE": 0xB0210001,
    "SOCLE": 0xB0210002,
    "EXPERIENCE": 0xB0210003,
    "RESTORE": 0xB0210004,
}
MODULE_INDICES = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 15, 21, 22, 23, 24)
FULL_WEAPON_MODULES = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 23, 24)

EXPECTED_DISPATCHER = {
    0x08802000: 0x3C080884,
    0x08802004: 0x8D081120,
    0x08802008: 0x3C180880,
    0x0880200C: 0xAF083FE4,
    0x08802010: 0x24190001,
    0x08802014: 0xAF193FE8,
    0x08802018: 0xAF003FEC,
    0x0880201C: 0x3C090880,
    0x08802020: 0x35290000,
    0x08802024: 0x8D2A0000,
    0x08802028: 0x240BFFFF,
    0x0880202C: 0x114B001D,
    0x08802030: 0x00000000,
    0x08802034: 0x8D2B0004,
    0x08802038: 0x11480006,
    0x0880203C: 0x00000000,
    0x08802040: 0x000B6080,
    0x08802044: 0x25290008,
    0x08802048: 0x012C4821,
    0x0880204C: 0x1000FFF5,
    0x08802050: 0x00000000,
    0x08802054: 0x25290008,
    0x08802058: 0xAF0B3FEC,
    0x0880205C: 0x11600011,
    0x08802060: 0x00000000,
    0x08802064: 0x3C0E0880,
    0x08802068: 0x3C0F0880,
    0x0880206C: 0x35EF2100,
    0x08802070: 0x8D2C0000,
    0x08802074: 0x000C6E02,
    0x08802078: 0x000C6200,
    0x0880207C: 0x000C6202,
    0x08802080: 0x018E6021,
    0x08802084: 0x000D6880,
    0x08802088: 0x01AF6821,
    0x0880208C: 0x8DAD0000,
    0x08802090: 0xAD8D0000,
    0x08802094: 0x25290004,
    0x08802098: 0x256BFFFF,
    0x0880209C: 0x1560FFF4,
    0x088020A0: 0x00000000,
    0x088020A4: 0x24190002,
    0x088020A8: 0xAF193FE8,
    0x088020AC: 0x0A201CD8,
    0x088020B0: 0x00000000,
}

LINE_RE = re.compile(r"^_L 0x([0-9A-Fa-f]{8}) 0x([0-9A-Fa-f]{8})$")
PROFILE_CASES = {
    "01_GLOBAL_60FPS_BASE_PREALPHA.ini": "BASE",
    "02_GLOBAL_60FPS_SOCLE_PREALPHA.ini": "SOCLE",
    "03_GLOBAL_60FPS_EXPERIENCE_PREALPHA.ini": "EXPERIENCE",
    "04_GLOBAL_EXPERIENCE_RESTORE_NEXT_LOAD.ini": "RESTORE",
}
LAYER_ORDER = {
    "BASE": 0,
    "SOCLE": 1,
    "WRAPPER": 2,
    "WEAPONS": 3,
    "BREAKABLES": 4,
    "PARTICLES": 5,
}
PROFILE_LAYERS = {
    "BASE": {"BASE"},
    "SOCLE": {"BASE", "SOCLE"},
    "EXPERIENCE": set(LAYER_ORDER),
    "RESTORE": set(LAYER_ORDER),
}
DYNAMIC_SOURCE_ADDRESSES = {
    0x09408470,
    0x09408478,
    0x0940847C,
    0x094082B4,
    0x094082B8,
    0x094082C0,
    0x094082C4,
}
WEAPON_CAVE_RETURNS = {
    "acid_ballistics": (0x0924138C, 0x30),
    "agent_grenade_ballistics": (0x0924A748, 0x34),
    "shock_timer_a": (0x092A976C, 0x08),
    "shock_timer_b": (0x092A9798, 0x0C),
    "laser_timer": (0x09282B04, 0x08),
    "suck_timers": (0x092B02B4, 0x54),
    "suck_comet_speed": (0x092D4CC8, 0x0C),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def signed16(value: int) -> int:
    return value - 0x10000 if value & 0x8000 else value


def parse_active_lines(path: Path) -> list[tuple[int, int, int]]:
    active = False
    rows = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if line.startswith("_C1"):
            active = True
            continue
        if line.startswith("_C0"):
            active = False
            continue
        match = LINE_RE.match(line)
        if active and match:
            rows.append((line_number, int(match.group(1), 16), int(match.group(2), 16)))
    if not rows:
        raise RuntimeError(f"{path.name}: aucun code actif")
    return rows


def direct_address(code: int) -> int | None:
    if code >> 28 != 2:
        return None
    return PSP_BASE + (code & 0x0FFFFFFF)


def direct_memory(rows: list[tuple[int, int, int]]) -> tuple[dict[int, int], list[tuple[int, int]]]:
    memory = {}
    ordered = []
    for _line, code, value in rows:
        address = direct_address(code)
        if address is None:
            continue
        memory[address] = value
        ordered.append((address, value))
    return memory, ordered


def patch_sort_key(patch: dict) -> tuple[int, int, int, int]:
    if patch["kind"] == "cave_return":
        phase = 0
    elif patch["is_hook"]:
        phase = 2
    else:
        phase = 1
    source = patch["source_address"]
    source_value = int(source, 16) if isinstance(source, str) and source.startswith("0x") else 0
    return phase, LAYER_ORDER[patch["layer"]], int(patch["address"], 16), source_value


def selected_patches(manifest: dict, profile: str) -> dict[int, list[dict]]:
    tables = {index: [] for index in MODULE_INDICES}
    for patch in manifest["patches"]:
        if patch["layer"] not in PROFILE_LAYERS[profile]:
            continue
        if profile == "RESTORE" and not patch["restore"]:
            continue
        tables[int(patch["module_index"])].append(patch)
    for index in tables:
        tables[index].sort(key=patch_sort_key)
    return tables


def expected_value(patch: dict, profile: str) -> int:
    key = "runtime_vanilla" if profile == "RESTORE" else "patched"
    return int(patch[key], 16)


def parse_dictionary(memory: dict[int, int], count: int, filename: str) -> list[int]:
    values = []
    for index in range(count):
        address = DICTIONARY_START + index * 4
        if address not in memory:
            raise RuntimeError(f"{filename}: dictionnaire tronqué à 0x{address:08X}")
        values.append(memory[address])
    if DICTIONARY_START + count * 4 > DICTIONARY_LIMIT:
        raise RuntimeError(f"{filename}: dictionnaire dans les caves")
    return values


def parse_compact_tables(
    memory: dict[int, int], dictionary: list[int], filename: str
) -> tuple[dict[int, list[tuple[int, int, int]]], int]:
    tables = {}
    cursor = TABLE_START
    while True:
        if cursor not in memory or cursor + 4 not in memory:
            raise RuntimeError(f"{filename}: en-tête de table manquant à 0x{cursor:08X}")
        module = memory[cursor]
        count = memory[cursor + 4]
        cursor += 8
        if module == 0xFFFFFFFF:
            if count != 0:
                raise RuntimeError(f"{filename}: sentinelle invalide")
            break
        if module in tables:
            raise RuntimeError(f"{filename}: module {module} dupliqué")
        items = []
        for _ in range(count):
            if cursor not in memory:
                raise RuntimeError(f"{filename}: table tronquée à 0x{cursor:08X}")
            packed = memory[cursor]
            value_id = packed >> 24
            if value_id >= len(dictionary):
                raise RuntimeError(f"{filename}: index dictionnaire {value_id} hors plage")
            address = PSP_BASE + (packed & 0xFFFFFF)
            items.append((address, dictionary[value_id], value_id))
            cursor += 4
        tables[module] = items
    if cursor > TABLE_LIMIT:
        raise RuntimeError(f"{filename}: table hors limite 0x{cursor:08X}")
    return tables, cursor


def parse_continuous_pairs(
    rows: list[tuple[int, int, int]], filename: str
) -> list[tuple[int, int, int]]:
    output = []
    index = 0
    while index < len(rows):
        line, code, argument = rows[index]
        code_type = code >> 28
        if code_type == 0xC:
            condition_address = PSP_BASE + (code & 0x0FFFFFFF)
            if condition_address != HOOK_ADDRESS:
                raise RuntimeError(
                    f"{filename}:{line}: type C interdit hors garde bootstrap "
                    f"(0x{condition_address:08X})"
                )
            index += 1
            continue
        if code_type != 0xE:
            index += 1
            continue
        if code >> 24 != 0xE0:
            raise RuntimeError(f"{filename}:{line}: garde continue non 16 bits")
        if argument >> 28 != 0:
            raise RuntimeError(f"{filename}:{line}: garde continue non égalité")
        condition_address = PSP_BASE + (argument & 0x0FFFFFFF)
        if condition_address != 0x08841120:
            raise RuntimeError(f"{filename}: condition inconnue 0x{condition_address:08X}")
        skip_lines = (code >> 16) & 0xFFF
        if skip_lines != 1:
            raise RuntimeError(f"{filename}:{line}: saut E non borné à une ligne ({skip_lines})")
        if index + 1 >= len(rows):
            raise RuntimeError(f"{filename}: condition finale sans écriture")
        _next_line, next_code, next_value = rows[index + 1]
        address = direct_address(next_code)
        if address is None:
            raise RuntimeError(f"{filename}: condition module non suivie d’une écriture 32 bits")
        output.append((code & 0xFFFF, address, next_value))
        index += 2
    return output


def simulate_cwcheat_first_pass(
    rows: list[tuple[int, int, int]], module: int, filename: str
) -> tuple[dict[int, int], bool]:
    """Execute the subset of CWCheat used by the pack with PPSSPP semantics."""
    memory = {
        0x08841120: module,
        HOOK_ADDRESS: HOOK_VANILLA,
    }
    index = 0
    while index < len(rows):
        line, code, argument = rows[index]
        index += 1
        code_type = code >> 28
        if code_type == 0x2:
            memory[PSP_BASE + (code & 0x0FFFFFFF)] = argument
        elif code_type == 0xC:
            address = PSP_BASE + (code & 0x0FFFFFFF)
            if memory.get(address, 0) != argument:
                return memory, False
        elif code_type == 0xE:
            if code >> 24 != 0xE0 or argument >> 28 != 0:
                raise RuntimeError(f"{filename}:{line}: variante E non simulée")
            address = PSP_BASE + (argument & 0x0FFFFFFF)
            expected = code & 0xFFFF
            skip_lines = (code >> 16) & 0xFFF
            if (memory.get(address, 0) & 0xFFFF) != expected:
                index += skip_lines
        else:
            raise RuntimeError(f"{filename}:{line}: type CWCheat non simulé 0x{code_type:X}")
    return memory, True


def expected_tables(
    selected: dict[int, list[dict]], profile: str
) -> tuple[dict[int, list[tuple[int, int]]], list[tuple[int, int, int]]]:
    compact = {}
    continuous = []
    for index in MODULE_INDICES:
        compact[index] = []
        for patch in selected[index]:
            item = (int(patch["address"], 16), expected_value(patch, profile))
            if patch["continuous"]:
                continuous.append((index, item[0], item[1]))
            else:
                compact[index].append(item)
    return compact, continuous


def emulate_dispatcher(
    direct: dict[int, int], tables: dict[int, list[tuple[int, int, int]]], module: int
) -> list[tuple[int, int]]:
    memory = dict(direct)
    memory[0x08841120] = module
    registers = [0] * 32
    pc = DISPATCHER_START
    writes = []
    steps = 0
    while True:
        steps += 1
        if steps > 10000:
            raise RuntimeError("Boucle infinie du dispatcher")
        word = memory.get(pc)
        if word is None:
            raise RuntimeError(f"Instruction absente à 0x{pc:08X}")
        opcode = word >> 26
        rs = (word >> 21) & 31
        rt = (word >> 16) & 31
        immediate = word & 0xFFFF
        if opcode == 0:
            rd = (word >> 11) & 31
            shift = (word >> 6) & 31
            function = word & 63
            if word == 0:
                pass
            elif function == 0:
                registers[rd] = (registers[rt] << shift) & 0xFFFFFFFF
            elif function == 2:
                registers[rd] = (registers[rt] & 0xFFFFFFFF) >> shift
            elif function == 0x21:
                registers[rd] = (registers[rs] + registers[rt]) & 0xFFFFFFFF
            else:
                raise RuntimeError(f"SPECIAL non géré 0x{word:08X}")
            pc += 4
        elif opcode == 0x0F:
            registers[rt] = immediate << 16
            pc += 4
        elif opcode == 0x0D:
            registers[rt] = registers[rs] | immediate
            pc += 4
        elif opcode == 0x09:
            registers[rt] = (registers[rs] + signed16(immediate)) & 0xFFFFFFFF
            pc += 4
        elif opcode == 0x23:
            address = (registers[rs] + signed16(immediate)) & 0xFFFFFFFF
            registers[rt] = memory.get(address, 0)
            pc += 4
        elif opcode == 0x2B:
            address = (registers[rs] + signed16(immediate)) & 0xFFFFFFFF
            value = registers[rt] & 0xFFFFFFFF
            memory[address] = value
            writes.append((address, value))
            pc += 4
        elif opcode in (4, 5):
            if memory.get(pc + 4) != 0:
                raise RuntimeError(f"Delay slot de branche non nul à 0x{pc + 4:08X}")
            equal = registers[rs] == registers[rt]
            taken = equal if opcode == 4 else not equal
            pc = pc + 4 + (signed16(immediate) << 2) if taken else pc + 8
        elif opcode == 2:
            if memory.get(pc + 4) != 0:
                raise RuntimeError(f"Delay slot de J non nul à 0x{pc + 4:08X}")
            target = ((pc + 4) & 0xF0000000) | ((word & 0x03FFFFFF) << 2)
            if target != 0x08807360:
                raise RuntimeError(f"Tail jump inattendu 0x{target:08X}")
            break
        else:
            raise RuntimeError(f"Opcode non géré 0x{word:08X} à 0x{pc:08X}")
        registers[0] = 0
    selected = [(address, value) for address, value, _id in tables.get(module, [])]
    expected = [
        (DISPATCHER_INDEX_ADDRESS, module),
        (DISPATCHER_STATE_ADDRESS, 1),
        (DISPATCHER_COUNT_ADDRESS, 0),
    ]
    if module in tables:
        expected.append((DISPATCHER_COUNT_ADDRESS, len(tables[module])))
    expected.extend(selected)
    expected.append((DISPATCHER_STATE_ADDRESS, 2))
    if writes != expected:
        raise RuntimeError(
            f"Dispatcher module {module}: écritures simulées divergentes\n"
            f"attendu={expected[:8]}... ({len(expected)})\n"
            f"obtenu={writes[:8]}... ({len(writes)})"
        )
    return selected


def verify_profile(pack: Path, manifest: dict, filename: str, profile: str) -> dict:
    path = pack / filename
    rows = parse_active_lines(path)
    memory, ordered_direct = direct_memory(rows)
    for address, expected in EXPECTED_DISPATCHER.items():
        if memory.get(address) != expected:
            raise RuntimeError(f"{filename}: dispatcher 0x{address:08X} incorrect")
    if ordered_direct[-1] != (HOOK_ADDRESS, HOOK_PATCHED):
        raise RuntimeError(f"{filename}: hook EBOOT non écrit en dernier")

    metadata = next(item for item in manifest["profiles"] if item["file"] == filename)
    dictionary = parse_dictionary(memory, int(metadata["dictionary_values"]), filename)
    tables, table_end = parse_compact_tables(memory, dictionary, filename)
    if set(tables) != set(MODULE_INDICES):
        raise RuntimeError(f"{filename}: périmètre modules incorrect")

    selected = selected_patches(manifest, profile)
    expected_compact, expected_continuous = expected_tables(selected, profile)
    decoded = {
        index: [(address, value) for address, value, _value_id in tables[index]]
        for index in MODULE_INDICES
    }
    if decoded != expected_compact:
        raise RuntimeError(f"{filename}: tables compactes différentes du manifeste")
    actual_continuous = parse_continuous_pairs(rows, filename)
    if actual_continuous != expected_continuous:
        raise RuntimeError(f"{filename}: écritures continues différentes du manifeste")
    expected_marker = PROFILE_MARKERS[profile]
    if memory.get(PROFILE_MARKER_ADDRESS) != expected_marker:
        raise RuntimeError(f"{filename}: marqueur de profil absent ou incorrect")

    cw_simulations = 0
    for module in (0, *MODULE_INDICES):
        simulated, reached_end = simulate_cwcheat_first_pass(rows, module, filename)
        if not reached_end:
            raise RuntimeError(
                f"{filename}: le premier passage CWCheat s’arrête avant la fin pour le module {module}"
            )
        if simulated.get(HOOK_ADDRESS) != HOOK_PATCHED:
            raise RuntimeError(f"{filename}: bootstrap non atteint pour le module {module}")
        if simulated.get(PROFILE_MARKER_ADDRESS) != expected_marker:
            raise RuntimeError(f"{filename}: garde E avale le marqueur pour le module {module}")
        for expected_module, address, value in expected_continuous:
            if expected_module == module and simulated.get(address) != value:
                raise RuntimeError(
                    f"{filename}: maintien continu absent module {module} à 0x{address:08X}"
                )
        cw_simulations += 1

    logical_count = sum(len(items) for items in selected.values())
    compact_count = sum(len(items) for items in expected_compact.values())
    if logical_count != int(metadata["writes"]):
        raise RuntimeError(f"{filename}: compteur logique incorrect")
    if compact_count != int(metadata["compact_writes"]):
        raise RuntimeError(f"{filename}: compteur compact incorrect")
    if len(actual_continuous) != int(metadata["continuous_writes"]):
        raise RuntimeError(f"{filename}: compteur continu incorrect")
    if table_end != int(metadata["table_end"], 16):
        raise RuntimeError(f"{filename}: fin de table incorrecte")

    cave_static = {
        int(item["address"], 16): int(item["word"], 16)
        for cave in manifest["caves"]
        for item in cave["static_words"]
    }
    cave_returns = {int(cave["return_word_address"], 16) for cave in manifest["caves"]}
    if profile == "EXPERIENCE":
        for address, expected in cave_static.items():
            if memory.get(address) != expected:
                raise RuntimeError(f"{filename}: cave statique 0x{address:08X} incorrecte")
        for address in cave_returns:
            if address in memory:
                raise RuntimeError(f"{filename}: retour dynamique 0x{address:08X} réécrit en continu")
    else:
        offenders = set(memory) & (set(cave_static) | cave_returns)
        if offenders:
            raise RuntimeError(f"{filename}: caves inattendues {sorted(offenders)}")

    for module in (0, *MODULE_INDICES):
        emulate_dispatcher(memory, tables, module)
    return {
        "file": filename,
        "profile": profile,
        "logical_writes": logical_count,
        "compact_writes": compact_count,
        "continuous_writes": len(actual_continuous),
        "dictionary_values": len(dictionary),
        "table_end": f"0x{table_end:08X}",
        "dispatcher_emulations": len(MODULE_INDICES) + 1,
        "cwcheat_first_pass_simulations": cw_simulations,
        "profile_marker": f"0x{expected_marker:08X}",
    }


def module_path(workspace: Path, index: int) -> Path:
    if index == 2:
        return workspace / "project_sources" / "05-LEVEL_02_clean.PRX"
    return workspace / "global_patch_work" / "sources" / "BIN" / f"LEVEL_{index:02d}.PRX"


def relocation_types(data: bytes) -> dict[int, int]:
    shoff = struct.unpack_from("<I", data, 0x20)[0]
    shentsize = struct.unpack_from("<H", data, 0x2E)[0]
    shnum = struct.unpack_from("<H", data, 0x30)[0]
    shstrndx = struct.unpack_from("<H", data, 0x32)[0]
    headers = [
        struct.unpack_from("<IIIIIIIIII", data, shoff + i * shentsize)
        for i in range(shnum)
    ]
    shstr = headers[shstrndx]
    names = data[shstr[4] : shstr[4] + shstr[5]]

    def name(offset: int) -> str:
        end = names.find(b"\0", offset)
        return names[offset:end].decode("ascii", errors="replace")

    output = {}
    for header in headers:
        if not name(header[0]).startswith(".rel") or header[9] != 8:
            continue
        for cursor in range(header[4], header[4] + header[5], 8):
            address, info = struct.unpack_from("<II", data, cursor)
            output[address] = info & 0xFF
    return output


def relocated_jump(raw: int) -> int:
    return (raw & 0xFC000000) | (((raw & 0x03FFFFFF) + (RUNTIME_BASE >> 2)) & 0x03FFFFFF)


def verify_prx_originals(workspace: Path, manifest: dict) -> dict:
    by_module = defaultdict(list)
    for patch in manifest["patches"]:
        if patch["kind"] != "cave_return":
            by_module[int(patch["module_index"])].append(patch)
    checked = 0
    relocated = 0
    continuous = 0
    for index in MODULE_INDICES:
        data = module_path(workspace, index).read_bytes()
        relocs = relocation_types(data)
        for patch in by_module[index]:
            address = int(patch["address"], 16)
            offset = FILE_BIAS + address - RUNTIME_BASE
            if not 0 <= offset <= len(data) - 4:
                raise RuntimeError(f"LEVEL_{index:02d}: adresse hors PRX 0x{address:08X}")
            raw = struct.unpack_from("<I", data, offset)[0]
            expected_file = int(patch["file_vanilla"], 16)
            if raw != expected_file:
                raise RuntimeError(
                    f"LEVEL_{index:02d} 0x{address:08X}: PRX 0x{raw:08X}, "
                    f"manifeste 0x{expected_file:08X}"
                )
            expected_runtime = int(patch["runtime_vanilla"], 16)
            relocation = relocs.get(address - RUNTIME_BASE, 0)
            if relocation == 4:
                if relocated_jump(raw) != expected_runtime:
                    raise RuntimeError(f"LEVEL_{index:02d}: restauration MIPS26 invalide")
                relocated += 1
            elif patch["continuous"]:
                source_address = int(patch["source_address"], 16)
                if source_address not in DYNAMIC_SOURCE_ADDRESSES or raw != 0:
                    raise RuntimeError(f"LEVEL_{index:02d}: champ continu non autorisé")
                continuous += 1
            elif raw != expected_runtime:
                raise RuntimeError(f"LEVEL_{index:02d}: vanilla runtime incohérent")
            checked += 1
    return {
        "prx_words_checked": checked,
        "mips26_relocations_checked": relocated,
        "runtime_initialized_words_checked": continuous,
    }


def verify_cave_returns(manifest: dict) -> dict:
    patches = manifest["patches"]
    by_module_source = {
        (int(patch["module_index"]), int(patch["source_address"], 16)): patch
        for patch in patches
        if patch["kind"] != "cave_return"
    }
    cave_returns = [patch for patch in patches if patch["kind"] == "cave_return"]
    weapon_checked = 0
    breakable_checked = 0
    for patch in cave_returns:
        index = int(patch["module_index"])
        word = int(patch["patched"], 16)
        if word >> 26 != 2:
            raise RuntimeError("Retour de cave sans opcode J")
        target = (word & 0x03FFFFFF) << 2
        if patch["category"] == "Retour de cave arme":
            source_hook, delta = WEAPON_CAVE_RETURNS[patch["mechanic"]]
            hook_patch = by_module_source[(index, source_hook)]
            expected = int(hook_patch["address"], 16) + delta
            weapon_checked += 1
        else:
            hook_patch = by_module_source[(index, 0x0916202C)]
            expected = int(hook_patch["address"], 16) + 0x6C
            breakable_checked += 1
        if target != expected:
            raise RuntimeError(
                f"LEVEL_{index:02d}: retour cave 0x{target:08X}, attendu 0x{expected:08X}"
            )
    if weapon_checked != 7 * len(FULL_WEAPON_MODULES) or breakable_checked != len(MODULE_INDICES):
        raise RuntimeError("Nombre de retours de cave inattendu")
    return {"weapon_cave_returns": weapon_checked, "breakable_cave_returns": breakable_checked}


def verify_crosscheck(pack: Path) -> dict:
    path = pack / "analysis" / "known_weapon_crosscheck.csv"
    rows = list(__import__("csv").DictReader(path.open(encoding="utf-8")))
    if len(rows) != 122 or any(row["status"] != "MATCH" for row in rows):
        raise RuntimeError("Contre-vérification armes inattendue")
    if any(row["expected_address"] != row["mapped_address"] for row in rows):
        raise RuntimeError("Adresse connue divergente")
    return {"known_weapon_matches": len(rows)}


def verify_file_manifest(pack: Path) -> dict:
    manifest_path = pack / "MANIFEST_SHA256.txt"
    expected = {}
    for line in manifest_path.read_text(encoding="utf-8").splitlines():
        digest, relative = line.split("  ", 1)
        expected[relative] = digest
    actual = {
        path.relative_to(pack).as_posix()
        for path in pack.rglob("*")
        if path.is_file() and path.name != "MANIFEST_SHA256.txt"
    }
    if set(expected) != actual:
        raise RuntimeError("MANIFEST_SHA256 ne couvre pas exactement le paquet")
    for relative, digest in expected.items():
        if sha256(pack / relative) != digest:
            raise RuntimeError(f"Hash incorrect : {relative}")
    return {"manifested_files": len(expected)}


def verify_zip(pack: Path, zip_path: Path) -> dict:
    with ZipFile(zip_path) as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"ZIP corrompu : {bad}")
        names = {name for name in archive.namelist() if not name.endswith("/")}
        expected = {
            f"{pack.name}/{path.relative_to(pack).as_posix()}"
            for path in pack.rglob("*")
            if path.is_file()
        }
        if names != expected:
            raise RuntimeError("Le ZIP ne correspond pas au dossier de sortie")
        forbidden = (".prx", ".wad", ".dump", ".gzf", ".bin")
        offenders = [name for name in names if name.lower().endswith(forbidden)]
        if offenders:
            raise RuntimeError(f"Binaire du jeu inclus : {offenders}")
    return {"zip_files": len(names), "zip_sha256": sha256(zip_path), "zip_size": zip_path.stat().st_size}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("pack", type=Path)
    parser.add_argument("zip", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    pack = args.pack.resolve()
    zip_path = args.zip.resolve()
    workspace = pack.parent.parent
    manifest = json.loads((pack / "patch_manifest.json").read_text(encoding="utf-8"))

    profiles = [
        verify_profile(pack, manifest, filename, profile)
        for filename, profile in PROFILE_CASES.items()
    ]
    result = {
        "status": "PASS",
        "package": pack.name,
        "profiles": profiles,
        **verify_prx_originals(workspace, manifest),
        **verify_cave_returns(manifest),
        **verify_crosscheck(pack),
        **verify_file_manifest(pack),
        **verify_zip(pack, zip_path),
    }
    rendered = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.report:
        args.report.resolve().write_text(rendered, encoding="utf-8")
    print(rendered, end="")


if __name__ == "__main__":
    main()
