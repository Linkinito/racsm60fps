#!/usr/bin/env python3
"""Build the cumulative global 60 FPS experience pack for UCES-00420.

The script ports the validated Pokitaru timing signatures to the fifteen
solo/special-mode PRXs, installs a compact pre-start dispatcher, and emits
CWCheat profiles only. It never modifies or redistributes game binaries.
"""

from __future__ import annotations

import csv
import hashlib
import json
import shutil
import struct
import sys
from collections import defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

import build_global_socle as socle_v1


HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parent
SOURCES = HERE / "sources"
BIN_DIR = SOURCES / "BIN"
CLEAN_LEVEL2 = WORKSPACE / "project_sources" / "05-LEVEL_02_clean.PRX"
RECOVERED = WORKSPACE / "recovered_full" / "Patch 60 fps - Ratchet & Clank Size Matters (PSP)"
WEAPON_MANIFEST = RECOVERED / "pokitaru_weapon_patch_manifest_v2.json"
KNOWN_WEAPON_CSV = RECOVERED / "known_weapon_patch_candidates.csv"

VERSION = "v0.2.1-prealpha.1"
PACKAGE_NAME = f"Size_Matters_60FPS_GLOBAL_EXPERIENCE_{VERSION}_UCES00420"
OUT = HERE / PACKAGE_NAME
ZIP_PATH = HERE / f"{PACKAGE_NAME}.zip"

RUNTIME_BASE = 0x09139D00
PSP_BASE = 0x08800000
HOOK_ADDRESS = 0x08806DA4
HOOK_RUNTIME_VANILLA = 0x0E201CD8
HOOK_PATCHED = 0x0E200800
TABLE_START = 0x08800000
TABLE_LIMIT = 0x08802000
DISPATCHER_START = 0x08802000
DICTIONARY_START = 0x08802100
DICTIONARY_LIMIT = 0x08802C00
PROFILE_MARKER_ADDRESS = 0x08803FE0
DISPATCHER_INDEX_ADDRESS = 0x08803FE4
DISPATCHER_STATE_ADDRESS = 0x08803FE8
DISPATCHER_COUNT_ADDRESS = 0x08803FEC
PROFILE_MARKERS = {
    "BASE": 0xB0210001,
    "SOCLE": 0xB0210002,
    "EXPERIENCE": 0xB0210003,
    "RESTORE": 0xB0210004,
}
CAVE_LIMIT = 0x08804000

MODULE_INDICES = tuple(socle_v1.LEVEL_NAMES)
FULL_WEAPON_MODULES = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 23, 24)
LACERATOR_ONLY_MODULES = (22,)
BOLT_MODULES = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 24)
TELEPORTER_MODULES = (1, 2, 3, 4, 7, 8, 9, 10)
FIRE_MODULES = (1, 4)
DYNAMIC_RUNTIME_ADDRESSES = {
    0x09408470,
    0x09408478,
    0x0940847C,
    0x094082B4,
    0x094082B8,
    0x094082C0,
    0x094082C4,
}


@dataclass(frozen=True)
class Section:
    name: str
    addr: int
    offset: int
    size: int
    entsize: int


class ElfImage:
    """Small ELF32/PRX reader with relocation-aware signature support."""

    MATCH_SECTIONS = (".text", ".rodata", ".data")

    def __init__(self, path: Path):
        self.path = path
        self.data = path.read_bytes()
        if self.data[:6] != b"\x7fELF\x01\x01":
            raise ValueError(f"{path}: ELF32 little-endian attendu")
        shoff = struct.unpack_from("<I", self.data, 0x20)[0]
        shentsize = struct.unpack_from("<H", self.data, 0x2E)[0]
        shnum = struct.unpack_from("<H", self.data, 0x30)[0]
        shstrndx = struct.unpack_from("<H", self.data, 0x32)[0]
        headers = [
            struct.unpack_from("<IIIIIIIIII", self.data, shoff + i * shentsize)
            for i in range(shnum)
        ]
        shstr = headers[shstrndx]
        names = self.data[shstr[4] : shstr[4] + shstr[5]]

        def section_name(offset: int) -> str:
            end = names.find(b"\0", offset)
            if end < 0:
                end = len(names)
            return names[offset:end].decode("ascii", errors="replace")

        self.sections = {
            section_name(h[0]): Section(section_name(h[0]), h[3], h[4], h[5], h[9])
            for h in headers
        }
        self.relocations: dict[int, int] = {}
        for name, section in self.sections.items():
            if not name.startswith(".rel") or section.entsize != 8:
                continue
            for cursor in range(section.offset, section.offset + section.size, 8):
                address, info = struct.unpack_from("<II", self.data, cursor)
                self.relocations[address] = info & 0xFF

        self.words_by_section: dict[str, tuple[int, ...]] = {}
        self.word_indices: dict[str, dict[int, list[int]]] = {}
        for name in self.MATCH_SECTIONS:
            section = self.sections[name]
            words = struct.unpack_from(f"<{section.size // 4}I", self.data, section.offset)
            self.words_by_section[name] = words
            indices: dict[int, list[int]] = defaultdict(list)
            for index, word in enumerate(words):
                indices[word].append(index)
            self.word_indices[name] = dict(indices)

    def section_for_vaddr(self, vaddr: int) -> Section:
        for name in self.MATCH_SECTIONS:
            section = self.sections[name]
            if section.addr <= vaddr < section.addr + section.size:
                return section
        raise KeyError(f"{self.path.name}: adresse PRX 0x{vaddr:08X} hors sections mappées")

    def word_at_runtime(self, address: int) -> int:
        vaddr = address - RUNTIME_BASE
        section = self.section_for_vaddr(vaddr)
        return struct.unpack_from("<I", self.data, section.offset + vaddr - section.addr)[0]

    def raw_word_at_vaddr(self, vaddr: int) -> int:
        section = self.section_for_vaddr(vaddr)
        return struct.unpack_from("<I", self.data, section.offset + vaddr - section.addr)[0]

    def all_offsets(self, pattern: bytes, section_name: str | None = None) -> list[int]:
        if section_name is None:
            start, end = 0, len(self.data)
        else:
            section = self.sections[section_name]
            start, end = section.offset, section.offset + section.size
        hits = []
        cursor = start
        while True:
            position = self.data.find(pattern, cursor, end)
            if position < 0:
                return hits
            hits.append(position)
            cursor = position + 1


def module_path(index: int) -> Path:
    if index == 2:
        return CLEAN_LEVEL2
    return BIN_DIR / f"LEVEL_{index:02d}.PRX"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def normalize_word(word: int, relocation_type: int) -> int:
    if relocation_type in (2, 3):
        return 0xD0000000 | relocation_type
    if relocation_type in (1, 5, 6):
        return word & 0xFFFF0000
    if relocation_type == 4:
        return word & 0xFC000000
    if relocation_type:
        return 0xE0000000 | relocation_type
    if word >> 26 in (2, 3):
        return word & 0xFC000000
    return word


@dataclass(frozen=True)
class Match:
    source_address: int
    target_address: int
    section: str
    score: float
    margin: float
    candidates: int


class SignatureMapper:
    def __init__(self, images: dict[int, ElfImage], radius: int = 24):
        self.images = images
        self.source = images[1]
        self.radius = radius
        self.cache: dict[tuple[int, int], Match] = {}

    def match(self, source_address: int, module_index: int) -> Match:
        key = (source_address, module_index)
        if key in self.cache:
            return self.cache[key]
        if module_index == 1:
            section = self.source.section_for_vaddr(source_address - RUNTIME_BASE)
            result = Match(source_address, source_address, section.name, 1.0, 1.0, 1)
            self.cache[key] = result
            return result

        source_vaddr = source_address - RUNTIME_BASE
        source_section = self.source.section_for_vaddr(source_vaddr)
        source_words = self.source.words_by_section[source_section.name]
        source_index = (source_vaddr - source_section.addr) // 4
        original = source_words[source_index]
        target = self.images[module_index]
        target_section = target.sections[source_section.name]
        target_words = target.words_by_section[source_section.name]
        candidates = target.word_indices[source_section.name].get(original, [])
        scored: list[tuple[float, int]] = []
        for candidate in candidates:
            score = 0.0
            total = 0.0
            for delta in range(-self.radius, self.radius + 1):
                if delta == 0:
                    continue
                source_pos = source_index + delta
                target_pos = candidate + delta
                if not (0 <= source_pos < len(source_words) and 0 <= target_pos < len(target_words)):
                    continue
                source_at = source_section.addr + source_pos * 4
                target_at = target_section.addr + target_pos * 4
                source_word = normalize_word(
                    source_words[source_pos], self.source.relocations.get(source_at, 0)
                )
                target_word = normalize_word(
                    target_words[target_pos], target.relocations.get(target_at, 0)
                )
                weight = 0.15 if source_word == 0 else 1.0
                total += weight
                if source_word == target_word:
                    score += weight
            scored.append((score / total if total else 0.0, candidate))
        if not scored:
            raise RuntimeError(
                f"LEVEL_{module_index:02d}: aucun candidat central pour 0x{source_address:08X}"
            )
        scored.sort(reverse=True)
        best_score, best_index = scored[0]
        second_score = scored[1][0] if len(scored) > 1 else 0.0
        result = Match(
            source_address,
            RUNTIME_BASE + target_section.addr + best_index * 4,
            source_section.name,
            best_score,
            best_score - second_score,
            len(scored),
        )
        self.cache[key] = result
        return result

    def require_exact(self, source_address: int, module_index: int) -> Match:
        match = self.match(source_address, module_index)
        if match.score < 0.999999 or match.margin < 0.40:
            raise RuntimeError(
                f"LEVEL_{module_index:02d}: signature 0x{source_address:08X} insuffisante "
                f"(score={match.score:.6f}, marge={match.margin:.6f})"
            )
        return match

    def suck_comet_life(self, module_index: int) -> Match:
        source_address = 0x09414404
        sequence = (
            0x3E99999A,
            0x3E99999A,
            0x3FC00000,
            0x3F000000,
            0x3F333333,
            0x41F00000,
            0x3F060A92,
            0x3F860A92,
            0x3E4CCCCD,
            0x3FC00000,
            0x41200000,
            0x3F000000,
        )
        pattern = b"".join(struct.pack("<I", word) for word in sequence)
        image = self.images[module_index]
        hits = image.all_offsets(pattern, ".data")
        if len(hits) != 1:
            raise RuntimeError(
                f"LEVEL_{module_index:02d}: signature SuckCannonComet trouvée {len(hits)} fois"
            )
        data_section = image.sections[".data"]
        target_address = RUNTIME_BASE + data_section.addr + hits[0] - data_section.offset + 5 * 4
        result = Match(source_address, target_address, ".data", 1.0, 1.0, 1)
        self.cache[(source_address, module_index)] = result
        return result

    def shock_table(self, source_address: int, module_index: int) -> Match:
        block_start = 0x09411164
        block_end = 0x094111D4
        if not block_start <= source_address < block_end:
            raise ValueError(f"Adresse hors table Shock Rocket : 0x{source_address:08X}")
        source_data_start = socle_v1.file_offset_for_runtime(block_start)
        source_data_end = socle_v1.file_offset_for_runtime(block_end)
        pattern = self.source.data[source_data_start:source_data_end]
        image = self.images[module_index]
        hits = image.all_offsets(pattern, ".data")
        if len(hits) != 1:
            raise RuntimeError(
                f"LEVEL_{module_index:02d}: bloc Shock Rocket trouvé {len(hits)} fois"
            )
        data_section = image.sections[".data"]
        target_block_start = (
            RUNTIME_BASE + data_section.addr + hits[0] - data_section.offset
        )
        result = Match(
            source_address,
            target_block_start + source_address - block_start,
            ".data",
            1.0,
            1.0,
            1,
        )
        self.cache[(source_address, module_index)] = result
        return result


@dataclass
class Patch:
    module_index: int
    module: str
    level: str
    layer: str
    category: str
    mechanic: str
    source_address: int
    address: int
    file_vanilla: int
    runtime_vanilla: int
    patched: int
    evidence: str
    score: float
    margin: float
    section: str
    kind: str = "direct"
    is_hook: bool = False
    restore: bool = True
    weapon_id: str = ""
    weapon_title: str = ""
    continuous: bool = False


def relocated_jump_word(raw_word: int, base: int = RUNTIME_BASE) -> int:
    opcode = raw_word & 0xFC000000
    if opcode not in (0x08000000, 0x0C000000):
        raise ValueError(f"J/JAL attendu, reçu 0x{raw_word:08X}")
    return opcode | (((raw_word & 0x03FFFFFF) + (base >> 2)) & 0x03FFFFFF)


def runtime_vanilla(image: ElfImage, address: int) -> int:
    vaddr = address - RUNTIME_BASE
    raw = image.word_at_runtime(address)
    if image.relocations.get(vaddr, 0) == 4:
        return relocated_jump_word(raw)
    return raw


def direct_patch(
    module_index: int,
    layer: str,
    category: str,
    mechanic: str,
    source_address: int,
    match: Match,
    expected_original: int,
    patched: int,
    images: dict[int, ElfImage],
    *,
    kind: str = "direct",
    is_hook: bool = False,
    restore: bool = True,
    weapon_id: str = "",
    weapon_title: str = "",
    evidence_extra: str = "",
    continuous: bool = False,
) -> Patch:
    image = images[module_index]
    actual = image.word_at_runtime(match.target_address)
    expected_file = 0 if continuous else expected_original
    if actual != expected_file:
        raise RuntimeError(
            f"LEVEL_{module_index:02d}: 0x{match.target_address:08X}=0x{actual:08X}, "
            f"attendu 0x{expected_file:08X}"
        )
    evidence = (
        f"signature {match.section}, score {match.score:.3f}, marge {match.margin:.3f}, "
        f"{match.candidates} candidat(s)"
    )
    if evidence_extra:
        evidence += f"; {evidence_extra}"
    return Patch(
        module_index,
        f"LEVEL_{module_index:02d}.PRX",
        socle_v1.LEVEL_NAMES[module_index],
        layer,
        category,
        mechanic,
        source_address,
        match.target_address,
        expected_file,
        expected_original if continuous else runtime_vanilla(image, match.target_address),
        patched,
        evidence,
        match.score,
        match.margin,
        match.section,
        kind,
        is_hook,
        restore,
        weapon_id,
        weapon_title,
        continuous,
    )


BREAKABLE_GROUPS = {
    "Physique partagée débris + projection des boulons": [
        (0x0916202C, 0x27BDFFC0, 0x0A200C00, "Entrée intégrateur vers cave demi-pas", True),
        (0x09162030, 0xAFB00028, 0x00000000, "Delay slot reproduit dans la cave", True),
        (0x091620C4, 0x46107380, 0x00000000, "Gravité vanilla neutralisée", True),
    ],
    "Débris génériques": [
        (0x09168954, 0x46166300, 0x461C6300, "Âge +1,0 vers +0,5", False),
        (0x09168974, 0x46166301, 0x461C6301, "Durée -1,0 vers -0,5", False),
        (0x09168B0C, 0x46166300, 0x461C6300, "Progression sol/rebond +1,0 vers +0,5", False),
    ],
    "Boulons ordinaires": [
        (0x09258A84, 0x3C053F80, 0x3C053F00, "Timer état 0 : 1,0 vers 0,5", False),
        (0x094082CC, 0x41700000, 0x41F00000, "Dénominateur état 1 : 15 vers 30", False),
        (0x09408460, 0x3D75C291, 0x3CF5C28F, "Attraction : incrément linéaire", False),
        (0x09408468, 0x3DF5C28F, 0x3D7D9C85, "Attraction : lissage exponentiel", False),
        (0x09408470, 0x3C888889, 0x3C088889, "Attraction : phase", False),
        (0x09408478, 0x3DCC7578, 0x3D4CB6F5, "Attraction : rotation sin", False),
        (0x0940847C, 0x3F7EB898, 0x3F7FAE19, "Attraction : rotation cos", False),
        (0x094082B4, 0x3C23D657, 0x3BA3D6DE, "Boulon posé : rotation sin 0,01", False),
        (0x094082B8, 0x3F7FFCB9, 0x3F7FFF2E, "Boulon posé : rotation cos 0,01", False),
        (0x094082C0, 0x3CF5B920, 0x3C75C033, "Boulon posé : rotation sin 0,03", False),
        (0x094082C4, 0x3F7FE283, 0x3F7FF8A1, "Boulon posé : rotation cos 0,03", False),
        (0x092592DC, 0x24040002, 0x24040004, "Cadence d’effet : intervalle 2 vers 4", False),
    ],
}


PARTICLE_GROUPS = {
    "Level-up de vie maximale": [
        (0x09189190, 0x3C04BF80, 0x3C04BF00, "Phase visuelle 1"),
        (0x091893FC, 0x3C05BF80, 0x3C05BF00, "Phase visuelle 2"),
        (0x091897CC, 0x3C05BF80, 0x3C05BF00, "Phase visuelle 3"),
    ],
    "Feu": [
        (0x0940B408, 0x3F2AAAAB, 0x3EAAAAAB, "Cadence d’émission 2/3 vers 1/3"),
    ],
    "Téléporteur": [
        (0x092B3C68, 0x3C04BF80, 0x3C04BF00, "Timer fixe A"),
        (0x092B3DBC, 0x3C04BF80, 0x3C04BF00, "Timer fixe B"),
    ],
    "Mine Abeille": [
        (0x094077A4, 0x41880000, 0x41080000, "Fondu visuel 17 vers 8,5"),
    ],
    "Agents Ravageurs": [
        (0x09248108, 0x3C073F80, 0x3C073F00, "Pas du shrapnel décoratif"),
    ],
}


BREAKABLE_CAVE_WORDS = [
    0x27BDFFC0, 0xAFB00028, 0x00808025, 0xE7B40020,
    0x46006506, 0x3C043F00, 0x44846000, 0xC60E0024,
    0x460C7381, 0xE60E0024, 0xC60F0004, 0x460C7BC2,
    0xC4CE0000, 0x460F7380, 0xE4CE0000, 0xC5120000,
    0xC60E0008, 0xC4D10004, 0x460C7382, 0x460C94C2,
    0x460C9CC2, 0x460C9CC2, 0x460E8C40, 0x46138C40,
    0xE4D10004, 0xC60F000C, 0x460C7BC2, 0xC4CE0008,
    0x460F7380, 0xE4CE0008, 0x460C9482, 0xC60E0008,
    0x46127380, 0xE60E0008, 0x3C043F80, 0x44846000,
    0x0A458826, 0x00000000,
]


WEAPON_CAVE_RETURNS = {
    "acid_ballistics": (0x0924138C, 0x30),
    "agent_grenade_ballistics": (0x0924A748, 0x34),
    "shock_timer_a": (0x092A976C, 0x08),
    "shock_timer_b": (0x092A9798, 0x0C),
    "laser_timer": (0x09282B04, 0x08),
    "suck_timers": (0x092B02B4, 0x54),
    "suck_comet_speed": (0x092D4CC8, 0x0C),
}


def j_word(address: int) -> int:
    return 0x08000000 | ((address >> 2) & 0x03FFFFFF)


def enc_i(opcode: int, rs: int, rt: int, immediate: int) -> int:
    return (opcode << 26) | (rs << 21) | (rt << 16) | (immediate & 0xFFFF)


def enc_r(rs: int, rt: int, rd: int, shift: int, function: int) -> int:
    return (rs << 21) | (rt << 16) | (rd << 11) | (shift << 6) | function


def assemble_dispatcher() -> list[tuple[int, int]]:
    # t0=index, t1=table cursor, t2=module, t3=count, t4=packed/address,
    # t5=value id/value, t6=PSP base, t7=dictionary, t8/t9=diagnostic.
    program: list[tuple] = [
        ("lui", 8, 0x0884),
        ("lw", 8, 0x1120, 8),
        # Runtime probes: requested module, entered/completed state, selected count.
        ("lui", 24, 0x0880),
        ("sw", 8, DISPATCHER_INDEX_ADDRESS & 0xFFFF, 24),
        ("addiu", 25, 0, 1),
        ("sw", 25, DISPATCHER_STATE_ADDRESS & 0xFFFF, 24),
        ("sw", 0, DISPATCHER_COUNT_ADDRESS & 0xFFFF, 24),
        ("lui", 9, 0x0880),
        ("ori", 9, 9, TABLE_START & 0xFFFF),
        ("label", "scan"),
        ("lw", 10, 0, 9),
        ("addiu", 11, 0, -1),
        ("beq", 10, 11, "done"),
        ("nop",),
        ("lw", 11, 4, 9),
        ("beq", 10, 8, "apply_prep"),
        ("nop",),
        ("sll", 12, 11, 2),
        ("addiu", 9, 9, 8),
        ("addu", 9, 9, 12),
        ("beq", 0, 0, "scan"),
        ("nop",),
        ("label", "apply_prep"),
        ("addiu", 9, 9, 8),
        ("sw", 11, DISPATCHER_COUNT_ADDRESS & 0xFFFF, 24),
        ("beq", 11, 0, "done"),
        ("nop",),
        ("lui", 14, 0x0880),
        ("lui", 15, 0x0880),
        ("ori", 15, 15, DICTIONARY_START & 0xFFFF),
        ("label", "apply"),
        ("lw", 12, 0, 9),
        ("srl", 13, 12, 24),
        ("sll", 12, 12, 8),
        ("srl", 12, 12, 8),
        ("addu", 12, 12, 14),
        ("sll", 13, 13, 2),
        ("addu", 13, 13, 15),
        ("lw", 13, 0, 13),
        ("sw", 13, 0, 12),
        ("addiu", 9, 9, 4),
        ("addiu", 11, 11, -1),
        ("bne", 11, 0, "apply"),
        ("nop",),
        ("label", "done"),
        ("addiu", 25, 0, 2),
        ("sw", 25, DISPATCHER_STATE_ADDRESS & 0xFFFF, 24),
        ("j", 0x08807360),
        ("nop",),
    ]
    labels: dict[str, int] = {}
    instruction_index = 0
    for item in program:
        if item[0] == "label":
            labels[item[1]] = instruction_index
        else:
            instruction_index += 1
    words = []
    current = 0
    for item in program:
        opcode = item[0]
        if opcode == "label":
            continue
        if opcode == "lui":
            word = enc_i(0x0F, 0, item[1], item[2])
        elif opcode == "lw":
            word = enc_i(0x23, item[3], item[1], item[2])
        elif opcode == "sw":
            word = enc_i(0x2B, item[3], item[1], item[2])
        elif opcode == "ori":
            word = enc_i(0x0D, item[2], item[1], item[3])
        elif opcode == "addiu":
            word = enc_i(0x09, item[2], item[1], item[3])
        elif opcode == "beq":
            word = enc_i(0x04, item[1], item[2], labels[item[3]] - current - 1)
        elif opcode == "bne":
            word = enc_i(0x05, item[1], item[2], labels[item[3]] - current - 1)
        elif opcode == "sll":
            word = enc_r(0, item[2], item[1], item[3], 0x00)
        elif opcode == "srl":
            word = enc_r(0, item[2], item[1], item[3], 0x02)
        elif opcode == "addu":
            word = enc_r(item[2], item[3], item[1], 0, 0x21)
        elif opcode == "j":
            word = j_word(item[1])
        elif opcode == "nop":
            word = 0
        else:
            raise ValueError(opcode)
        words.append((DISPATCHER_START + current * 4, word))
        current += 1
    if words[-1][0] >= DICTIONARY_START:
        raise RuntimeError("Dispatcher trop grand")
    return words


DISPATCHER_WORDS = assemble_dispatcher()


def build_core(images: dict[int, ElfImage]) -> list[Patch]:
    by_module: dict[int, list[socle_v1.Patch]] = {}
    for index in MODULE_INDICES:
        data = images[index].data
        addresses = socle_v1.scan_core(data, f"LEVEL_{index:02d}.PRX")
        by_module[index] = socle_v1.build_patches(index, data, addresses)
    source_addresses = {patch.mechanic: patch.address for patch in by_module[1]}
    output = []
    for index in MODULE_INDICES:
        for source in by_module[index]:
            output.append(
                Patch(
                    index,
                    source.module,
                    source.level,
                    source.profile,
                    "Socle temporel",
                    source.mechanic,
                    source_addresses[source.mechanic],
                    source.address,
                    source.file_vanilla,
                    source.runtime_vanilla,
                    source.patched,
                    source.evidence,
                    1.0,
                    1.0,
                    ".text" if source.address < 0x09300000 else ".data",
                )
            )
    return output


WRAPPER_PREFIX = (
    0x27BDFFC0, 0xE7B40020, 0xE7B60024, 0xE7B80028,
    0xE7BA002C, 0xAFB00030, 0xAFB10034, 0xAFBF0038,
    0x46007D06, 0x46007586, 0x46006E06, 0x46006686,
    0x00A08025, 0x00808825,
)


def build_wrappers(images: dict[int, ElfImage]) -> list[Patch]:
    pattern = b"".join(struct.pack("<I", word) for word in WRAPPER_PREFIX)
    output = []
    for index in MODULE_INDICES:
        image = images[index]
        text = image.sections[".text"]
        hits = image.all_offsets(pattern, ".text")
        choices = []
        words = image.words_by_section[".text"]
        for hit in hits:
            wrapper_vaddr = text.addr + hit - text.offset
            callers = sum(
                1
                for word_index, word in enumerate(words)
                if word >> 26 == 3
                and (word & 0x03FFFFFF) == (wrapper_vaddr >> 2)
                and image.relocations.get(text.addr + word_index * 4, 0) == 4
            )
            choices.append((callers, wrapper_vaddr))
        choices.sort(reverse=True)
        if not choices or choices[0][0] < 2:
            raise RuntimeError(f"LEVEL_{index:02d}: wrapper commun non trouvé")
        if len(choices) > 1 and choices[0][0] == choices[1][0]:
            raise RuntimeError(f"LEVEL_{index:02d}: wrappers communs ambigus")
        callers, wrapper_vaddr = choices[0]
        address = RUNTIME_BASE + wrapper_vaddr + 0x38
        raw = image.word_at_runtime(address)
        if raw >> 26 != 3 or image.relocations.get(address - RUNTIME_BASE, 0) != 4:
            raise RuntimeError(f"LEVEL_{index:02d}: premier JAL du wrapper invalide")
        output.append(
            Patch(
                index,
                f"LEVEL_{index:02d}.PRX",
                socle_v1.LEVEL_NAMES[index],
                "WRAPPER",
                "Wrapper global",
                "Suppression de la seconde passe interne du wrapper commun",
                0x09148094,
                address,
                raw,
                relocated_jump_word(raw),
                0,
                f"prologue exact; {callers} appelants; {len(choices)} clone(s)",
                1.0,
                1.0,
                ".text",
            )
        )
    return output


def build_weapons(
    images: dict[int, ElfImage], mapper: SignatureMapper
) -> tuple[list[Patch], dict[tuple[int, int], int], list[dict]]:
    manifest = json.loads(WEAPON_MANIFEST.read_text(encoding="utf-8"))
    output: list[Patch] = []
    mapped_addresses: dict[tuple[int, int], int] = {}
    signature_rows = []
    for weapon in manifest["weapons"]:
        required = [patch for patch in weapon["patches"] if not patch.get("optional", False)]
        target_modules = FULL_WEAPON_MODULES
        if weapon["id"] == "01_lacerator":
            target_modules = FULL_WEAPON_MODULES + LACERATOR_ONLY_MODULES
        for patch_info in required:
            source_address = int(patch_info["address"], 16)
            original = int(patch_info["original"], 16)
            patched = int(patch_info["patched"], 16)
            for index in target_modules:
                if 0x09411164 <= source_address < 0x094111D4:
                    match = mapper.shock_table(source_address, index)
                elif source_address == 0x09414404:
                    match = mapper.suck_comet_life(index)
                else:
                    match = mapper.require_exact(source_address, index)
                mapped_addresses[(index, source_address)] = match.target_address
                item = direct_patch(
                    index,
                    "WEAPONS",
                    "Armes et effets de mods",
                    f"{weapon['title']} — {patch_info['instruction']}",
                    source_address,
                    match,
                    original,
                    patched,
                    images,
                    kind=patch_info["kind"],
                    is_hook=patch_info["kind"] == "hook",
                    weapon_id=weapon["id"],
                    weapon_title=weapon["title"],
                    evidence_extra=patch_info["rationale"],
                )
                output.append(item)
                signature_rows.append(
                    {
                        "layer": "WEAPONS",
                        "source_address": f"0x{source_address:08X}",
                        "module_index": index,
                        "target_address": f"0x{match.target_address:08X}",
                        "section": match.section,
                        "score": f"{match.score:.6f}",
                        "margin": f"{match.margin:.6f}",
                        "candidates": match.candidates,
                        "status": "ACCEPTÉ",
                    }
                )
    return output, mapped_addresses, signature_rows


def build_breakables(
    images: dict[int, ElfImage], mapper: SignatureMapper
) -> tuple[list[Patch], dict[tuple[int, int], int], list[dict]]:
    pokitaru_runtime = socle_v1.RAM_DUMPS[1].read_bytes()
    for definitions in BREAKABLE_GROUPS.values():
        for source_address, original, _patched, _label, _hook in definitions:
            if source_address not in DYNAMIC_RUNTIME_ADDRESSES:
                continue
            observed = struct.unpack_from(
                "<I", pokitaru_runtime, source_address - PSP_BASE
            )[0]
            if observed != original:
                raise RuntimeError(
                    f"RAM2: constante runtime 0x{source_address:08X}=0x{observed:08X}, "
                    f"attendu 0x{original:08X}"
                )
    output = []
    mapped_addresses = {}
    rows = []
    for group, definitions in BREAKABLE_GROUPS.items():
        modules = MODULE_INDICES if group != "Boulons ordinaires" else BOLT_MODULES
        for source_address, original, patched, label, hook in definitions:
            for index in modules:
                match = mapper.require_exact(source_address, index)
                mapped_addresses[(index, source_address)] = match.target_address
                output.append(
                    direct_patch(
                        index,
                        "BREAKABLES",
                        group,
                        label,
                        source_address,
                        match,
                        original,
                        patched,
                        images,
                        kind="hook" if hook else "direct",
                        is_hook=hook,
                        continuous=source_address in DYNAMIC_RUNTIME_ADDRESSES,
                    )
                )
                rows.append(
                    {
                        "layer": "BREAKABLES",
                        "source_address": f"0x{source_address:08X}",
                        "module_index": index,
                        "target_address": f"0x{match.target_address:08X}",
                        "section": match.section,
                        "score": f"{match.score:.6f}",
                        "margin": f"{match.margin:.6f}",
                        "candidates": match.candidates,
                        "status": "ACCEPTÉ",
                    }
                )
    return output, mapped_addresses, rows


def particle_modules(group: str) -> tuple[int, ...]:
    if group == "Level-up de vie maximale":
        return MODULE_INDICES
    if group == "Feu":
        return FIRE_MODULES
    if group == "Téléporteur":
        return TELEPORTER_MODULES
    return FULL_WEAPON_MODULES


def build_particles(
    images: dict[int, ElfImage], mapper: SignatureMapper
) -> tuple[list[Patch], list[dict]]:
    output = []
    rows = []
    for group, definitions in PARTICLE_GROUPS.items():
        for source_address, original, patched, label in definitions:
            for index in particle_modules(group):
                match = mapper.require_exact(source_address, index)
                output.append(
                    direct_patch(
                        index,
                        "PARTICLES",
                        f"Particules / FX — {group}",
                        label,
                        source_address,
                        match,
                        original,
                        patched,
                        images,
                    )
                )
                rows.append(
                    {
                        "layer": "PARTICLES",
                        "source_address": f"0x{source_address:08X}",
                        "module_index": index,
                        "target_address": f"0x{match.target_address:08X}",
                        "section": match.section,
                        "score": f"{match.score:.6f}",
                        "margin": f"{match.margin:.6f}",
                        "candidates": match.candidates,
                        "status": "ACCEPTÉ",
                    }
                )
    return output, rows


def weapon_caves() -> tuple[list[dict], list[tuple[int, int]]]:
    manifest = json.loads(WEAPON_MANIFEST.read_text(encoding="utf-8"))
    cave_records = []
    static_words = []
    for cave in manifest["caves"]:
        words = [(int(word["address"], 16), int(word["opcode"], 16)) for word in cave["words"]]
        return_address = words[-2][0]
        if words[-1][1] != 0:
            raise RuntimeError(f"{cave['name']}: delay slot final non nul")
        static = [(address, value) for address, value in words if address != return_address]
        static_words.extend(static)
        cave_records.append(
            {
                "name": cave["name"],
                "description": cave["description"],
                "start": int(cave["address"], 16),
                "return_word_address": return_address,
                "static_words": static,
            }
        )
    return cave_records, static_words


def build_cave_returns(
    weapon_map: dict[tuple[int, int], int], breakable_map: dict[tuple[int, int], int]
) -> tuple[list[Patch], list[dict], list[tuple[int, int]]]:
    caves, static_words = weapon_caves()
    output = []
    cave_by_name = {cave["name"]: cave for cave in caves}
    for index in FULL_WEAPON_MODULES:
        for cave_name, (source_hook, delta) in WEAPON_CAVE_RETURNS.items():
            cave = cave_by_name[cave_name]
            return_target = weapon_map[(index, source_hook)] + delta
            output.append(
                Patch(
                    index,
                    f"LEVEL_{index:02d}.PRX",
                    socle_v1.LEVEL_NAMES[index],
                    "WEAPONS",
                    "Retour de cave arme",
                    cave_name,
                    cave["return_word_address"],
                    cave["return_word_address"],
                    0,
                    0,
                    j_word(return_target),
                    f"retour = hook porté 0x{weapon_map[(index, source_hook)]:08X} + 0x{delta:X}",
                    1.0,
                    1.0,
                    "EBOOT cave",
                    "cave_return",
                    False,
                    False,
                )
            )

    break_return_address = 0x08803090
    break_static = [
        (0x08803000 + i * 4, word)
        for i, word in enumerate(BREAKABLE_CAVE_WORDS)
        if 0x08803000 + i * 4 != break_return_address
    ]
    static_words.extend(break_static)
    caves.append(
        {
            "name": "breakable_half_step",
            "description": "Demi-pas balistique partagé débris et boulons projetés",
            "start": 0x08803000,
            "return_word_address": break_return_address,
            "static_words": break_static,
        }
    )
    for index in MODULE_INDICES:
        source_hook = 0x0916202C
        return_target = breakable_map[(index, source_hook)] + 0x6C
        output.append(
            Patch(
                index,
                f"LEVEL_{index:02d}.PRX",
                socle_v1.LEVEL_NAMES[index],
                "BREAKABLES",
                "Retour de cave breakables",
                "Retour intégrateur après demi-pas",
                break_return_address,
                break_return_address,
                0,
                0,
                j_word(return_target),
                f"retour = hook porté 0x{breakable_map[(index, source_hook)]:08X} + 0x6C",
                1.0,
                1.0,
                "EBOOT cave",
                "cave_return",
                False,
                False,
            )
        )
    return output, caves, static_words


def crosscheck_known_weapon_candidates(patches: list[Patch]) -> list[dict]:
    rows = list(csv.DictReader(KNOWN_WEAPON_CSV.open(encoding="utf-8")))
    source_by_key = {
        (row["system"], row["patch"]): int(row["runtime_address"], 16)
        for row in rows
        if row["prx"] == "LEVEL_01.PRX"
    }
    patch_map = {
        (patch.module_index, patch.source_address): patch
        for patch in patches
        if patch.layer == "WEAPONS"
    }
    module_name_to_index = {
        f"LEVEL_{index:02d}.PRX": index for index in MODULE_INDICES
    }
    module_name_to_index["LEVEL_02_clean.PRX"] = 2
    output = []
    for row in rows:
        if row["prx"] not in module_name_to_index:
            continue
        index = module_name_to_index[row["prx"]]
        source_address = source_by_key[(row["system"], row["patch"])]
        patch = patch_map.get((index, source_address))
        if patch is None:
            # The candidate CSV predates the v2 weapon authority. Two old
            # candidates (RYNO 0.8 and Shock 0.8) were deliberately replaced
            # by the final v2 strategy and are not reintroduced here.
            continue
        expected_address = int(row["runtime_address"], 16)
        if patch.address != expected_address or patch.patched != int(row["patched_word"], 16):
            raise RuntimeError(f"Candidat connu divergent : {row['prx']} {row['system']} {row['patch']}")
        output.append(
            {
                "prx": row["prx"],
                "system": row["system"],
                "patch": row["patch"],
                "expected_address": row["runtime_address"],
                "mapped_address": f"0x{patch.address:08X}",
                "status": "MATCH",
            }
        )
    return output


def patch_sort_key(patch: Patch) -> tuple[int, int, int, int]:
    if patch.kind == "cave_return":
        phase = 0
    elif patch.is_hook:
        phase = 2
    else:
        phase = 1
    layer_order = {
        "BASE": 0,
        "SOCLE": 1,
        "WRAPPER": 2,
        "WEAPONS": 3,
        "BREAKABLES": 4,
        "PARTICLES": 5,
    }
    return phase, layer_order[patch.layer], patch.address, patch.source_address if isinstance(patch.source_address, int) else 0


def profile_patches(all_patches: list[Patch], profile: str) -> dict[int, list[Patch]]:
    layers = {
        "BASE": {"BASE"},
        "SOCLE": {"BASE", "SOCLE"},
        "EXPERIENCE": {"BASE", "SOCLE", "WRAPPER", "WEAPONS", "BREAKABLES", "PARTICLES"},
        "RESTORE": {"BASE", "SOCLE", "WRAPPER", "WEAPONS", "BREAKABLES", "PARTICLES"},
    }[profile]
    tables = {index: [] for index in MODULE_INDICES}
    for patch in all_patches:
        if patch.layer not in layers:
            continue
        if profile == "RESTORE" and not patch.restore:
            continue
        tables[patch.module_index].append(patch)
    for index in tables:
        tables[index].sort(key=patch_sort_key)
    return tables


def cw_address(address: int) -> int:
    offset = address - PSP_BASE
    if not 0 <= offset <= 0x0FFFFFFF:
        raise ValueError(f"Adresse PSP hors plage : 0x{address:08X}")
    return 0x20000000 | offset


def cw_line(address: int, value: int) -> str:
    return f"_L 0x{cw_address(address):08X} 0x{value:08X}"


def cw_condition_equal(address: int, value: int) -> str:
    offset = address - PSP_BASE
    if not 0 <= offset <= 0x0FFFFFFF:
        raise ValueError(f"Condition PSP hors plage : 0x{address:08X}")
    return f"_L 0x{0xC0000000 | offset:08X} 0x{value:08X}"


def cw_condition_equal_skip(address: int, value: int, skip_lines: int = 1) -> str:
    """Run the next lines only when a 16-bit value matches (CWCheat type E)."""
    offset = address - PSP_BASE
    if not 0 <= offset <= 0x0FFFFFFF:
        raise ValueError(f"Condition PSP hors plage : 0x{address:08X}")
    if not 0 <= value <= 0xFFFF:
        raise ValueError(f"Valeur 16 bits hors plage : 0x{value:X}")
    if not 1 <= skip_lines <= 0xFFF:
        raise ValueError(f"Nombre de lignes CWCheat hors plage : {skip_lines}")
    code = 0xE0000000 | (skip_lines << 16) | value
    return f"_L 0x{code:08X} 0x{offset:08X}"


def build_ini(
    title: str,
    tables: dict[int, list[Patch]],
    profile: str,
    static_cave_words: list[tuple[int, int]],
) -> tuple[str, dict]:
    restore = profile == "RESTORE"
    compact_tables = {
        index: [patch for patch in tables[index] if not patch.continuous]
        for index in MODULE_INDICES
    }
    continuous_tables = {
        index: [patch for patch in tables[index] if patch.continuous]
        for index in MODULE_INDICES
    }
    values: list[int] = []
    value_ids: dict[int, int] = {}
    for index in MODULE_INDICES:
        for patch in compact_tables[index]:
            value = patch.runtime_vanilla if restore else patch.patched
            if value not in value_ids:
                value_ids[value] = len(values)
                values.append(value)
    if len(values) > 256:
        raise RuntimeError(f"Dictionnaire trop grand : {len(values)} valeurs")
    dictionary_end = DICTIONARY_START + len(values) * 4
    if dictionary_end > DICTIONARY_LIMIT:
        raise RuntimeError("Dictionnaire dans les caves")

    total = sum(len(items) for items in tables.values())
    lines = [
        "_S UCES-00420",
        "_G Ratchet & Clank: Size Matters [EU]",
        "",
        f"# {title}",
        f"# Version {VERSION}; {total} écritures logiques sur quinze modules solo/spéciaux.",
        "# FRONTEND et LEVEL_16 à LEVEL_20 restent vanilla.",
        "# Profil alternatif : redémarrage complet de PPSSPP avant tout changement d’INI.",
        "",
        f"_C1 {title}",
    ]
    continuous_count = sum(len(items) for items in continuous_tables.values())
    if continuous_count:
        lines.extend([
            f"# {continuous_count} constantes initialisées au runtime : maintien conditionnel continu.",
            "# Type E : une condition fausse saute exactement l’écriture suivante sans arrêter le profil.",
            "# La condition 16 bits sur 0x08841120 empêche toute écriture dans un autre module.",
        ])
        for index in MODULE_INDICES:
            for patch in continuous_tables[index]:
                value = patch.runtime_vanilla if restore else patch.patched
                lines.append(cw_condition_equal_skip(0x08841120, index))
                lines.append(cw_line(patch.address, value))
        lines.append("")
    lines.extend([
        "# Marqueur vivant : prouve que l’interpréteur a traversé toutes les conditions type E.",
        cw_line(PROFILE_MARKER_ADDRESS, PROFILE_MARKERS[profile]),
        "",
    ])
    lines.extend([
        "# Bootstrap exécuté une seule fois. Le type C est ici volontairement un code-stopper :",
        "# si le hook est déjà installé, PPSSPP arrête seulement la fin bootstrap de ce bloc.",
        "_L 0xC0006DA4 0x0E201CD8",
    ])
    if profile == "EXPERIENCE":
        lines.append("# Les caves sont écrites avant les hooks PRX.")
        for address, word in sorted(static_cave_words):
            lines.append(cw_line(address, word))
        lines.append("")
    lines.append("# Dispatcher compact et sondes d’exécution.")
    lines.extend(cw_line(address, word) for address, word in DISPATCHER_WORDS)
    lines.extend(["", f"# Dictionnaire de {len(values)} valeurs à 0x{DICTIONARY_START:08X}."])
    for value_id, value in enumerate(values):
        lines.append(cw_line(DICTIONARY_START + value_id * 4, value))

    cursor = TABLE_START
    lines.extend(["", f"# Tables compactes à 0x{TABLE_START:08X}."])
    for index in MODULE_INDICES:
        items = compact_tables[index]
        lines.extend([
            f"# Module {index}: LEVEL_{index:02d}.PRX — {socle_v1.LEVEL_NAMES[index]} — {len(items)} écritures.",
            cw_line(cursor, index),
            cw_line(cursor + 4, len(items)),
        ])
        cursor += 8
        for patch in items:
            value = patch.runtime_vanilla if restore else patch.patched
            offset = patch.address - PSP_BASE
            if not 0 <= offset <= 0xFFFFFF:
                raise RuntimeError(f"Adresse non compressible : 0x{patch.address:08X}")
            packed = (value_ids[value] << 24) | offset
            action = "restaure" if restore else "patche"
            lines.append(
                f"# {action} 0x{patch.address:08X} avec dict[{value_ids[value]}] — "
                f"{patch.category}: {patch.mechanic}"
            )
            lines.append(cw_line(cursor, packed))
            cursor += 4
    lines.extend([
        "# Sentinelle.",
        cw_line(cursor, 0xFFFFFFFF),
        cw_line(cursor + 4, 0),
        "# Hook EBOOT écrit en dernier.",
        cw_line(HOOK_ADDRESS, HOOK_PATCHED),
        "",
    ])
    cursor += 8
    if cursor > TABLE_LIMIT:
        raise RuntimeError(f"Table trop grande : fin 0x{cursor:08X}")
    if restore:
        lines.extend([
            "_C0 [APRÈS RECHARGEMENT] Retirer le hook du dispatcher",
            "# Cocher seulement après le chargement du niveau à restaurer.",
            cw_line(HOOK_ADDRESS, HOOK_RUNTIME_VANILLA),
            "",
        ])
    return "\n".join(lines), {
        "profile": profile,
        "writes": total,
        "compact_writes": total - continuous_count,
        "continuous_writes": continuous_count,
        "dictionary_values": len(values),
        "dictionary_end": f"0x{dictionary_end:08X}",
        "table_end": f"0x{cursor:08X}",
        "static_cave_words": len(static_cave_words) if profile == "EXPERIENCE" else 0,
        "profile_marker_address": f"0x{PROFILE_MARKER_ADDRESS:08X}",
        "profile_marker_value": f"0x{PROFILE_MARKERS[profile]:08X}",
    }


def write_csv(path: Path, rows: list[dict], fields: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = list(rows[0]) if rows else []
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def patch_record(patch: Patch) -> dict:
    row = asdict(patch)
    for key in ("source_address", "address", "file_vanilla", "runtime_vanilla", "patched"):
        value = row[key]
        row[key] = value if isinstance(value, str) else f"0x{value:08X}"
    return row


def verify_memory_caves() -> list[dict]:
    rows = []
    for dump in socle_v1.RAM_DUMPS:
        data = dump.read_bytes()
        cave = data[:0x4000]
        nonzero = sum(byte != 0 for byte in cave)
        if nonzero:
            raise RuntimeError(f"{dump.name}: 0x08800000–0x08803FFF contient {nonzero} octets non nuls")
        hook = struct.unpack_from("<I", data, HOOK_ADDRESS - PSP_BASE)[0]
        if hook != HOOK_RUNTIME_VANILLA:
            raise RuntimeError(f"{dump.name}: hook RAM inattendu 0x{hook:08X}")
        rows.append({"dump": dump.name, "zero_bytes_checked": 0x4000, "nonzero": 0, "hook": f"0x{hook:08X}"})
    return rows


def source_inventory() -> list[dict]:
    rows = socle_v1.source_inventory()
    rows.extend([
        {
            "path": "AUTHORITY/pokitaru_weapon_patch_manifest_v2.json",
            "size_bytes": WEAPON_MANIFEST.stat().st_size,
            "sha256": sha256(WEAPON_MANIFEST),
            "role": "Manifeste source des 13 armes",
        },
        {
            "path": "AUTHORITY/known_weapon_patch_candidates.csv",
            "size_bytes": KNOWN_WEAPON_CSV.stat().st_size,
            "sha256": sha256(KNOWN_WEAPON_CSV),
            "role": "Contre-vérification multi-PRX",
        },
    ])
    return rows


def validate_patch_sets(patches: list[Patch]) -> None:
    seen: dict[tuple[int, int], Patch] = {}
    for patch in patches:
        key = (patch.module_index, patch.address)
        if key in seen:
            previous = seen[key]
            if previous.patched != patch.patched or previous.runtime_vanilla != patch.runtime_vanilla:
                raise RuntimeError(
                    f"Conflit LEVEL_{patch.module_index:02d} 0x{patch.address:08X}: "
                    f"{previous.mechanic} / {patch.mechanic}"
                )
            raise RuntimeError(
                f"Doublon LEVEL_{patch.module_index:02d} 0x{patch.address:08X}: "
                f"{previous.mechanic} / {patch.mechanic}"
            )
        seen[key] = patch
    expected = {
        "BASE": 60,
        "SOCLE": 52,
        "WRAPPER": 15,
        "WEAPONS": 1034,
        "BREAKABLES": 237,
        "PARTICLES": 87,
    }
    actual = defaultdict(int)
    for patch in patches:
        actual[patch.layer] += 1
    if dict(actual) != expected:
        raise RuntimeError(f"Comptages de couches inattendus : {dict(actual)} != {expected}")


def make_package(
    patches: list[Patch],
    caves: list[dict],
    static_cave_words: list[tuple[int, int]],
    signature_rows: list[dict],
    crosscheck_rows: list[dict],
    input_verification: dict,
) -> dict:
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    (OUT / "analysis").mkdir()
    (OUT / "docs").mkdir()
    (OUT / "tools").mkdir()

    profile_specs = [
        ("01_GLOBAL_60FPS_BASE_PREALPHA.ini", "60 FPS GLOBAL — BASE", "BASE"),
        ("02_GLOBAL_60FPS_SOCLE_PREALPHA.ini", "60 FPS GLOBAL — SOCLE", "SOCLE"),
        ("03_GLOBAL_60FPS_EXPERIENCE_PREALPHA.ini", "60 FPS GLOBAL — EXPÉRIENCE GÉNÉRALE", "EXPERIENCE"),
        ("04_GLOBAL_EXPERIENCE_RESTORE_NEXT_LOAD.ini", "RESTAURATION VANILLA — EXPÉRIENCE GÉNÉRALE", "RESTORE"),
    ]
    profile_metadata = []
    for filename, title, profile in profile_specs:
        tables = profile_patches(patches, profile)
        content, metadata = build_ini(title, tables, profile, static_cave_words)
        (OUT / filename).write_text(content + "\n", encoding="utf-8")
        metadata["file"] = filename
        profile_metadata.append(metadata)

    manifest = {
        "game": "Ratchet & Clank: Size Matters",
        "game_id": "UCES-00420",
        "version": VERSION,
        "module_indices": list(MODULE_INDICES),
        "excluded_modules": [0, 16, 17, 18, 19, 20],
        "dispatcher": {
            "table_start": f"0x{TABLE_START:08X}",
            "dispatcher_start": f"0x{DISPATCHER_START:08X}",
            "dictionary_start": f"0x{DICTIONARY_START:08X}",
            "hook_address": f"0x{HOOK_ADDRESS:08X}",
            "hook_vanilla": f"0x{HOOK_RUNTIME_VANILLA:08X}",
            "hook_patched": f"0x{HOOK_PATCHED:08X}",
            "format": "u32 module, u32 count, puis u32 packed(value_id:8,address_offset_from_0x08800000:24)",
            "words": [{"address": f"0x{a:08X}", "word": f"0x{w:08X}"} for a, w in DISPATCHER_WORDS],
        },
        "cwcheat_semantics": {
            "runtime_condition": "type E, comparaison 16 bits, saut borné à une ligne",
            "bootstrap_guard": "type C code-stopper, placé après tout maintien continu",
            "fixed_regression": "v0.2.0 utilisait type C pour les 77 écritures continues et arrêtait le bloc avant le dispatcher",
        },
        "diagnostics": {
            "profile_marker": f"0x{PROFILE_MARKER_ADDRESS:08X}",
            "dispatcher_module_index": f"0x{DISPATCHER_INDEX_ADDRESS:08X}",
            "dispatcher_state": f"0x{DISPATCHER_STATE_ADDRESS:08X}",
            "dispatcher_compact_count": f"0x{DISPATCHER_COUNT_ADDRESS:08X}",
            "dispatcher_state_complete": "0x00000002",
        },
        "profiles": profile_metadata,
        "caves": [
            {
                **{k: v for k, v in cave.items() if k != "static_words"},
                "start": f"0x{cave['start']:08X}",
                "return_word_address": f"0x{cave['return_word_address']:08X}",
                "static_words": [
                    {"address": f"0x{address:08X}", "word": f"0x{word:08X}"}
                    for address, word in cave["static_words"]
                ],
            }
            for cave in caves
        ],
        "patches": [patch_record(patch) for patch in patches],
        "input_verification": input_verification,
    }
    (OUT / "patch_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    patch_rows = [patch_record(patch) for patch in patches]
    write_csv(OUT / "analysis" / "module_patch_map.csv", patch_rows)
    write_csv(OUT / "analysis" / "signature_map.csv", signature_rows)
    write_csv(OUT / "analysis" / "known_weapon_crosscheck.csv", crosscheck_rows)
    inventory = source_inventory()
    write_csv(OUT / "analysis" / "source_inventory_sha256.csv", inventory)

    layer_counts = defaultdict(int)
    for patch in patches:
        layer_counts[patch.layer] += 1
    coverage_rows = []
    for index in MODULE_INDICES:
        row = {
            "module_index": index,
            "module": f"LEVEL_{index:02d}.PRX",
            "level": socle_v1.LEVEL_NAMES[index],
        }
        for layer in ("BASE", "SOCLE", "WRAPPER", "WEAPONS", "BREAKABLES", "PARTICLES"):
            row[layer.lower()] = sum(
                patch.module_index == index and patch.layer == layer for patch in patches
            )
        row["experience_total"] = sum(patch.module_index == index for patch in patches)
        coverage_rows.append(row)
    write_csv(OUT / "analysis" / "coverage_summary.csv", coverage_rows)

    make_docs(OUT, profile_metadata, coverage_rows, layer_counts, len(crosscheck_rows))
    shutil.copy2(Path(__file__), OUT / "tools" / Path(__file__).name)
    validator_source = HERE / "validate_global_experience.py"
    if validator_source.is_file():
        shutil.copy2(validator_source, OUT / "tools" / validator_source.name)

    hash_lines = []
    for path in sorted(p for p in OUT.rglob("*") if p.is_file()):
        hash_lines.append(f"{sha256(path)}  {path.relative_to(OUT).as_posix()}")
    (OUT / "MANIFEST_SHA256.txt").write_text("\n".join(hash_lines) + "\n", encoding="utf-8")

    if ZIP_PATH.exists():
        ZIP_PATH.unlink()
    with ZipFile(ZIP_PATH, "w", ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(p for p in OUT.rglob("*") if p.is_file()):
            archive.write(path, f"{OUT.name}/{path.relative_to(OUT).as_posix()}")
    return {
        "package": str(OUT),
        "zip": str(ZIP_PATH),
        "zip_sha256": sha256(ZIP_PATH),
        "zip_size": ZIP_PATH.stat().st_size,
        "layers": dict(layer_counts),
        "profiles": profile_metadata,
        "patch_records": len(patches),
        "known_weapon_crosschecks": len(crosscheck_rows),
    }


def make_docs(
    out: Path,
    profiles: list[dict],
    coverage: list[dict],
    layer_counts: dict[str, int],
    crosschecks: int,
) -> None:
    profile_rows = "\n".join(
        f"| {item['file']} | {item['writes']} | {item['compact_writes']} | "
        f"{item['continuous_writes']} | {item['dictionary_values']} | {item['table_end']} |"
        for item in profiles
    )
    coverage_rows = "\n".join(
        f"| {row['module_index']} | {row['module']} | {row['level']} | {row['weapons']} | "
        f"{row['breakables']} | {row['particles']} | {row['experience_total']} |"
        for row in coverage
    )
    readme = f"""# Size Matters 60 FPS — expérience générale globale

Version **{VERSION}**, cible **Europe UCES-00420**. Cette pré-alpha ajoute au socle global les 13 armes, le wrapper commun en une passe, la physique des breakables avec les boulons ordinaires, ainsi que les effets/particules dont les signatures ont été retrouvées sans ambiguïté.

Le profil ne débloque rien dans la sauvegarde : les armes et les 23 mods restent acquis, équipés et progressés normalement. Les mods ne reçoivent pas 23 écritures arbitraires ; leurs effets profitent des corrections apportées aux systèmes d’armes qu’ils réutilisent, puis devront être retestés combinaison par combinaison.

Cette révision corrige la panne de la v0.2.0 : les 77 gardes utilisaient le type CWCheat `C`, qui est un **code-stopper** dans PPSSPP. La première garde visant un autre module interrompait donc le bloc avant l’installation du dispatcher. Elles utilisent désormais le type `E`, dont le saut est borné à l’unique écriture suivante.

## Profils

| Fichier | Écritures logiques | Compactes | Continues | Valeurs du dictionnaire | Fin de table |
|---|---:|---:|---:|---:|---:|
{profile_rows}

Le profil recommandé pour un premier parcours est `03_GLOBAL_60FPS_EXPERIENCE_PREALPHA.ini`. Les quatre INI sont alternatifs : redémarrer complètement PPSSPP avant d’en remplacer un autre.

## Couverture du profil expérience

| Index | PRX | Niveau | Armes/caves | Breakables/boulons | Particules/FX | Total |
|---:|---|---|---:|---:|---:|---:|
{coverage_rows}

Les Giant Clank n’embarquent pas les classes des 13 armes. L’Airboard niveau 3 n’embarque que le Lacerator. Les tables reflètent cette présence réelle au lieu d’écrire des adresses supposées.

## Installation et retour vanilla

1. Copier un seul INI sous le nom `UCES00420.ini` dans `PPSSPP/PSP/Cheats`.
2. Démarrer PPSSPP à froid, activer les cheats, puis entrer dans le niveau depuis le frontend.
3. Pour restaurer, démarrer avec `04_GLOBAL_EXPERIENCE_RESTORE_NEXT_LOAD.ini`, charger chaque niveau concerné, puis activer son bloc de retrait du hook ou redémarrer à froid sans l’INI.

Ne pas commencer par une savestate prise dans un PRX déjà chargé : le dispatcher agit juste avant l’initialisation du module.

## Diagnostic mémoire rapide

Avec le profil expérience, vérifier après l’entrée dans un niveau :

| Adresse | Valeur attendue | Sens |
|---|---|---|
| `0x08803FE0` | `0xB0210003` | le profil a traversé toutes les conditions `E` |
| `0x08803FE4` | index du niveau (`1` Pokitaru, `2` Ryllus, etc.) | le dispatcher a été appelé |
| `0x08803FE8` | `0x00000002` | le dispatcher est arrivé à sa sortie |
| `0x08803FEC` | nombre non nul | une table de module a été sélectionnée |
| `0x08806DA4` | `0x0E200800` | le hook EBOOT est installé |

Si `0x08803FE0` est correct mais que `0x08803FE8` reste nul, revenir au frontend puis entrer normalement dans le niveau : le profil est chargé, mais l’appel pré-start n’a pas encore eu lieu.

## Statut et limites

- Le socle Pokitaru reste la seule base ayant reçu une validation dynamique antérieure.
- Les portages multi-PRX, les 79 écritures d’armes, le wrapper, les breakables et les particules sont validés statiquement mais nécessitent des essais en jeu.
- Sept constantes de rotation des boulons sont initialisées après le chargement du PRX ; elles représentent 77 écritures module-adresse maintenues en continu et conditionnées par l’index du module.
- “Particules” signifie ici les effets connus : trois phases de level-up, émission de feu là où la classe existe, deux timers de téléporteur, fondu Bee Mine et shrapnel Agents. Ce n’est pas encore un correctif exhaustif du moteur de particules.
- Le wrapper global remplace la variante Local JAL ; les deux approches ne doivent jamais être combinées.
- FRONTEND et `LEVEL_16` à `LEVEL_20` ne sont jamais patchés.

Le paquet ne contient aucun PRX, WAD, EBOOT ni dump RAM du jeu. Il requiert une copie légitime de la version européenne.
"""
    (out / "README.md").write_text(readme, encoding="utf-8")

    architecture = f"""# Architecture du profil cumulatif

Le hook EBOOT à `0x{HOOK_ADDRESS:08X}` appelle le dispatcher à `0x{DISPATCHER_START:08X}`. Celui-ci lit l’index demandé à `0x08841120`, sélectionne une table et applique chaque mot avant de reprendre la routine vanilla `0x08807360`.

Les écritures continues sont gardées par des conditions CWCheat `E` sur les 16 bits bas de `0x08841120`. Une condition fausse saute exactement une ligne. Le seul type `C` actif protège le bootstrap et se trouve après ces écritures ; une fois le hook posé, il évite de réécrire le dispatcher et les tables à chaque rafraîchissement.

Chaque entrée compacte contient huit bits d’index de valeur et vingt-quatre bits d’offset depuis `0x08800000`. Les valeurs sont placées dans un dictionnaire à `0x{DICTIONARY_START:08X}`. La plus grande table finit avant `0x{TABLE_LIMIT:08X}`.

Les caves armes occupent `0x08802C00–0x08802E9C` et la cave breakables `0x08803000–0x08803094`. Leur dernier saut dépend du PRX : le mot de retour est donc la première écriture de chaque table de module, avant tout hook vers la cave. Les corps de caves sont écrits directement avant l’installation du hook EBOOT.

Les deux dumps gameplay contrôlés contiennent uniquement des zéros sur `0x08800000–0x08803FFF` et le hook vanilla attendu.

Les sondes `0x08803FE0–0x08803FEC` distinguent quatre états : profil interprété, index vu à l’entrée, fin du dispatcher et taille de la table sélectionnée.
"""
    (out / "docs" / "ARCHITECTURE.md").write_text(architecture, encoding="utf-8")

    tests = """# Matrice de tests — expérience générale

## Parcours prioritaire

1. Cold boot, sauvegarde normale, Pokitaru sans savestate.
2. Tirer chaque arme sans mod puis avec chacun de ses mods actifs ; comparer cadence, portée, durée, DPS et XP au 30 FPS vanilla.
3. Casser plusieurs caisses, observer projection, rebonds, durée des débris et attraction des boulons.
4. Vérifier caméra et déplacements sur une transition complète de niveau.
5. Contrôler level-up de vie, feu, téléporteurs, Bee Mine et shrapnel Agents.
6. Répéter au minimum sur Ryllus, un niveau tardif, un Airboard et Giant Clank.

## Arrêts immédiats

- crash ou écran noir au chargement ;
- arme dont la trajectoire ou la durée est doublée/divisée par deux ;
- breakables figés, gravité excessive ou boulons impossibles à ramasser ;
- animation accélérée par le wrapper ;
- corruption d’inventaire ou de sauvegarde.

Noter le PRX, l’arme/mod, l’état précis, 30 FPS vanilla, 60 FPS patché, backend PPSSPP et présence d’une savestate.
"""
    (out / "docs" / "MATRICE_TESTS.md").write_text(tests, encoding="utf-8")

    validation = f"""# Validation technique

- {sum(layer_counts.values())} enregistrements de patch, dont {layer_counts['WEAPONS']} armes/caves et {layer_counts['BREAKABLES']} breakables/caves.
- {crosschecks} adresses recoupées exactement avec `known_weapon_patch_candidates.csv`.
- Signatures de portage acceptées uniquement avec contexte normalisé exact et marge minimale de 0,40 ; le record SuckCannonComet utilise une séquence de douze mots unique.
- Wrapper choisi par prologue exact et nombre maximal d’appelants, ce qui exclut les clones mono-appel.
- Valeurs vanilla relocalisées pour les instructions MIPS26 du VBlank et du wrapper.
- Corps de caves écrits avant les hooks ; retours spécifiques au module écrits en première phase.
- Tables, dictionnaire, dispatcher et caves bornés dans la zone vérifiée nulle.
- Simulation de la sémantique CWCheat pour le frontend et les quinze indices : les gardes `E` restent bornées et le bootstrap est atteint dans tous les cas.
- Sondes du dispatcher validées : index, entrée/sortie et nombre d’écritures sélectionnées.
- Ryllus construit depuis `LEVEL_02_clean.PRX`, pas depuis le PRX déjà contaminé de `BIN.zip`.

La validation statique ne remplace pas une exécution réelle dans PPSSPP.
"""
    (out / "docs" / "VALIDATION_TECHNIQUE.md").write_text(validation, encoding="utf-8")

    correction = f"""# Correctif {VERSION}

## Cause racine

La v0.2.0 utilisait 77 paires de la forme `0xC0041120 / écriture`. Dans PPSSPP, le type `C` n’est pas une condition portant seulement sur la ligne suivante : c’est une assertion qui termine tout le bloc `_C1` quand elle est fausse. Aucun index de niveau ne peut satisfaire successivement les gardes des quinze modules ; le dispatcher, le dictionnaire, les tables et le hook placés après elles étaient donc inatteignables.

Les corps de caves, placés avant ces gardes, pouvaient malgré tout être visibles en mémoire. C’est pourquoi le profil paraissait actif sans produire le 60 FPS.

## Correction

- remplacement des 77 gardes par des conditions `E` 16 bits avec saut d’une ligne ;
- déplacement des caves dans la partie bootstrap à exécution unique ;
- ajout de quatre sondes à `0x08803FE0–0x08803FEC` ;
- ajout d’une simulation du premier passage CWCheat pour les seize cas d’index ;
- conservation du dispatcher pré-start afin de ne pas réintroduire la course de rafraîchissement d’environ 77 ms.
"""
    (out / "docs" / "CORRECTIF_v0.2.1.md").write_text(correction, encoding="utf-8")


def main() -> None:
    socle_inputs = socle_v1.verify_inputs()
    memory_checks = verify_memory_caves()
    images = {index: ElfImage(module_path(index)) for index in MODULE_INDICES}
    mapper = SignatureMapper(images)

    core = build_core(images)
    wrappers = build_wrappers(images)
    weapons, weapon_map, weapon_signatures = build_weapons(images, mapper)
    breakables, breakable_map, breakable_signatures = build_breakables(images, mapper)
    particles, particle_signatures = build_particles(images, mapper)
    cave_returns, caves, static_cave_words = build_cave_returns(weapon_map, breakable_map)
    patches = core + wrappers + weapons + breakables + particles + cave_returns
    validate_patch_sets(patches)
    crosschecks = crosscheck_known_weapon_candidates(patches)
    verification = {
        **socle_inputs,
        "zero_region_checks": memory_checks,
        "known_weapon_crosschecks": len(crosschecks),
    }
    result = make_package(
        patches,
        caves,
        static_cave_words,
        weapon_signatures + breakable_signatures + particle_signatures,
        crosschecks,
        verification,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
