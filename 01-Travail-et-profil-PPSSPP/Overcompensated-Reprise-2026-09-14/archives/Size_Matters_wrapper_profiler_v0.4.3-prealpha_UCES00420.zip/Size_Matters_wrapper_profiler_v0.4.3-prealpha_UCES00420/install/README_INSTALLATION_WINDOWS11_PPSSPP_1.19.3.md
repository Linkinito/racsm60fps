# Installation — Windows 11 / PPSSPP 1.19.3

Cette distribution contient la v0.4.3 à base dynamique et compatible avec les marqueurs JIT de PPSSPP. Si une version antérieure a été testée, supprimer d’abord le dossier `PSP\PLUGINS\SizeMattersWrapperProfiler` en entier : conserver l'ancien `patch.prx` maintiendrait l'ancien détecteur.

## Choisir un seul palier

Les dossiers `00_DETECT_ONLY`, `01_FOCUSED_TRIGGERED_DOOR` et `02_FULL_POKITARU` contiennent chacun une arborescence `PSP/PLUGINS/SizeMattersWrapperProfiler`. Ils utilisent le même PRX mais une configuration différente. N’en installer qu’un à la fois, dans cet ordre.

Les mêmes arborescences sont disponibles sous forme d’archives directement extractibles dans `ready_zips/`.

| Dossier | Effet | Quand l’utiliser |
|---|---|---|
| `00_DETECT_ONLY` | zéro écriture dans le code du jeu | toujours en premier |
| `01_FOCUSED_TRIGGERED_DOOR` | deux `jal` WF-019 redirigés dans Pokitaru | prochain test après le palier 00 déjà validé |
| `02_FULL_POKITARU` | 55 `jal` redirigés dans Pokitaru | après une trace focalisée avec au moins un hit |

## Trouver le bon dossier Memory Stick

Dans PPSSPP, utiliser `File > Open Memory Stick...` ou `Settings > System > PSP Memory Stick > Show Memory Stick folder`. Selon l’installation Windows, ce dossier peut être `memstick` à côté de `PPSSPPWindows64.exe`, `%USERPROFILE%\Documents\PPSSPP`, ou un chemin personnalisé.

Le résultat attendu après copie est :

```text
<Memory Stick>\
└─ PSP\
   └─ PLUGINS\
      └─ SizeMattersWrapperProfiler\
         ├─ patch.prx
         ├─ plugin.ini
         └─ RCSMProfiler.ini
```

Copier le contenu du dossier de palier choisi dans la racine du Memory Stick et accepter la fusion du dossier `PSP`. Pour changer de palier, fermer complètement PPSSPP puis remplacer les trois fichiers.

Au premier lancement, la dernière ligne `start` de `status.log` doit contenir `version=0.4.3-prealpha`. Avec le palier 01, elle doit être suivie d'une ligne `module armed` contenant `mode=focused_pokitaru`, `family=WF-019`, `callsites=2`, `resolver=module_api`, la base et le delta. Si le log affiche une ancienne version, PPSSPP charge encore l’ancien fichier et le test n’est pas exploitable.

## Désactiver proprement

Fermer PPSSPP et déplacer `SizeMattersWrapperProfiler` hors de `PSP\PLUGINS`. Le renommer tout en le laissant dans `PLUGINS` n’est pas une désactivation fiable, car `plugin.ini` peut encore être découvert.

Le plugin ne modifie ni l’ISO ni les sauvegardes. Ses seuls fichiers persistants sont `status.log` et les traces JSON dans son propre dossier. Les redirections sont en RAM et disparaissent avec la fermeture complète du jeu/émulateur.

## Précautions

- vérifier dans les informations du jeu que l’ID est exactement `UCES00420` ;
- utiliser des sauvegardes internes du jeu, pas un savestate créé avec une autre version du plugin ;
- désactiver provisoirement les cheats et anciens patchs 60 FPS pour isoler ce test ;
- ne pas activer `memory = 64` : le plugin n’en a pas besoin ;
- conserver une copie de `status.log` et des traces avant de changer de palier.

La procédure complète et les critères de réussite se trouvent dans `../../TEST_PROTOCOL_PPSSPP_1.19.3_WINDOWS11.md`.
