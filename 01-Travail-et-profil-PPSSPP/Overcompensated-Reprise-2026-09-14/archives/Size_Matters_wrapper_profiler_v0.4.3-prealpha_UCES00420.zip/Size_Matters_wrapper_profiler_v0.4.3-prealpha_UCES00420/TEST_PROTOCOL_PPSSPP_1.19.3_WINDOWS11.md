# Protocole gradué — PPSSPP 1.19.3 sous Windows 11 Famille

## But de cette première campagne

Cette session ne cherche pas encore à « réparer » le 60 FPS. Elle doit valider successivement le chargement du PRX, la reconnaissance des modules, la transparence d’un trampoline sur une famille reproductible, puis la transparence des 55 callsites de Pokitaru. Chaque palier possède un critère d’arrêt : on ne passe jamais au suivant si le précédent a crashé, modifié le gameplay ou signalé un mot étranger.

**Révision du 25 août :** le palier 00 v0.4.2 a validé la résolution de `rcp1` à `+0x7000`. Au palier 01, le jeu est resté normal pendant environ la moitié de Pokitaru, mais PPSSPP a remplacé le premier mot du wrapper par son marqueur JIT `0x682BACB6`. La v0.4.2 l'a confondu avec un déchargement. La v0.4.3 accepte désormais cette classe `0x68xxxxxx` uniquement à cet emplacement, tout en exigeant exactement les autres gardes. Le callsite WF-002 n'ayant reçu aucun hit, le nouveau palier 01 cible les deux branches de `TriggeredDoor` (WF-019).

## Préparation commune

1. Fermer complètement PPSSPP.
2. Ouvrir le dossier Memory Stick depuis PPSSPP (`File > Open Memory Stick...` ou `Settings > System > Show Memory Stick folder`).
3. Sauvegarder au minimum `PSP\SAVEDATA` et tout ancien dossier `PSP\PLUGINS\SizeMattersWrapperProfiler`.
4. Désactiver provisoirement les cheats, le fichier 60 FPS actuel et tout autre plugin Size Matters. Le but est d’observer un seul mécanisme à la fois.
5. Vérifier que le jeu est bien `UCES00420`.
6. Préparer une sauvegarde **interne au jeu** sur Pokitaru. Ne pas reprendre un savestate : PPSSPP peut y conserver l’état d’une ancienne version d’un plugin.
7. Garder le cœur CPU habituel, idéalement le JIT par défaut, le frameskip à zéro et la vitesse d’émulation à 100 %. Noter tout réglage différent dans `TEST_RETURN_TEMPLATE.md`.

Avant chaque palier, fermer PPSSPP et déplacer les anciens `status.log`/`trace_*.json` dans un dossier d’archive afin que le nouveau résultat soit sans ambiguïté.

## Palier 00 — détection sans écriture

Installer le contenu de `install/00_DETECT_ONLY` dans le Memory Stick, puis démarrer PPSSPP à froid et lancer le jeu.

1. Charger la sauvegarde Pokitaru et attendre dix secondes dans une zone jouable.
2. Marcher, tourner la caméra et ouvrir/fermer un menu pour confirmer que le jeu reste normal.
3. Appuyer une seule fois sur `L + R + SELECT` ; attendre deux secondes.
4. Revenir au menu principal du jeu, puis fermer PPSSPP normalement.

Résultat attendu dans `status.log` :

```text
start version=0.4.3-prealpha ... mode=detect_only ... reference_base=0x09139D00 resolver=module_api+fallback_scan
module detected key=LEVEL_01 index=1 ... writes=0 resolver=module_api base=0x........ delta=..... entry=0x........ jit=.
trace saved ...
```

La trace v3 doit indiquer `mode: detect_only`, `installed_callsites: 0`, 55 entrées, zéro hit et `unknown_hits: 0`. Dans `capture`, `reference_base` doit valoir `0x09139D00`, `runtime_base` doit reprendre la base du log et `address_delta` doit être leur différence. Chaque `runtime_ra` doit être égal au `ra` de référence plus ce delta. Ce palier ne contient aucun appel au trampoline et ne modifie ni le code du jeu ni le tail-jump interne du profiler.

**Arrêt immédiat** si aucun `status.log` n’apparaît, si la dernière ligne `start` n’indique pas `0.4.3-prealpha`, si le jeu n’est pas UCES00420, si le résolveur final est `fallback_scan` ou si le log ne reconnaît jamais `LEVEL_01`. Dans ce dernier cas, appuyer tout de même sur `L + R + SELECT` : la v0.4.3 doit ajouter une ligne `manual export ignored` contenant le statut de l’API, la base, le delta, l’ancre et les gardes observés aux adresses traduites. Ne pas installer le palier 01 ; fournir les éléments décrits dans « Diagnostic selon le symptôme ».

## Palier 01 — famille TriggeredDoor de Pokitaru

Après réussite du palier 00, fermer PPSSPP et remplacer le dossier du plugin par `install/01_FOCUSED_TRIGGERED_DOOR`. Cette configuration traduit puis redirige exactement les deux branches WF-019 de `TriggeredDoor`, aux `$ra` de référence `0x092C142C` et `0x092C16AC`. Elles couvrent deux états exclusifs de la même logique de porte ; les instrumenter ensemble reste minimal tout en évitant un nouveau probe silencieux.

1. Démarrer à froid et charger la même sauvegarde Pokitaru.
2. Vérifier dans le log que la ligne d'armement annonce `mode=focused_pokitaru family=WF-019 ... callsites=2`.
3. Approcher plusieurs portes du niveau ; pour chacune, s'en éloigner, revenir, attendre son ouverture/fermeture et la franchir si possible.
4. Continuer une à deux minutes en surveillant commandes, caméra, animation, collisions, son et stabilité.
5. Pendant que Ratchet est encore contrôlable et qu'une porte est visible ou vient d'être utilisée, appuyer sur `L + R + SELECT`, attendre deux secondes, puis quitter normalement.

Résultat attendu : une trace avec `mode: focused_pokitaru`, `installed_callsites: 2`, `unknown_hits: 0` et au moins un hit sur WF-019. La ligne `PPSSPP JIT marker accepted ... remaining guards valid` est normale : elle montre précisément que la v0.4.3 a reconnu le remplacement temporaire sans inventer un changement de niveau. Un hit confirme que le trampoline assembleur a réellement été exécuté.

Ne pas passer au palier 02 en cas de crash, de mot `foreign/unreadable`, de `unknown_hits`, d’animation différente ou de ralentissement important.

## Palier 02 — tous les callsites de Pokitaru

Après une trace focalisée avec au moins un hit et aucun problème visible, installer `install/02_FULL_POKITARU`. `allowed_module = 1` interdit tout armement dans Ryllus ou les autres niveaux.

1. Refaire exactement le parcours du palier 01 pendant deux à trois minutes.
2. Ajouter une interaction avec une porte, un ennemi, un projectile et un élément mobile si possible.
3. Exporter une trace avec `L + R + SELECT`.
4. Si une progression normale permet d’aller vers Ryllus, effectuer la transition : le plugin doit exporter Pokitaru, détecter LEVEL_02, mais annoncer `writes=0` puisque seul le module 1 est autorisé.
5. Quitter normalement et conserver tous les fichiers produits.

Résultat attendu : `module armed ... callsites=55`, trace complète, `unknown_hits: 0`, aucune erreur de santé et comportement vanilla. Le profiler complet est volontairement plus lourd qu’un futur dispatcher : il sauvegarde tout l’état scalaire à chaque appel et n’est pas destiné à être laissé comme patch final.

## Lire automatiquement une trace

Sur un PC avec Python 3, depuis la racine du paquet :

```powershell
python profiler\tools\parse_trace.py `
  "C:\chemin\vers\trace_L01_0001.json" `
  --csv "C:\chemin\vers\trace_L01_0001.csv"
```

Une sortie `status: PASS` confirme le format, le nombre d’entrées, la correspondance exacte des `$ra`/familles avec le corpus et la cohérence des `runtime_ra` avec le delta. Elle ne juge pas encore le gameplay.

## Diagnostic selon le symptôme

| Symptôme | Ne pas faire | Fichiers/retours nécessaires |
|---|---|---|
| Aucun `status.log` | ne pas passer au palier suivant | copie de l’arborescence du plugin, ID du jeu, log PPSSPP avec debug logging activé |
| la dernière ligne `start` n’indique pas `0.4.3-prealpha` | ne pas poursuivre avec l’ancien PRX | supprimer le dossier complet du plugin, réinstaller l’archive v0.4.3 et redémarrer PPSSPP à froid |
| `resolver=fallback_scan` | ne pas activer le mode focalisé, même si LEVEL_01 est reconnu | fournir `status.log` : le repli est sûr et borné, mais l’API primaire devrait fonctionner sous PPSSPP 1.19.3 |
| v0.4.3 présente mais aucun module détecté | ne pas activer le mode focalisé | appuyer sur `L + R + SELECT`, puis fournir `status.log` ; la ligne donnera `api`, `base`, `delta` et les trois sondes traduites |
| `PPSSPP JIT marker accepted` | ne pas traiter cela comme un crash | poursuivre le test si le jeu reste normal ; cette ligne est le comportement correct de la v0.4.3 |
| `install refused` | ne pas forcer les adresses | `status.log`, niveau exact, cheats/plugins actifs, dump RAM avant toute écriture |
| Crash lors de `module armed` | retirer le dossier plugin et redémarrer à froid | `status.log`, log PPSSPP, étape/action exacte, cœur CPU utilisé ; sauvegarde interne si la scène est spécifique |
| Trace focalisée avec zéro hit | ne pas passer au palier 02 | trace JSON et liste des portes réellement essayées ; une sauvegarde près d'une porte pourra devenir nécessaire |
| `unknown_hits > 0` | ne pas utiliser full_module | trace JSON et `status.log` ; cela indiquerait un problème de liaison ou de concurrence |
| Gameplay différent sans crash | ne pas continuer longtemps | trace, sauvegarde interne, description mesurable et vidéo courte facultative |

Pour obtenir le log de l’émulateur en cas de problème, ouvrir `Settings > Tools > Developer Tools`, activer le debug logging et conserver les canaux par défaut au premier essai. Il n’est pas nécessaire d’activer le débogage pour une session réussie.

## Ce que tu devras me renvoyer au premier point d’arrêt

Pour le palier 01 v0.4.3, le minimum utile est `status.log`, la trace JSON v3 et l'indication des portes essayées. Le formulaire `TEST_RETURN_TEMPLATE.md` aide à conserver le contexte ; le log PPSSPP n’est nécessaire qu’en cas d’erreur. Une sauvegarde interne ne devient nécessaire que si aucune porte accessible ne déclenche WF-019. Un nouveau dump RAM ne sera demandé que si la base est résolue mais qu'une garde indépendante diverge.

La configuration `profiler/config_profiles/03_full_all_known_levels` existe pour la phase suivante, mais elle n’appartient pas à cette première campagne.
