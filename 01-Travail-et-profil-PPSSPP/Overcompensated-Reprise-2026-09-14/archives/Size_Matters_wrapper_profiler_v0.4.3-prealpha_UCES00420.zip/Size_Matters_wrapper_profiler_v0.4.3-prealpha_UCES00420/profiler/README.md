# Profiler PRX du wrapper — UCES00420

## Ce que fait réellement ce binaire

`patch.prx` est un plugin utilisateur destiné d’abord à PPSSPP. Il ne débloque pas encore le framerate et ne choisit aucune politique `ONE_PASS` ou `TWO_PASS`. Il mesure quel callsite connu appelle le wrapper original, combien de fois et entre quels VBlank. Après avoir compté, le trampoline transmet immédiatement l’appel au wrapper deux-passes original : le résultat fonctionnel doit donc rester vanilla.

Le PRX lit `RCSMProfiler.ini` une fois au démarrage et propose quatre modes :

| Mode | Écritures dans le code du jeu | Portée | Usage |
|---|---:|---|---|
| `detect_only` | 0 | détection des 15 profils | premier démarrage obligatoire |
| `single_pokitaru` | 1 mot | un `jal` de LEVEL_01 | diagnostic expert d'une adresse précise |
| `focused_pokitaru` | 2 mots par défaut | les deux branches WF-019 de LEVEL_01 | essai reproductible près des portes |
| `full_module` | 6 à 57 mots | module autorisé par `allowed_module` | cartographie dynamique après validation |

La configuration fournie limite `full_module` à `allowed_module = 1`, donc Pokitaru. La valeur `0` autorise les quinze profils connus, mais elle est volontairement isolée dans `config_profiles/03_full_all_known_levels` et ne doit pas être utilisée avant les essais gradués.

## Garde-fous implémentés

Avant la première écriture, le runtime récupère `text_addr` du module vivant `rcp1`, calcule son écart avec la base de référence `0x09139D00`, puis exige une empreinte stable pendant trois sondages. Il vérifie les quatre premiers mots du wrapper, son second appel interne et chaque `jal` candidat après application de ce même delta. L’ancre de référence à `0x09148800` ne porte aucune relocation dans les quinze PRX ; le second appel est comparé à un `jal` encodé vers sa cible runtime. Une divergence bloque l’installation entière. Après une écriture, les plages de cache données et instructions sont synchronisées avec les API PSP. Le retrait ne restaure qu’un mot qui cible encore notre hook ; un mot étranger fait échouer le système en mode fermé.

La v0.4.2 a ensuite validé le résolveur à un delta réel de `+0x7000`, puis a exporté un faux `module_transition` alors que le jeu demeurait jouable. Le mot observé `0x682BACB6` appartient à la classe que PPSSPP réserve à ses blocs JIT (`opcode 0x68000000`, masque `0xFC000000`). La v0.4.3 l'accepte uniquement au premier mot du wrapper ; l'ancre du niveau, les trois autres mots du prologue, le `jal` interne et les callsites restent exigés exactement. Les preuves se trouvent dans `IN_SITU_DIAGNOSTIC_v0.4.2.json`.

La résolution primaire utilise `sceKernelGetModuleIdList` et `sceKernelQueryModuleInfo`. Un balayage de mémoire borné et aligné sur `0x1000` n’est autorisé qu’en cas d’échec de cette API et seulement si le candidat est unique. Un résultat absent ou ambigu reste sans écriture.

Lors d’un changement de niveau, les anciennes adresses redeviennent la propriété du chargeur du jeu : le plugin coupe l’enregistrement et ne réinjecte pas aveuglément l’ancien code. Un rechargement du même niveau est distingué d’une modification étrangère, puis soumis à nouveau à la fenêtre de stabilité.

## Trampoline Allegrex

Chaque niveau possède un stub dont le dernier saut immédiat appartient au profiler. Dans les modes instrumentés, le runtime réencode ce `j` vers le wrapper vérifié à sa nouvelle adresse ; le mode `detect_only` ne touche même pas ce mot interne. Le corps commun sauvegarde puis restaure :

- les 30 GPR utiles, le `$ra` original et le `$gp` du jeu ;
- HI et LO ;
- FCR31 ;
- les 32 registres FPU scalaires `$f0` à `$f31`.

Le `$gp` du plugin n’est actif que pendant le petit shim C de comptage. Aucun fichier, allocation, verrou ou appel système n’est utilisé sur ce chemin chaud. La frame temporaire mesure 288 octets sur la pile du thread appelant. Le code C ordinaire n’utilise pas la VFPU ; la validation in situ reste néanmoins nécessaire pour confirmer le comportement de PPSSPP/JIT autour des blocs réécrits.

## Traces et commandes

Les fichiers sont écrits dans `PSP/PLUGINS/SizeMattersWrapperProfiler/` :

- `status.log` : décisions de détection, armement, refus, transitions et erreurs ;
- `trace_Lxx_####.json` : table complète du module au format `rcsm-wrapper-trace/3`, avec adresses de référence et runtime.

Contrôles en jeu, si `controls_enabled = true` :

- `L + R + SELECT` : exporter une trace ;
- `L + R + START` : remettre les compteurs à zéro.

Les boutons sont interrogés même avant reconnaissance. Si l’export est demandé sans profil actif, aucune trace trompeuse n’est créée, mais `status.log` reçoit une ligne `manual export ignored` avec le résolveur, le statut de l’API, la base, le delta et les mots effectivement lus en mémoire.

Le parseur recoupe automatiquement chaque paire `$ra`/famille avec le corpus :

```sh
python3 tools/parse_trace.py trace_L01_0001.json --csv trace_L01_0001.csv
```

## Validation réalisée hors jeu

Le binaire a été compilé avec PSPDEV v20260301 / `psp-gcc 15.2.0`. `PSP_BUILD_VALIDATION.json` consigne 799 invariants réussis, dont les quinze tail-jumps exportés, les sauvegardes GPR/FPU, le type PRX `0xFFA0`, la résolution dynamique, le garde JIT borné, les deux branches WF-019, les 493 relations `$ra = jal + 8` et l’empreinte SHA-256 du binaire.

L’empreinte statique produite par `psp-size` est de 30 960 octets (`text + data + bss`). Les piles déclarées sont de 16 Kio pour le moniteur et 2 Kio pour l’horloge VBlank, soit environ 49 392 octets au total hors petites structures internes de threads. Newlib est désactivé ; le plugin n’alloue pas de tas et n’utilise pas l’option PPSSPP `memory = 64`. Cette mémoire existe réellement et peut déplacer le niveau : les adresses sont donc toujours dérivées de la base déclarée par `rcp1`.

Tests hôte :

```sh
cc -std=c11 -Wall -Wextra -Werror \
  -Iinclude -Igenerated \
  src/rcsm_profiler_core.c generated/wrapper_profiles.generated.c \
  tests/test_profiler_core.c -o /tmp/rcsm_core_test
/tmp/rcsm_core_test

cc -std=c11 -Wall -Wextra -Werror \
  -Iinclude -Igenerated \
  src/rcsm_profiler_core.c generated/wrapper_profiles.generated.c \
  tests/test_runtime_dump.c -o /tmp/rcsm_dump_test
/tmp/rcsm_dump_test LEVEL_01_RAM.dump LEVEL_02_RAM.dump

cc -std=c11 -Wall -Wextra -Werror \
  -Iinclude src/rcsm_format.c tests/test_format.c \
  -o /tmp/rcsm_format_test
/tmp/rcsm_format_test

python3 tests/test_trace_parser.py
```

## Recompiler

Avec `PSPDEV` défini et `$PSPDEV/bin` dans `PATH` :

```sh
make clean all
python3 tools/validate_prx.py --pspdev "$PSPDEV" --output PSP_BUILD_VALIDATION.json
```

Voir `BUILD_REPRODUCIBILITY.md` pour la chaîne exacte et le protocole racine pour l’essai PPSSPP. Une PSP réelle sous CFW n’est pas encore une cible prise en charge : son chargeur, sa version de firmware et ses contraintes de concurrence doivent être validés séparément.
