# Size Matters — wrapper profiler v0.4.3-prealpha (UCES00420)

Ce paquet prolonge le catalogue statique par un **vrai PRX utilisateur compilé** pour PPSSPP. Il ne constitue pas encore un patch 60 FPS : son rôle est de reconnaître le PRX de niveau actif, d’observer les appels au wrapper deux-passes sans changer son résultat, puis d’exporter des traces qui permettront de décider quoi corriger et où.

## État au 25 août 2026

- 15 modules de niveau cartographiés, 493 callsites et 59 familles ;
- trampoline Allegrex compilé, avec sauvegarde/restauration des GPR, HI/LO, FCR31 et 32 registres FPU scalaires ;
- redirection transactionnelle d’un seul mot par callsite, delay slot inchangé ;
- trois paliers : aucune écriture, les deux branches `TriggeredDoor` de Pokitaru, puis tous les callsites de Pokitaru ;
- traces JSON v3, compteur VBlank, contrôles manuels et suivi des changements de niveau ;
- résolution dynamique de la base du module `rcp1` via les API PSP, avec balayage borné en repli ;
- relocalisation cohérente des empreintes, wrappers, callsites, `$ra` et tail-jumps, sans valeur `+0x6000` codée en dur ;
- palier 00 v0.4.2 validé in situ à un delta réel de `+0x7000` : 55/55 adresses traduites, zéro écriture ;
- premier palier instrumenté resté stable pendant environ la moitié de Pokitaru, mais WF-002 n'a produit aucun hit ;
- faux `module_transition` expliqué : PPSSPP avait placé son opcode JIT interne `0x682BACB6` au premier mot du wrapper, sans décharger ni corrompre le niveau ;
- v0.4.3 compatible avec cette classe officielle `0x68xxxxxx` uniquement au premier mot, toutes les autres gardes restant exactes ;
- `L + R + SELECT` est interrogé même sans profil reconnu et écrit alors un diagnostic explicite dans `status.log` ;
- tests hôte, sanitizers, compilation PSPDEV et audit du binaire réussis ;
- empreinte estimée : 30 960 octets pour le module, 18 432 octets de piles déclarées, soit environ 49 392 octets avant les petites structures internes du noyau ;
- sept scénarios sur dumps réels réussis : LEVEL_01/02 aux bases de référence, à `+0x6000`, à `+0x7000`, plus le marqueur JIT réellement observé ;
- **prochaine frontière : palier 01 focalisé WF-019 près des portes de Pokitaru**.

Ouvrir [index.html](index.html) pour le rapport vulgarisé et [TEST_PROTOCOL_PPSSPP_1.19.3_WINDOWS11.md](TEST_PROTOCOL_PPSSPP_1.19.3_WINDOWS11.md) pour la première session de test.

## Où commencer

1. Supprimer entièrement l’ancien dossier du plugin, puis lire le protocole et sauvegarder le dossier Memory Stick.
2. Le palier 00 ayant déjà réussi, installer `install/01_FOCUSED_TRIGGERED_DOOR` pour le prochain essai.
3. Vérifier que le log contient `version=0.4.3-prealpha`, `mode=focused_pokitaru`, `family=WF-019` et `callsites=2`.
4. Tester plusieurs portes tout en restant dans une zone jouable, puis exporter manuellement la trace.
5. N’utiliser `install/02_FULL_POKITARU` qu’après une trace focalisée avec au moins un hit, zéro hit inconnu et aucun changement visible.

Les sources et preuves de compilation se trouvent dans `profiler/`. Aucun EBOOT, PRX de niveau ou autre binaire du jeu n’est inclus ; `patch.prx` est uniquement le module original produit pour cette expérimentation.
