# Pokitaru 60 FPS V1 — two smoothing strategies

Scope: **Pokitaru only**, `LEVEL_01.PRX`, European release `UCES-00420`.

This bundle contains two mutually exclusive PPSSPP/CWCheat test builds:

- `UCES00420_Pokitaru_V1_local-jal.ini`: the common gameplay patch plus the 15 individual smoother-call replacements accumulated during testing.
- `UCES00420_Pokitaru_V1_global-wrapper.ini`: the same common gameplay patch, but no individual smoother-call replacements; the first internal pass of the shared wrapper at runtime `0x0914805C` is neutralized instead.

Do not enable both builds together.

## Source checked

- File: `LEVEL_01.PRX`
- Runtime base: `0x09139D00`
- File size: `3,444,725` bytes
- SHA-256: `d10a81d076fb44987a45314a020cda2f7e8b39f860b957911ca9365464676571`
- Runtime-to-file formula: `file offset = 0x74 + (runtime address - 0x09139D00)`

Every address used by these builds was checked against this Pokitaru PRX. The supplied `RAM.dump`, `RAM.dump.gzf`, and `LEVEL_02_clean.PRX` were not used: they correspond to Ryllus rather than Pokitaru.

## Common gameplay patch

Both files contain these identical 22 writes.

| System | Runtime address | Vanilla word | 60 FPS word |
|---|---:|---:|---:|
| Second VBlank | `0x091D0350` | `0x0C06FD09` | `0x00000000` |
| Player substeps | `0x091699FC` | `0x2A240002` | `0x2A240001` |
| General delta | `0x0914EEE0` | `0x3C043D08` | `0x3C043C88` |
| Local physics compensation | `0x091698BC` | `0x46006506` | `0x460C6500` |
| Camera, positive | `0x0913D31C` | `0x3C043D08` | `0x3C043C88` |
| Camera, negative | `0x0913D334` | `0x3C04BD08` | `0x3C04BC88` |
| Titanium Bolt speed | `0x09412308` | `0x3E75C28F` | `0x3DF5C28F` |
| Titanium Bolt factor | `0x092B548C` | `0x3C044000` | `0x3C043F80` |
| Crab pursuit speed | `0x09409028` | `0x3E6EEEF0` | `0x3DEEEEF0` |
| Crab attack threshold | `0x094090C8` | `0x41D80000` | `0x42580000` |
| TrainingBot speed | `0x09412D18` | `0x3E4CCCCE` | `0x3DCCCCCE` |
| TrainingBot hitbox start | `0x092BF014` | `0x2A240032` | `0x2A240064` |
| TrainingBot hitbox end | `0x092BF01C` | `0x2A240035` | `0x2A24006A` |
| EnemyWave delta | `0x09271C5C` | `0x3C043D08` | `0x3C043C88` |
| HutDoor speed | `0x0940C5C0` | `0x3E2AAAAB` | `0x3DAAAAAB` |
| Luna target speed | `0x0940EBA0` | `0x3E4CCCCE` | `0x3DCCCCCE` |
| Level01DoorTarget speed | `0x0940E1F0` | `0x3EAAAAAB` | `0x3E2AAAAB` |
| TriggeredDoor profile 4 speed | `0x094132A8` | `0x3EAAAAAB` | `0x3E2AAAAB` |
| Level01Boat speed | `0x0940DFDC` | `0x3DCCCCCE` | `0x3D4CCCCE` |
| TMRobotHeadB speed | `0x0941244C` | `0x3E088889` | `0x3D888889` |
| DropshipB initialization factor | `0x09269344` | `0x3C074000` | `0x3C073F80` |
| Final elevator progression | `0x092900E8` | `0x3C063D08` | `0x3C063C88` |

The dropship and elevator values are read during initialization. Reload the level or a checkpoint before comparing a build.

## Local-JAL build

At each of the following 15 runtime addresses:

```text
jal 0x0914805C  [0x0E452017]
    becomes
jal 0x09147F90  [0x0E451FE4]
```

| System | Runtime callsites |
|---|---|
| Shared Navigate smoothing | `0x09162C88`, `0x09162CAC`, `0x09162CD0` |
| Luna path smoothing | `0x09165C20`, `0x09165C44`, `0x09165C68` |
| HutDoor opening/closing | `0x0927DFFC`, `0x0927E2A0` |
| Level01DoorTarget | `0x0928A5C8` |
| TriggeredDoor opening/closing | `0x092C1424`, `0x092C16A4` |
| Level01Boat acceleration/braking/return | `0x09288C28`, `0x092892C4`, `0x09289668` |
| DropshipB flight speed | `0x09268694` |

The six other known `DropshipB` wrapper calls at `0x09268764`, `0x09268780`, `0x0926879C`, `0x0926890C`, `0x09268930`, and `0x0926894C` control direction/orientation smoothing. They were deliberately not added to the local build because they were not part of the working minimal dropship patch.

## Global-wrapper build

The wrapper still begins at runtime `0x0914805C`. Its first internal call is neutralized:

```text
0x09148094
jal 0x09147F90  [0x0E451FE4]
    becomes
nop             [0x00000000]
```

The second internal pass at `0x091480B0` remains intact. This preserves the wrapper's prologue, epilogue, calling convention, and return path.

The Pokitaru `.text` contains 55 direct calls to the wrapper. Consequently, this build deliberately has broader coverage than the local build and remains experimental until a complete Pokitaru replay shows no regression, especially in:

- dropship direction, rotation, and inclination;
- Luna and other path-following objects;
- doors and moving level objects;
- enemy navigation;
- camera or traversal paths that may call the same wrapper.

## Deliberate V1 exclusions

- all weapon-specific fixes, including Lacérator, Sniper Mine, Acid Bomb and weapon level-up;
- max-health level-up timings;
- nanotech/ammo attraction particles;
- debris, shrapnel, gulls, fish fin, armor halo, ambient effects, and other cosmetic work;
- all Ryllus addresses and files.

## Test protocol

1. Load Pokitaru with only one of the two cheat entries enabled.
2. Reload the level or checkpoint so initialization-time values are rebuilt.
3. Replay the whole level with identical inputs where practical.
4. Compare the local build first, then the global-wrapper build.
5. Disable the Pokitaru cheat before transitioning to Ryllus. These V1 files are intentionally level-specific and are not guarded against another PRX occupying the same runtime addresses.

Priority regression checks for the global build: Luna, hut doors, target door, large wave door, boat, dropship flight/orientation/largage, TMRobotHeadB, tyrolienne, and final elevator.
