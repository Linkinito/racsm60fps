#!/usr/bin/env python3
"""Static timing audit for Ratchet & Clank: Size Matters PSP PRX files.

First-pass reverse-engineering assistant. It detects timing-related instruction
patterns, groups them by probable function, and compares functions across PRXs.
It does NOT automatically decide that a candidate is a bug.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import struct
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Iterable

from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN
from capstone.mips import (
    MIPS_OP_REG, MIPS_OP_IMM, MIPS_OP_MEM,
)

RUNTIME_BASE = 0x09139D00
FLOAT_LUI_IMMS = {
    0x3D08: "1/30_hi",
    0x3C88: "1/60_hi",
    0x3F80: "+1.0_hi",
    0xBF80: "-1.0_hi",
    0x3F00: "+0.5_hi",
    0xBF00: "-0.5_hi",
    0x4000: "+2.0_hi",
    0xC000: "-2.0_hi",
}

@dataclass
class Section:
    name: str
    addr: int
    offset: int
    size: int
    flags: int

@dataclass
class Insn:
    idx: int
    address: int
    offset: int
    word: int
    mnemonic: str
    op_str: str
    cs: object = field(repr=False)

@dataclass
class Candidate:
    prx: str
    function_start: int
    function_end: int
    address: int
    kind: str
    confidence: str
    delta_tainted: bool
    details: str
    context: str
    fingerprint: str = ""
    match_prx: str = ""
    match_function: str = ""
    match_score: float = 0.0


def parse_elf32_sections(data: bytes) -> dict[str, Section]:
    if data[:4] != b"\x7fELF" or data[4] != 1 or data[5] != 1:
        raise ValueError("Expected ELF32 little-endian")
    e_shoff = struct.unpack_from("<I", data, 0x20)[0]
    e_shentsize = struct.unpack_from("<H", data, 0x2E)[0]
    e_shnum = struct.unpack_from("<H", data, 0x30)[0]
    e_shstrndx = struct.unpack_from("<H", data, 0x32)[0]
    headers = []
    for i in range(e_shnum):
        off = e_shoff + i * e_shentsize
        headers.append(struct.unpack_from("<IIIIIIIIII", data, off))
    shstr = headers[e_shstrndx]
    names = data[shstr[4]: shstr[4] + shstr[5]]

    def cstr(off: int) -> str:
        end = names.find(b"\0", off)
        if end < 0:
            end = len(names)
        return names[off:end].decode("ascii", errors="replace")

    out = {}
    for h in headers:
        name = cstr(h[0])
        out[name] = Section(name, h[3], h[4], h[5], h[2])
    return out


def reg_name(md: Cs, reg_id: int) -> str:
    return md.reg_name(reg_id)


def op_reg(md: Cs, ins: Insn, n: int) -> str | None:
    ops = ins.cs.operands
    if n >= len(ops) or ops[n].type != MIPS_OP_REG:
        return None
    return reg_name(md, ops[n].reg)


def op_imm(ins: Insn, n: int) -> int | None:
    ops = ins.cs.operands
    if n >= len(ops) or ops[n].type != MIPS_OP_IMM:
        return None
    return int(ops[n].imm)


def op_mem(md: Cs, ins: Insn, n: int) -> tuple[str, int] | None:
    ops = ins.cs.operands
    if n >= len(ops) or ops[n].type != MIPS_OP_MEM:
        return None
    return reg_name(md, ops[n].mem.base), int(ops[n].mem.disp)


def disassemble(path: Path) -> tuple[list[Insn], Section]:
    data = path.read_bytes()
    sections = parse_elf32_sections(data)
    text = sections[".text"]
    code = data[text.offset:text.offset + text.size]
    md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
    md.detail = True
    md.skipdata = True
    md.skipdata_setup = (".word", None, None)
    result = []
    for idx, ci in enumerate(md.disasm(code, RUNTIME_BASE + text.addr)):
        rel = ci.address - (RUNTIME_BASE + text.addr)
        word = struct.unpack_from("<I", code, rel)[0]
        result.append(Insn(idx, ci.address, text.offset + rel, word, ci.mnemonic, ci.op_str, ci))
    return result, text


def is_prologue(md: Cs, ins: Insn) -> bool:
    if ins.mnemonic not in ("addiu", "addi"):
        return False
    return op_reg(md, ins, 0) == "sp" and op_reg(md, ins, 1) == "sp" and (op_imm(ins, 2) or 0) < 0


def internal_jal_target(ins: Insn, text_start: int, text_end: int) -> int | None:
    if ins.mnemonic != "jal":
        return None
    imm = op_imm(ins, 0)
    if imm is None:
        return None
    # PRX code is linked relative to module address zero; Capstone displays the
    # encoded low address. Convert it to the runtime module base.
    target = RUNTIME_BASE + imm if imm < RUNTIME_BASE else imm
    if text_start <= target < text_end and target % 4 == 0:
        return target
    return None


def find_function_starts(md: Cs, insns: list[Insn], text_start: int, text_end: int) -> list[int]:
    starts = {text_start}
    for i, ins in enumerate(insns):
        if ins.mnemonic == ".word":
            continue
        target = internal_jal_target(ins, text_start, text_end)
        if target is not None:
            starts.add(target)
        if is_prologue(md, ins):
            # Prologues are strong candidates, especially if aligned or after a return/nop.
            starts.add(ins.address)
    return sorted(starts)


def function_ranges(starts: list[int], text_end: int) -> list[tuple[int, int]]:
    return [(s, starts[i + 1] if i + 1 < len(starts) else text_end) for i, s in enumerate(starts)]


def find_range(ranges: list[tuple[int, int]], addr: int) -> tuple[int, int]:
    # Binary search on starts.
    lo, hi = 0, len(ranges)
    while lo < hi:
        mid = (lo + hi) // 2
        if ranges[mid][0] <= addr:
            lo = mid + 1
        else:
            hi = mid
    return ranges[max(0, lo - 1)]


def context(insns: list[Insn], idx: int, before: int = 4, after: int = 7) -> str:
    lines = []
    for x in insns[max(0, idx-before):min(len(insns), idx+after+1)]:
        marker = ">" if x.idx == idx else " "
        lines.append(f"{marker}{x.address:08X}: {x.mnemonic:<8} {x.op_str}")
    return "\n".join(lines)


def normalized_token(md: Cs, ins: Insn) -> str:
    m = ins.mnemonic
    if m == ".word":
        return ".word"
    ops = ins.cs.operands
    parts = [m]
    for oi, op in enumerate(ops):
        if op.type == MIPS_OP_REG:
            parts.append(reg_name(md, op.reg))
        elif op.type == MIPS_OP_MEM:
            base = reg_name(md, op.mem.base)
            disp = int(op.mem.disp)
            # Preserve typical object/stack field offsets; mask large global-data displacements.
            parts.append(f"M[{base}+{disp if -0x400 <= disp <= 0x1000 else 'G'}]")
        elif op.type == MIPS_OP_IMM:
            imm = int(op.imm)
            if m in ("j", "jal") or m.startswith("b"):
                parts.append("TARGET")
            elif m == "lui":
                parts.append(FLOAT_LUI_IMMS.get(imm & 0xFFFF, "ADDRHI"))
            elif -16 <= imm <= 16:
                parts.append(str(imm))
            elif (imm & 0xFFFF) in (0x8889, 0x893B):
                parts.append(hex(imm & 0xFFFF))
            else:
                parts.append("IMM")
    return ":".join(parts)


def function_fingerprint(md: Cs, fn_insns: list[Insn], max_n: int = 80) -> str:
    toks = [normalized_token(md, x) for x in fn_insns[:max_n]]
    return hashlib.sha1("|".join(toks).encode()).hexdigest()[:16]


def function_signature(md: Cs, fn_insns: list[Insn], max_n: int = 80) -> list[str]:
    return [normalized_token(md, x) for x in fn_insns[:max_n]]


def similarity(a: list[str], b: list[str]) -> float:
    if not a or not b:
        return 0.0
    n = max(len(a), len(b))
    matches = sum(x == y for x, y in zip(a, b))
    # Penalize length mismatch mildly.
    return matches / n


def build_delta_taint(md: Cs, fn: list[Insn]) -> list[set[str]]:
    """Track a deliberately conservative set of FPRs derived from incoming f12."""
    tainted = {"f12"}
    states = []
    for ins in fn:
        states.append(set(tainted))
        m = ins.mnemonic
        if m == ".word":
            continue
        d, s1, s2 = op_reg(md, ins, 0), op_reg(md, ins, 1), op_reg(md, ins, 2)
        if m in ("mov.s", "abs.s", "neg.s") and d:
            if s1 in tainted:
                tainted.add(d)
            else:
                tainted.discard(d)
        elif m in ("add.s", "sub.s", "mul.s", "div.s") and d:
            if s1 in tainted or s2 in tainted:
                tainted.add(d)
            else:
                tainted.discard(d)
        elif m == "lwc1" and d:
            tainted.discard(d)
        elif m == "mtc1" and len(ins.cs.operands) >= 2:
            fd = op_reg(md, ins, 1)
            if fd:
                tainted.discard(fd)
    return states


def analyze_prx(path: Path):
    insns, text = disassemble(path)
    md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
    md.detail = True
    text_start = RUNTIME_BASE + text.addr
    text_end = text_start + text.size
    starts = find_function_starts(md, insns, text_start, text_end)
    ranges = function_ranges(starts, text_end)
    by_addr = {x.address: x for x in insns}
    addr_to_idx = {x.address: i for i, x in enumerate(insns)}

    functions = {}
    signatures = {}
    for s, e in ranges:
        i0 = addr_to_idx.get(s)
        if i0 is None:
            continue
        i1 = i0
        while i1 < len(insns) and insns[i1].address < e:
            i1 += 1
        fn = insns[i0:i1]
        functions[s] = fn
        signatures[s] = function_signature(md, fn)

    candidates: list[Candidate] = []

    for fs, fn in functions.items():
        if not fn:
            continue
        fe = fn[-1].address + 4
        taint_states = build_delta_taint(md, fn)

        def add(local_idx: int, kind: str, confidence: str, delta: bool, details: str):
            gi = fn[local_idx].idx
            candidates.append(Candidate(
                path.name, fs, fe, fn[local_idx].address, kind, confidence,
                delta, details, context(insns, gi),
                function_fingerprint(md, fn),
            ))

        # Explicit construction of 1/30 (lui 0x3D08 + ori 0x8889).
        for i, ins in enumerate(fn):
            if ins.mnemonic == "lui" and (op_imm(ins, 1) or 0) & 0xFFFF == 0x3D08:
                r = op_reg(md, ins, 0)
                for j in range(i+1, min(i+4, len(fn))):
                    y = fn[j]
                    if y.mnemonic == "ori" and op_reg(md, y, 0) == r and op_reg(md, y, 1) == r and ((op_imm(y, 2) or 0) & 0xFFFF) == 0x8889:
                        add(i, "FIXED_DT_1_30", "high", False, f"constructs float 1/30 in {r}")
                        break

        # Float +/-1 loaded then used by arithmetic and usually stored.
        for i, ins in enumerate(fn):
            if ins.mnemonic != "lui":
                continue
            imm = (op_imm(ins, 1) or 0) & 0xFFFF
            if imm not in (0x3F80, 0xBF80):
                continue
            gpr = op_reg(md, ins, 0)
            fpr = None
            mt_idx = None
            for j in range(i+1, min(i+5, len(fn))):
                if fn[j].mnemonic == "mtc1" and op_reg(md, fn[j], 0) == gpr:
                    fpr = op_reg(md, fn[j], 1)
                    mt_idx = j
                    break
            if not fpr:
                continue
            for j in range(mt_idx+1, min(mt_idx+12, len(fn))):
                y = fn[j]
                if y.mnemonic in ("add.s", "sub.s") and fpr in (op_reg(md,y,1), op_reg(md,y,2)):
                    d = op_reg(md,y,0)
                    stored = any(z.mnemonic == "swc1" and op_reg(md,z,0) == d for z in fn[j+1:min(j+6,len(fn))])
                    kind = "FRAME_FLOAT_COUNTER" if stored else "FLOAT_PLUS_MINUS_ONE"
                    add(i, kind, "medium" if stored else "low", bool(taint_states[j] & {"f12"}),
                        f"loads {'+1.0' if imm==0x3F80 else '-1.0'} into {fpr}; used at {y.address:08X}")
                    break

        # Integer memory counter +/-1: lw, addiu +/-1, sw same field.
        for i in range(len(fn)-2):
            a,b = fn[i],fn[i+1]
            if a.mnemonic != "lw" or b.mnemonic != "addiu":
                continue
            rd = op_reg(md,a,0); mem = op_mem(md,a,1)
            if not rd or not mem or op_reg(md,b,0)!=rd or op_reg(md,b,1)!=rd or op_imm(b,2) not in (-1,1):
                continue
            for j in range(i+2,min(i+7,len(fn))):
                z=fn[j]
                if z.mnemonic=="sw" and op_reg(md,z,0)==rd and op_mem(md,z,1)==mem:
                    add(i,"FRAME_INT_COUNTER","medium",False,
                        f"{mem[0]}{mem[1]:+d} updated by {op_imm(b,2):+d}")
                    break

        # Direct float field += another float, followed by store back to same field.
        # This catches frame-based linear movement but also many vector operations.
        for i in range(len(fn)):
            a=fn[i]
            if a.mnemonic != "lwc1":
                continue
            dst=op_reg(md,a,0); dstmem=op_mem(md,a,1)
            if not dst or not dstmem:
                continue
            for j in range(i+1,min(i+10,len(fn))):
                y=fn[j]
                if y.mnemonic != "add.s" or op_reg(md,y,0)!=dst or op_reg(md,y,1)!=dst:
                    continue
                vel=op_reg(md,y,2)
                # Ensure velocity came from a load in the local window.
                vel_load=None
                for k in range(i+1,j):
                    if fn[k].mnemonic=="lwc1" and op_reg(md,fn[k],0)==vel:
                        vel_load=fn[k]
                if vel_load is None:
                    continue
                stored=False
                for k in range(j+1,min(j+6,len(fn))):
                    z=fn[k]
                    if z.mnemonic=="swc1" and op_reg(md,z,0)==dst and op_mem(md,z,1)==dstmem:
                        stored=True; break
                if not stored:
                    continue
                delta_used = vel in taint_states[j] or dst in taint_states[j]
                kind = "DELTA_POSITION_STEP" if delta_used else "DIRECT_POSITION_STEP"
                conf = "high" if delta_used else "medium"
                add(j,kind,conf,delta_used,
                    f"field {dstmem[0]}{dstmem[1]:+d} += {vel}; source load at {vel_load.address:08X}")
                break

        # Any arithmetic/store operation involving delta-tainted values.
        for i, ins in enumerate(fn):
            if ins.mnemonic not in ("add.s","sub.s","mul.s","div.s"):
                continue
            d=op_reg(md,ins,0)
            if d and (op_reg(md,ins,1) in taint_states[i] or op_reg(md,ins,2) in taint_states[i]):
                if any(z.mnemonic=="swc1" and op_reg(md,z,0)==d for z in fn[i+1:min(i+8,len(fn))]):
                    add(i,"DELTA_DERIVED_STORE","high",True,
                        f"{d} derives from incoming f12 and is stored")
                    break  # one summary marker per function

    return {
        "path": path,
        "text": text,
        "insns": insns,
        "functions": functions,
        "signatures": signatures,
        "candidates": candidates,
    }


def cross_match(a, b):
    """Match only candidate-bearing functions, using normalized instruction tokens."""
    a_funcs = sorted({c.function_start for c in a["candidates"]})
    b_funcs = sorted({c.function_start for c in b["candidates"]})
    # Exact fingerprint first.
    b_fp = {}
    for fs in b_funcs:
        fp = function_fingerprint(Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN), b["functions"][fs])
        b_fp.setdefault(fp, []).append(fs)

    md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN); md.detail=True
    matches = {}
    for fs in a_funcs:
        fn = a["functions"][fs]
        fp = function_fingerprint(md, fn)
        if len(b_fp.get(fp, [])) == 1:
            matches[fs] = (b_fp[fp][0], 1.0)
            continue
        sig = a["signatures"][fs]
        # Restrict candidates by approximate instruction-count ratio.
        best=(None,0.0)
        for gs in b_funcs:
            bsig=b["signatures"][gs]
            if max(len(sig),len(bsig)) > 0 and min(len(sig),len(bsig))/max(len(sig),len(bsig)) < 0.55:
                continue
            sc=similarity(sig,bsig)
            if sc>best[1]: best=(gs,sc)
        if best[0] is not None and best[1]>=0.72:
            matches[fs]=best
    return matches


def write_outputs(results, outdir: Path):
    outdir.mkdir(parents=True, exist_ok=True)
    all_candidates=[]
    for r in results:
        all_candidates.extend(r["candidates"])

    fields=[f.name for f in Candidate.__dataclass_fields__.values()]
    with (outdir/"timing_candidates.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=fields)
        w.writeheader(); w.writerows(asdict(c) for c in all_candidates)

    with (outdir/"timing_candidates.json").open("w",encoding="utf-8") as f:
        json.dump([asdict(c) for c in all_candidates],f,ensure_ascii=False,indent=2)

    summary={}
    for r in results:
        counts={}
        funcs={}
        for c in r["candidates"]:
            counts[c.kind]=counts.get(c.kind,0)+1
            funcs.setdefault(c.kind,set()).add(c.function_start)
        summary[r["path"].name]={
            "text_size":r["text"].size,
            "instruction_count":len(r["insns"]),
            "probable_function_count":len(r["functions"]),
            "candidate_counts":counts,
            "candidate_function_counts":{k:len(v) for k,v in funcs.items()},
        }
    with (outdir/"summary.json").open("w",encoding="utf-8") as f:
        json.dump(summary,f,indent=2)

    # Compact human-readable report: prioritize functions with direct frame steps,
    # fixed dt, or frame counters, and show cross-PRX match.
    lines=["# PRX timing audit – first pass",""]
    for r in results:
        lines += [f"## {r['path'].name}",""]
        grouped={}
        for c in r["candidates"]:
            if c.kind in {"DIRECT_POSITION_STEP","FIXED_DT_1_30","FRAME_FLOAT_COUNTER","FRAME_INT_COUNTER","DELTA_POSITION_STEP"}:
                grouped.setdefault(c.function_start,[]).append(c)
        ranked=sorted(grouped.items(), key=lambda kv:(
            -sum(c.kind=="DIRECT_POSITION_STEP" for c in kv[1]),
            -sum(c.kind=="FIXED_DT_1_30" for c in kv[1]),
            -len(kv[1]), kv[0]))
        for fs,cs in ranked[:80]:
            kinds={}
            for c in cs:kinds[c.kind]=kinds.get(c.kind,0)+1
            first=cs[0]
            match=(f" -> {first.match_prx}:{first.match_function} ({first.match_score:.2f})" if first.match_function else "")
            lines.append(f"- `{fs:08X}` `{first.fingerprint}` {kinds}{match}")
        lines.append("")
    (outdir/"report.md").write_text("\n".join(lines),encoding="utf-8")


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("prx",nargs="+",type=Path)
    ap.add_argument("-o","--outdir",type=Path,default=Path("timing_audit"))
    args=ap.parse_args()
    results=[analyze_prx(p) for p in args.prx]
    if len(results)>=2:
        for i,a in enumerate(results):
            for j,b in enumerate(results):
                if i==j: continue
                matches=cross_match(a,b)
                for c in a["candidates"]:
                    if c.function_start in matches:
                        fs,sc=matches[c.function_start]
                        c.match_prx=b["path"].name
                        c.match_function=f"0x{fs:08X}"
                        c.match_score=sc
    write_outputs(results,args.outdir)
    print(json.dumps(json.loads((args.outdir/"summary.json").read_text()),indent=2))

if __name__=="__main__":
    main()
