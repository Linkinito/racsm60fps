#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,json,collections
from pathlib import Path

KNOWN={
 ('LEVEL_01.PRX',0x0917658C):'Ratchet state/update block (already handled by main physics patches)',
 ('LEVEL_02_clean.PRX',0x0917AE40):'Ratchet state/update block (already handled by main physics patches)',
 ('LEVEL_01.PRX',0x0916202C):'Generic effect/debris integrator',
 ('LEVEL_02_clean.PRX',0x091622B0):'Generic effect/debris integrator',
 ('LEVEL_01.PRX',0x09251E30):'BlasterShot::Update',
 ('LEVEL_02_clean.PRX',0x09257CC4):'BlasterShot::Update',
 ('LEVEL_01.PRX',0x092BC4C4):'TorsoAShot::Update (delta-based)',
}

def load(path):
 data=json.load(open(path,encoding='utf-8'))
 g=collections.defaultdict(list)
 for x in data:g[int(x['function_start'])].append(x)
 return data,g

def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('audit_a',type=Path)
 ap.add_argument('audit_b',type=Path)
 ap.add_argument('-o','--outdir',type=Path,default=Path('timing_audit_combined'))
 args=ap.parse_args(); args.outdir.mkdir(parents=True,exist_ok=True)
 A,GA=load(args.audit_a); B,GB=load(args.audit_b)
 nameA=A[0]['prx']; nameB=B[0]['prx']
 fa=collections.defaultdict(list); fb=collections.defaultdict(list)
 for fs,xs in GA.items():fa[xs[0]['fingerprint']].append(fs)
 for fs,xs in GB.items():fb[xs[0]['fingerprint']].append(fs)
 exact={}
 for fp,aa in fa.items():
  bb=fb.get(fp,[])
  if len(aa)==1 and len(bb)==1:
   exact[aa[0]]=bb[0]
 exact_rev={v:k for k,v in exact.items()}
 rows=[]
 def emit(name,g,other_name,matches):
  for fs,xs in sorted(g.items()):
   c=collections.Counter(x['kind'] for x in xs)
   score=(5*c['DIRECT_POSITION_STEP']+4*c['FRAME_FLOAT_COUNTER']+3*c['FIXED_DT_1_30']+
          2*c['FRAME_INT_COUNTER']-3*c['DELTA_DERIVED_STORE'])
   rows.append({
    'prx':name,'function_start':f'0x{fs:08X}','known_name':KNOWN.get((name,fs),''),
    'fingerprint':xs[0]['fingerprint'],'score':score,
    'direct_position_steps':c['DIRECT_POSITION_STEP'],
    'frame_float_counters':c['FRAME_FLOAT_COUNTER'],
    'frame_int_counters':c['FRAME_INT_COUNTER'],
    'fixed_dt_1_30':c['FIXED_DT_1_30'],
    'delta_derived_stores':c['DELTA_DERIVED_STORE'],
    'float_plus_minus_one':c['FLOAT_PLUS_MINUS_ONE'],
    'exact_match_prx':other_name if fs in matches else '',
    'exact_match_function':f'0x{matches[fs]:08X}' if fs in matches else '',
   })
 emit(nameA,GA,nameB,exact);emit(nameB,GB,nameA,exact_rev)
 fields=list(rows[0])
 with open(args.outdir/'functions.csv','w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
 common=[]
 for a,b in exact.items():
  ca=collections.Counter(x['kind'] for x in GA[a])
  cb=collections.Counter(x['kind'] for x in GB[b])
  score=5*ca['DIRECT_POSITION_STEP']+4*ca['FRAME_FLOAT_COUNTER']+3*ca['FIXED_DT_1_30']+2*ca['FRAME_INT_COUNTER']-3*ca['DELTA_DERIVED_STORE']
  common.append((score,a,b,GA[a][0]['fingerprint'],ca))
 common.sort(reverse=True)
 lines=['# Audit temporel comparatif','',
 f'- Fonctions candidates dans {nameA}: **{len(GA)}**',
 f'- Fonctions candidates dans {nameB}: **{len(GB)}**',
 f'- Correspondances exactes et uniques: **{len(exact)}**','',
 'Le score est un triage heuristique, pas une preuve de bug.','',
 '## Repères validés','']
 for (prx,addr),label in KNOWN.items():
  if prx in (nameA,nameB):lines.append(f'- `{prx}` `{addr:08X}` — {label}')
 lines += ['', '## Candidats communs prioritaires','']
 for score,a,b,fp,c in common[:100]:
  if score<=0:continue
  label=KNOWN.get((nameA,a),'') or KNOWN.get((nameB,b),'')
  lines.append(f'- score **{score:3d}** — `{nameA}:{a:08X}` ↔ `{nameB}:{b:08X}` — {dict(c)}' + (f' — **{label}**' if label else ''))
 (args.outdir/'priority.md').write_text('\n'.join(lines),encoding='utf-8')
 meta={'prx_a':nameA,'prx_b':nameB,'candidate_functions_a':len(GA),'candidate_functions_b':len(GB),'unique_exact_matches':len(exact)}
 (args.outdir/'summary.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
 print(json.dumps(meta,indent=2))
if __name__=='__main__':main()
