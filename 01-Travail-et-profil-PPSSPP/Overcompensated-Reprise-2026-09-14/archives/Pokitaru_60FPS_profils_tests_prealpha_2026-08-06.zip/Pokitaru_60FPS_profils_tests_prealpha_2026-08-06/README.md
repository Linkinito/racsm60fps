# Pokitaru — profils de test 60 FPS pré-alpha

Ce paquet sépare le travail Pokitaru en sept fichiers INI alternatifs. Il ne contient aucun binaire du jeu, dump RAM, PRX, WAD, ISO ou sauvegarde.

Compatibilité analysée :

- Ratchet & Clank: Size Matters, version européenne UCES-00420 ;
- Pokitaru seulement, module LEVEL_01.PRX ;
- base runtime du module : 0x09139D00 ;
- PRX de référence SHA-256 : d10a81d076fb44987a45314a020cda2f7e8b39f860b957911ca9365464676571.

## Profils

| N° | Profil | Écritures principales | Activation | But |
|---|---|---|---|---|
| 01 | 60 FPS base | 4 | Automatique | Observer les anomalies brutes à 60 FPS |
| 02 | 60 FPS socle | 8 | Automatique | Base + caméra + Titanium Bolt |
| 03 | Socle + armes | 8 + 13 blocs | Armes C0 | Une arme à la fois |
| 04 | Socle + niveau individuel | 8 + 12 blocs | Objets C0 | Une mécanique Pokitaru à la fois |
| 05 | Socle + niveau global | 23 | Automatique | Wrapper partagé en une passe |
| 06 | Socle + breakables + boulons | 8 + 7 blocs | Candidats C0 | Physique, timers, attraction et effets séparés |
| 07 | Socle + cosmétiques | 8 + 5 blocs | Candidats C0 | Effets non gamebreaking séparés |

Chaque INI possède une notice portant le même numéro dans le dossier docs.

## Installation

1. Choisir un seul des sept INI.
2. Le copier dans le dossier Cheats de PPSSPP et le renommer UCES00420.ini si nécessaire.
3. Activer les cheats PPSSPP, sans frameskip, et vérifier que le jeu tient réellement 60 FPS.
4. Faire un démarrage à froid, puis entrer dans Pokitaru. Le dispatcher applique le socle au chargement du module.
5. Dans les profils 03, 04, 06 et 07, laisser d’abord tous les blocs C0 désactivés.
6. Créer un savestate avant la scène, activer un seul bloc C0, recharger la scène ou Pokitaru, puis mesurer.

## Règles de test indispensables

- Ne jamais fusionner deux INI de ce paquet.
- Ne jamais combiner le profil 04 LOCAL JAL et le profil 05 GLOBAL WRAPPER.
- Un bloc C0 décoché ne restaure pas les octets qu’il a écrits.
- Pour annuler un candidat : décocher TEST, cocher son bloc RESTORE, recharger la scène, puis décocher RESTORE.
- Pour revenir à un état de référence incontestable : fermer complètement le jeu et PPSSPP, puis redémarrer sans cheat.
- Comparer des secondes réelles, des distances, des dégâts et des nombres d’événements ; une simple impression visuelle ne suffit pas.

## Statuts

- VALIDÉ : résultat déjà confirmé sur la séquence Pokitaru indiquée.
- REPLAY : candidat déjà intégré dans l’ancien profil local, mais la séquence complète doit être rejouée.
- TEST : justification statique établie, validation dynamique 30/60 manquante.
- EXPÉRIMENTAL : patch nouveau ou couverture large ; activer isolément.
- NON PATCHÉ : anomalie connue sans correction assez sûre pour être publiée.

Le mot validé ne signifie pas que tout le jeu est couvert. Ce paquet est une pré-alpha Pokitaru destinée à produire des mesures reproductibles avant tout portage.

## Contenu

- sept INI prêts à copier ;
- sept notices détaillées ;
- MATRICE_TESTS.md pour l’ordre de campagne recommandé ;
- VALIDATION_TECHNIQUE.md et patch_manifest.json pour l’audit ;
- MANIFEST_SHA256.txt pour vérifier l’intégrité du paquet.
