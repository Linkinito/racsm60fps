# Notice 04 — socle + éléments / ennemis individuels

## Fonctionnement

Le socle est automatique. Douze blocs C0 isolent les mécanismes Pokitaru. Les constantes propres à un objet et ses appels locaux de lissage sont regroupés afin qu’un test corresponde à une scène compréhensible.

La variante LOCAL JAL remplace quinze appels précis de la fonction deux passes 0x0914805C par la fonction une passe 0x09147F90. Elle ne touche pas le wrapper partagé.

## Identification, résultat et attente

| Bloc | Identification | Vanilla 30 FPS | Socle 60 FPS | Attendu avec patch | Statut |
|---|---|---|---|---|---|
| Crabe | Vitesse + seuil 27 vers 54 | Attaque vers 0,90 s | Vers 0,45 s, déplacement ×2 | Attaque vers 0,90 s et vitesse normale | VALIDÉ |
| TrainingBot | Vitesse + fenêtre 50–53 vers 100–106 | Déplacement / hitbox normaux | Vitesse et fenêtre ×2 | Même déplacement et fenêtre réelle | VALIDÉ |
| EnemyWave | Delta privé 1/30 vers 1/60 | Vague normale | Progression ×2 | Progression 30 FPS | VALIDÉ |
| Navigation | 3 appels XYZ vers fonction une passe | Lissage normal | Deux passes à chaque update 60 Hz | Une passe par update | REPLAY |
| HutDoor | Vitesse + 2 appels locaux | Ouverture normale | Porte accélérée | Temps d’ouverture 30 FPS | VALIDÉ |
| Luna | Vitesse cible + 3 appels XYZ | Séquence normale | Déplacement / suivi accélérés | Séquence complète identique en secondes | REPLAY |
| Level01DoorTarget | Vitesse + 1 appel local | Porte normale | Porte accélérée | Temps et arrêt 30 FPS | REPLAY |
| TriggeredDoor | Vitesse profil 4 + 2 appels | Porte normale | Ouverture / fermeture accélérées | Profils conservés | REPLAY |
| Level01Boat | Vitesse + 3 appels locaux | Trajet normal | Bateau accéléré | Trajet et transitions 30 FPS | VALIDÉ |
| TMRobotHeadB | Vitesse table | Mouvement normal | Mouvement / mêlée accélérés | Vitesse 30 FPS | VALIDÉ |
| Dropship | Facteur init + seul appel de vol retenu | Vol et largage normaux | Vol / largage accélérés | Vol et largage normalisés | VALIDÉ |
| Ascenseur final | Progression 1/30 vers 1/60 | Fin de niveau normale | Progression ×2 | Même durée de transition | REPLAY |

## Choix prudents

Six autres appels du Dropship restent exclus : 0x09268764, 0x09268780, 0x0926879C, 0x0926890C, 0x09268930 et 0x0926894C. Leur rôle ne justifie pas une redirection automatique.

La tyrolienne ne possède aucun patch ici : elle a été jugée correcte avec le socle. Le candidat Nano 45 vers 90 à 0x0940FDF8 n’est pas intégré faute de validation suffisante.

## Protocole

Utiliser le même point d’entrée et le même savestate. Pour chaque bloc, mesurer durée totale, distance, instant de collision / hitbox et état final. Rejouer les transitions aller et retour ; une porte qui s’ouvre correctement peut encore mal se fermer.

Le profil 04 et le profil 05 sont mutuellement exclusifs.
