# Notice 02 — 60 FPS socle

## Définition stricte

Le socle contient huit écritures : les quatre de la base, deux pour la caméra principale et deux pour le Titanium Bolt. Les boulons ordinaires ne sont pas le Titanium Bolt et restent hors de ce profil.

## Identification, résultats et attente

| Mécanique | Patch | Vanilla 30 FPS | 60 FPS base | Attendu avec socle |
|---|---|---|---|---|
| Base 60 FPS | 4 écritures du profil 01 | Jeu 30 Hz cohérent | Base déjà corrigée | Joueur et temps général conservés |
| Caméra + | 0x0913D31C, +1/30 vers +1/60 | Rotation normale | Environ ×2 dans une direction | Même angle par seconde qu’à 30 FPS |
| Caméra - | 0x0913D334, -1/30 vers -1/60 | Rotation normale | Environ ×2 dans l’autre direction | Symétrie et vitesse 30 FPS |
| Titanium Bolt | 0x09412308 et 0x092B548C | Collecte normale | Animation / déplacement accéléré et potentiellement bloquant | 0,24 vers 0,12 et facteur 2 vers 1 |

## Résultat observé

La caméra principale et le Titanium Bolt ont déjà donné un résultat fonctionnel sur Pokitaru. Le socle est le point de comparaison de tous les profils 03 à 07.

Il ne contient volontairement pas les 14 constantes d’objets du niveau, les 15 redirections locales de lissage, les armes, les breakables, les boulons ordinaires ou les effets cosmétiques.

## Test

Mesurer un tour de caméra complet dans les deux sens, rejouer la collecte du Titanium Bolt, puis vérifier déplacement, saut, chute et glide. Toute autre anomalie doit être classée dans une famille ultérieure, sans grossir le socle.
