# Notice 03 — socle + armes

## Fonctionnement

Le socle de huit écritures est automatique. Les treize armes sont treize blocs C0 indépendants. Sept caves, situées entre 0x08802C00 et 0x08802E9C, servent uniquement lorsque la transformation ne tient pas dans un remplacement de constante.

## Identification et résultat attendu

| Arme | Mécanique identifiée | Vanilla 30 FPS | Socle 60 FPS prédit | Attendu avec bloc |
|---|---|---|---|---|
| Lacérator | Vitesse / dénominateur et âge projectile | Trajet et portée normaux | Projectile et vieillissement accélérés | Vitesse et durée réelles du 30 FPS |
| Tremblator | Âge de l’onde | Expansion normale | Onde vieillie deux fois trop vite | Durée normale |
| Bombacide | Cave balistique h=0,5 | Arc normal | Translation ×2 et gravité déformée | x,z ×0,5 ; gravité effective ×0,25 |
| Agents Ravageurs | Timers, grenade, roquette | Cycle normal | Enfants, grenade et roquette accélérés | Cycles et trajectoires 30 FPS |
| Mine Abeille | Âge, progression, virage, mouvement | Mine et abeille normales | Vie / virage / déplacement accélérés | Durées et degrés/s 30 FPS |
| Barrière Statique | Compteurs d’états fixes | États normaux | États raccourcis | États restaurés ; drain delta intact |
| Roquette Éclair | Deux timers privés, vitesse, durée, braquage | Projectile normal | Cycle et guidage accélérés | Temps, vitesse et virage 30 FPS |
| Mine de Sniper | Timers d’armement et d’états | Déploiement normal | États raccourcis | Durées restaurées ; mouvement à mesurer |
| Incinérator | Temps, munitions, compteur secondaire, modulo dégâts | DPS et consommation normaux | Scan et consommation potentiellement ×2 | Cadence logique 30 Hz |
| Pisteur Laser | Timer privé et phases | Rayon normal | Phases et DPS potentiellement accélérés | Phases 30 FPS ; DPS à mesurer |
| Aspiro-Canon | Trois timers, rangement, vie et vitesse projectile | Aspiration normale | Capture / relâchement accélérés | Durées et projectile 30 FPS |
| Bovinator | Huit pas de transformation | Transformation normale | Transformation environ ×2 | Même temps de transformation |
| T.E.L.T. | Salve, âge, vitesse et braquage roquettes | Salve normale | Salve et roquettes accélérées | Cadence et guidage 30 FPS |

## Nature des patches

Les opcodes, constantes, hooks et restaurations ont été recoupés statiquement dans LEVEL_01.PRX et RAM2.dump. Le profil contient 79 écritures de gameplay et sept caves totalisant 92 mots. Les treize blocs restent toutefois au statut TEST tant qu’une campagne dynamique PPSSPP 30/60 FPS n’a pas confirmé :

- temps de trajet et portée ;
- durée avant disparition ;
- degrés de braquage par seconde ;
- dégâts, DPS, munitions et XP ;
- nombre de projectiles et d’effets par seconde ;
- variantes et niveaux de chaque arme.

## Exclusions volontaires

Le candidat AgentOfDoomShrapnel 1,0 vers 0,5 est retiré : le paramètre alimente l’échelle / orientation et certaines réponses au rebond, pas le delta-temps. Le fondu de Mine Abeille est déplacé dans le profil 07.

## Protocole

Activer une arme, recharger le même savestate avant l’action, effectuer au moins cinq répétitions, restaurer le bloc, puis passer à l’arme suivante. Ne jamais valider une arme sur sa portée seule : deux erreurs peuvent se compenser.
