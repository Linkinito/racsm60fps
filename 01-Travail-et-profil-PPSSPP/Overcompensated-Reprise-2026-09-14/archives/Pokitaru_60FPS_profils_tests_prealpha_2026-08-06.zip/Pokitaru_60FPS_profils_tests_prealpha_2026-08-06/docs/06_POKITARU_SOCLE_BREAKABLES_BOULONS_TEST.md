# Notice 06 — socle + breakables + boulons ordinaires

## Architecture identifiée

Les caisses et breakables génériques créent des fragments dans le pool mis à jour par 0x09168890. Leur intégration physique passe par 0x0916202C. Cette dernière fonction possède exactement deux appelants directs observés à Pokitaru :

- 0x09168A88 : pool générique de débris / effets ;
- 0x09258B20 : état balistique du BoltController.

Puisque ce profil inclut volontairement les boulons ordinaires, le partage n’est plus traité comme un effet de bord : la cave corrige les deux appelants.

## Demi-pas appliqué

Vanilla par update :

    compteur -= 1
    x += vx
    y += vy + 0,5 × g
    z += vz
    vy += g

À 60 Hz, la cave utilise h = 0,5 :

    compteur -= 0,5
    x += 0,5 × vx
    y += 0,5 × vy + 0,125 × g
    z += 0,5 × vz
    vy += 0,5 × g

Le terme de gravité en position devient 0,125, pas 0,25 : il correspond à 0,5 × g × h². Les coefficients de friction et de rebond ne sont pas divisés.

## Blocs, résultats et attentes

| Bloc | Identification | Vanilla 30 FPS | Socle 60 FPS | Attendu | Statut |
|---|---|---|---|---|---|
| Physique partagée | 0x0916202C ; appelants 0x09168A88 et 0x09258B20 | Arc balistique normal | Translation environ ×2 ; gravité appliquée deux fois | Demi-pas exact h=0,5 | EXPÉRIMENTAL |
| Âge / durée débris | 0x09168954 et 0x09168974 | Vie normale | Âge et disparition environ ×2 | +0,5 / -0,5 par update | EXPÉRIMENTAL |
| Sol / rebond débris | 0x09168B0C | Progression normale | Branche post-collision ×2 | +0,5 par update | EXPÉRIMENTAL |
| Boulon états 0 / 1 | 0x09258A84 et table 0x094082CC | Projection / stabilisation normales | Transitions deux fois trop rapides | Timer 0,5 ; dénominateur 30 | EXPÉRIMENTAL |
| Attraction boulons | Tables 0x09408460–0x0940847C | Aimantation normale | Attraction et phase accélérées | Incréments demi-pas et lissage exact | EXPÉRIMENTAL |
| Rotation boulons posés | Tables 0x094082B4–0x094082C4 | Rotation normale | Rotation environ ×2 | Angles divisés par deux | EXPÉRIMENTAL |
| Effet boulons | Reset à 0x092592DC | Un effet toutes les 2 updates à 30 Hz | Deux fois plus d’événements/s | Intervalle 4 updates à 60 Hz | EXPÉRIMENTAL |

Pour le lissage d’attraction vanilla 0,12, la valeur demi-pas est calculée par 1 - sqrt(1 - 0,12) = 0,0619168468. Une division simple par deux ne préserverait pas exactement la réponse exponentielle.

## Ce qui reste hors correctif

Les classes AgentOfDoomShrapnel, BeeMineShrapnel, CrabShrapnel, HeadShrapnel, ShrapnelGeneric, TorsoShrapnel et TrainingBotShrapnel utilisent un second moteur à 0x092CBA7C. CowBell l’utilise également. Aucune modification globale n’est publiée ici afin de ne pas toucher CowBell et de ne pas confondre le paramètre géométrique 1,0 avec un delta-temps.

Le nombre de morceaux initialement créé par une caisse est événementiel ; ce profil ne le modifie pas. BoltController_SpewBolts à 0x09258860 reste intact : ni quantité ni valeur monétaire ne changent. Le Titanium Bolt est un autre système, déjà couvert par le socle.

## Protocole

Tester les sept blocs dans l’ordre du fichier. Pour chaque étape, filmer une caisse ordinaire, une caisse de munitions, une caisse de vie et plusieurs projections de boulons. Mesurer trajectoire, hauteur maximale, temps de disparition, nombre de rebonds, temps avant attraction et temps jusqu’au ramassage. Vérifier enfin collisions, dégâts et total de boulons.
