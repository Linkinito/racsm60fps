# Notice 07 — socle + autres cosmétiques

## Fonctionnement

Le socle est automatique. Cinq blocs C0 isolent des animations, timers ou cadences d’émission qui ne doivent pas être mélangés aux ennemis, aux armes de gameplay ou aux breakables.

## Identification, résultat et attente

| Bloc | Identification | Vanilla 30 FPS | Socle 60 FPS | Attendu avec patch | Statut |
|---|---|---|---|---|---|
| Level-up vie max | 3 décréments fixes ; phases 90 / 30 / 50 | 5,67 s environ | 2,83 s environ ; particules potentiellement ×2 | 5,67 s ; densité encore à mesurer | EXPÉRIMENTAL |
| Feu | Accumulateur d’émission 2/3 par update | Environ 20 unités/s | Environ 40 unités/s | 1/3 par update, environ 20/s | EXPÉRIMENTAL |
| Téléporteur | 2 timers -1 fixes | Durées normales | Deux phases environ deux fois trop courtes | -0,5 par update | EXPÉRIMENTAL |
| Aileron Sharkagator | 5 appels locaux au wrapper deux passes | Animation normale | Aileron observé accéléré | Une passe sur ces cinq appels seulement | EXPÉRIMENTAL |
| Fondu Mine Abeille | Table 17 par update | Fondu normal | Fondu prédit ×2 | 8,5 par update | EXPÉRIMENTAL |

## Limites

Le level-up de vie applique la nouvelle vie maximale avant sa présentation. Le patch ne change donc pas la progression du joueur ; il ne fait que restaurer les trois durées visuelles. Les particules aléatoires restent évaluées 60 fois par seconde et doivent être comptées séparément.

Le bloc Aileron modifie cinq appels locaux seulement. Il est incompatible avec le profil 05 global wrapper.

L’ancien candidat 0x09248108, 1,0 vers 0,5 pour AgentOfDoomShrapnel, est explicitement rejeté : la valeur sert à l’échelle / orientation et à certaines réponses physiques, pas au delta-temps.

## Anomalies conservées comme témoins NON PATCHÉS

- mouettes ;
- halos d’armure ;
- cascades et eau ;
- autres poissons / faune ;
- particules ambiantes non identifiées ;
- second moteur Moby shrapnel.

Ces lignes ne reçoivent pas d’opcode spéculatif. Leur présence dans la checklist permet de vérifier qu’un autre bloc ne les modifie pas indirectement.

## Protocole

Mesurer la durée totale du level-up, compter les émissions de feu sur dix secondes, chronométrer chaque phase du téléporteur et filmer l’aileron avec le même trajet caméra. Pour le fondu Mine Abeille, isoler l’alpha du reste du comportement de l’arme.
