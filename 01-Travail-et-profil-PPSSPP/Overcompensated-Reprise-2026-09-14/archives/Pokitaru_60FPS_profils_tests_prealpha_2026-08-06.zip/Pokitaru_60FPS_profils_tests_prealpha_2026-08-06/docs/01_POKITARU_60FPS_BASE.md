# Notice 01 — 60 FPS base

## Fonctionnement

Ce profil est le témoin minimal. Le dispatcher pré-démarrage écrit exactement quatre mots dans LEVEL_01.PRX au chargement de Pokitaru. Il ne corrige ni la caméra, ni les objets du niveau, ni les armes.

## Identification et patch

| Mécanique | Identification | Résultat vanilla 30 FPS | Résultat sans correction à 60 FPS | Attendu avec ce profil |
|---|---|---|---|---|
| Déverrouillage | Boucle VBlank identifiée à 0x091D0350 | 30 FPS verrouillés | 60 FPS autorisés | 60 FPS réels si l’émulateur suit |
| Joueur | Sous-pas à 0x091699FC | Deux sous-pas dans la boucle 30 Hz | Sans correction : mouvement environ ×2 | Un sous-pas à 60 Hz |
| Temps général | Constante 1/30 à 0x0914EEE0 | Pas de 33,3 ms | Sans correction : temps simulé ×2 | Pas de 16,7 ms |
| Compensation joueur | Chemin local à 0x091698BC | Mouvement cohérent | Le nouveau delta exige une compensation | Saut, chute et glide proches du 30 FPS |

La paire 0x0914EEE0 / 0x091698BC doit rester groupée : la première fournit le delta 1/60 et la seconde compense le chemin joueur qui attendait l’ancien pas.

## Résultat de référence

- Observé : déplacement, saut, chute et glide redeviennent globalement comparables au 30 FPS.
- Attendu : la caméra reste environ deux fois trop rapide et le Titanium Bolt demeure gamebreaking.
- Intérêt : produire la liste brute des systèmes encore liés au nombre d’updates.

## Test

Faire un trajet fixe, dix sauts, une chute chronométrée et un glide. Ne pas utiliser ce profil pour juger les objets du niveau : il sert précisément de témoin brut.
