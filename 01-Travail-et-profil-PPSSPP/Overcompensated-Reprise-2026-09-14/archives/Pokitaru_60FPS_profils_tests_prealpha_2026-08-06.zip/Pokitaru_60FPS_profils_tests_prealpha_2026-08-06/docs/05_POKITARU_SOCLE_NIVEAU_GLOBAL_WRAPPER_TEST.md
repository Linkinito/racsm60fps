# Notice 05 — socle + niveau, wrapper global en une passe

## Fonctionnement

Ce profil applique vingt-trois écritures avant le démarrage de Pokitaru. Il reprend le socle, les quatorze constantes d’objets / ennemis et modifie une seule fois le wrapper commun au lieu de rediriger quinze appels individuels.

| Composant | Quantité | Application |
|---|---|---|
| Écritures socle | 8 | Identiques au profil 02 |
| Constantes objets / ennemis | 14 | Identiques aux constantes directes du profil 04 |
| Wrapper partagé | 1 | 0x09148094 : seconde passe interne remplacée par NOP |
| Appels directs couverts | 55 observés | Couverture plus large que les 15 appels locaux |

## Identification

La fonction 0x0914805C ajoute une seconde passe autour de la primitive 0x09147F90. À 60 updates par seconde, la seconde passe peut doubler la réponse de nombreux lissages. Le patch remplace le JAL interne du wrapper à 0x09148094 par NOP.

## Résultats de référence

- Vanilla 30 FPS : les deux passes et les constantes d’origine produisent le comportement de référence.
- Socle 60 FPS : les objets encore frame-based et les lissages à deux passes peuvent progresser trop vite.
- Profil individuel 04 : seuls quinze appels identifiés sont redirigés.
- Profil global 05 : les cinquante-cinq appelants directs observés héritent de la version une passe.

## Résultat attendu

Les objets déjà ciblés doivent rejoindre leurs durées 30 FPS, tout en révélant si d’autres consommateurs du wrapper bénéficient du même changement. Ce résultat est prédit statiquement ; la couverture large reste EXPÉRIMENTALE.

## Campagne de non-régression

Rejouer au minimum Luna, les trois familles de portes, le bateau, le Dropship, l’ascenseur final, la navigation ennemie, les orientations, les traversées et la caméra. Une amélioration sur un seul objet ne valide pas le wrapper global.

Ne pas combiner avec le profil 04 ni avec le bloc Aileron du profil 07, qui redirigent des appels locaux.
