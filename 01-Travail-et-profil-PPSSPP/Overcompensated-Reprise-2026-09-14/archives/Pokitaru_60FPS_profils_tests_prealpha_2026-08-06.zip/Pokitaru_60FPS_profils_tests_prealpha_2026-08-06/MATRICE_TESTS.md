# Matrice de campagne Pokitaru

| Étape | Configuration | But | Mesures minimales |
|---|---|---|---|
| A | 30 FPS vanilla, aucun cheat | Référence absolue | Durées, distances, dégâts, nombre d’événements |
| B | 01 base | Anomalies brutes | Joueur correct ; caméra et systèmes frame-based visibles |
| C | 02 socle | Référence 60 FPS commune | Caméra et Titanium Bolt corrigés |
| D | 03, une arme C0 | Combat | Une arme, un niveau d’arme et un ennemi fixes |
| E | 04, un objet C0 | Niveau individuel | Une scène / transition à la fois |
| F | 05 global | Comparaison de couverture | Rejouer toute la checklist E et les non-régressions |
| G | 06, blocs dans l’ordre | Breakables / boulons | Physique, timers, attraction, rotation, cadence |
| H | 07, un bloc C0 | Cosmétiques | Durées et comptage d’émissions |

## Fiche de résultat

Pour chaque essai, noter :

- version du paquet et nom exact de l’INI ;
- bloc C0 activé ;
- version et plateforme PPSSPP, backend graphique, frameskip ;
- framerate réellement maintenu ;
- sauvegarde / savestate et lieu précis ;
- résultat 30 FPS, résultat socle, résultat patché ;
- cinq répétitions minimum ;
- durée en secondes, distance, dégâts / XP et nombre d’événements ;
- vidéo ou captures, si possible avec compteur d’images ;
- régression observée après la mécanique principale.

## Ordre et restauration

Un test commence depuis un démarrage à froid ou une restauration confirmée. Après un bloc C0 : le décocher, activer son RESTORE, recharger Pokitaru ou le checkpoint, puis désactiver RESTORE. En cas de doute, redémarrer complètement PPSSPP.

Le profil 04 LOCAL JAL et le profil 05 GLOBAL WRAPPER ne doivent jamais être actifs simultanément.
