# Validation technique

Résultat : SUCCÈS

## Sources Pokitaru

- LEVEL_01.PRX : d10a81d076fb44987a45314a020cda2f7e8b39f860b957911ca9365464676571
- RAM2.dump : 5f68eceba120a58eb4c21c9dd1e9fc57ef96ab0ffcdbbb5fb17d37a60d599a3a
- POKITARU.MB.WAD : 7da60590aaab6e22b3569a31c2e3e61e1fadaad0b52f4deb324a6679f832e7fa
- UCES00420_EBOOT.BIN : eab4e81e302cff922969ea5fe31f937ba96b18ea8b2f7ee7632038537d00ffdd

Les fichiers RAM.dump et LEVEL_02_clean.PRX liés à Ryllus n’ont servi ni aux adresses ni aux opcodes de ce paquet.

## Contrôles

- 147 valeurs vanilla recoupées dans le PRX propre ou, pour les tables runtime nulles dans le PRX, dans RAM2.dump ;
- relocation MIPS26 recoupée : 0x091D0350 vaut 0x0C06FD09 dans le PRX brut et 0x0E4BE449 en RAM ;
- sept syntaxes INI analysées ;
- mots float recalculés en IEEE-754 simple précision ;
- cave armes : 0x08802C00–0x08802E9C ;
- cave breakables / boulons : 38 instructions, 152 octets, 0x08803000–0x08803094, retour 0x09162098 ;
- couverture TEST / RESTORE exacte : 79 adresses armes, 29 niveau individuel, 18 breakables / boulons et 12 cosmétiques ;
- aucun binaire du jeu dans le paquet ;
- dispatcher Pokitaru limité au module index 1.

## Statistiques INI

| Fichier | Blocs C1 | Blocs C0 | Lignes _L |
|---|---|---|---|
| 01_POKITARU_60FPS_BASE.ini | 1 | 1 | 47 |
| 02_POKITARU_60FPS_SOCLE.ini | 1 | 1 | 59 |
| 03_POKITARU_SOCLE_ARMES_TEST.ini | 1 | 26 | 300 |
| 04_POKITARU_SOCLE_NIVEAU_INDIVIDUEL_TEST.ini | 1 | 24 | 108 |
| 05_POKITARU_SOCLE_NIVEAU_GLOBAL_WRAPPER_TEST.ini | 1 | 1 | 104 |
| 06_POKITARU_SOCLE_BREAKABLES_BOULONS_TEST.ini | 1 | 14 | 124 |
| 07_POKITARU_SOCLE_COSMETIQUES_TEST.ini | 1 | 10 | 74 |

## Erreurs

- aucune erreur détectée

Cette validation est structurelle et statique. Elle ne remplace pas les essais dynamiques PPSSPP à 30 et 60 FPS, particulièrement pour les armes, le wrapper global, les breakables, les boulons ordinaires et les cosmétiques.
